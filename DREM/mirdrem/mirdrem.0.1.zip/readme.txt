Version 0.1 of mirDREM 
-------------------------------------------------------------------------------
This software was developed by Marcel Schulz in collaboration with Ziv Bar-Joseph. 
Any questions about the software or bugs found should be emailed to mschulz@mmci.uni-saarland.de or zivbj@cs.cmu.edu.

-------------------------------------------------------------------------------
mirDREM requires Java 1.5 or later to be installed.  Java can be downloaded from
http://www.java.com.

We are currently porting mirDREM to the DREM 2.0 version (http://sb.cs.cmu.edu/drem/, reference 2) to use the improved visualization and output features and hope that it will be soon available.

mirDREM comes packaged with a processed data set for a mouse gene and microRNA expression time series as explained in reference 1).

-------------------------------------------------------------------------------
Once Java is installed, to start mirDREM in Microsoft Windows double click on mirdrem.cmd.  
Otherwise to start mirDREM, from a command line while in the mirdrem directory enter the 
command

java -mx1024M  -jar mirdrem.jar 

The default settings for mirdrem are loaded when you start. Containing   
miRNA and TF-gene interactions and mouse time series expression data of genes and miRNAs that can be used to reconstruct the model described in reference 1).  

This opens the main dialog and in order to start the computation hit the Execute button on the bottom.
A search dialog should open now and after a few minutes (depending on your processor) the complete network should be displayed in a new window.

mirDREM comes with two sets of predicted interaction datasets which can be found in the RegInput folder:
mouse-TF-miRNA-interactions.dat
human-TF-miRNA-interactions.dat
Both contain TF and miRNA predicted interactions one for human and one for mouse.

In addition to the interaction file in the RegInput folder, mirDREM needs an additional file that has to be selected under Options->mirDREM Options->Regulator Type File
For both interaction datasets the corresponding regulator type files can be found in the main mirDREM folder (mouse-RegulatorType.dat,human-RegulatorType.dat).

The origin of TF interactions is explained in reference 2).

The miRNA-gene interactions are taken from the microcosm database (http://www.ebi.ac.uk/enright-srv/microcosm/) which uses the miRanda prediction algorithm (reference 3), all predictions are taken if p-value <= 0.01.

The interactions are contained in the RegInput directory.
If a user adds their own files to this directory they will automatically
appear on the menu of available regulator-gene association files.  

Use the small help buttons in the GUI to learn more about the differnet input fields and parameters.
-------------------------------------------------------------------------------

mirDREM makes use of the Piccolo toolkit which is distributed under a BSD license.  
More information about Piccolo can be found at www.cs.umd.edu/hcil/piccolo

mirDREM makes use of the Batik software which is distributed under an Apache license
More information about Batik can be found at http://xmlgraphics.apache.org/batik/.


mirDREM makes use of the Gene Ontology and gene annotations provided by Gene Ontology
Consortium members.  More information about the Gene Ontology can be found at
www.geneontology.org.

-------------------------------------------------------------------------------
References
1) Marcel H  Schulz, Kusum V Pandit, Christian L Lino Cardenas, Ambalavanan Namasivayam, Naftali Kaminski, Ziv Bar-Joseph
Reconstructing dynamic miRNA regulated interaction networks
submitted.
2) MH Schulz, WE Devanny, A Gitter, S Zhong, J Ernst and Z Bar-Joseph 
DREM 2.0: Improved reconstruction of dynamic regulatory networks from time-series expression data 
BMC Systems Biology 2012
3) Enright AJ, John B, Gaul U, Tuschl T, Sander C and Marks DS.
 MicroRNA targets in Drosophila. Genome Biology (2003) 5;R1
