package edu.cmu.cs.sb.drem;

import edu.cmu.cs.sb.core.*;
import javax.swing.*;

import java.util.*;
import java.text.*;
import java.io.*;
import java.awt.*;
import java.math.*;
import java.awt.event.*;
import java.util.zip.*;

import edu.umd.cs.piccolo.nodes.PPath;
import edu.umd.cs.piccolo.nodes.PText;
import java.util.regex.*;

/**
 * This class implements the core methods for learning the DREM maps
 */
public class DREM_Timeiohmm 
{
    int nglobaltime;
    double nodepenalty =10;
    boolean bmodeldiff = true;
    static boolean BDEBUG =false;
    static boolean BDEBUGMODEL = false;
    boolean ballowmergeval =false;
    boolean bsavedchange = false;
    boolean BEQUALSTD = false;
    boolean BVITERBI =false;
    boolean BREGDREM =false;
    boolean bhasmerge = false;
    double MINPROB = .00000000000000000001;
    double DEFAULTSIGMA = .5;
    double MAXFUTUREITR = 30;
    double MERGEMIN = -.0015;
    double DELAYMIN = -.0015;

    double MERGEMINDIFF = 0;
    double DELAYMINDIFF = 0;
    int nrandomseed;
    DREMGui progressDREMGui;
    int nglobaliteration;
    int ninitsearchval;

    double RESPLITMIN = -.0015;
    double RESPLITMINDIFF = 0;

    boolean brealXaxisDEF;
    double dYaxisDEF;
    double dXaxisDEF;
    double dnodekDEF;
    int nKeyInputTypeDEF;
    double dKeyInputXDEF;
    double dpercentDEF;
    JButton currentButton;

    JLabel statusLabel;
    JLabel statusLabel15;
    JLabel statuscountLabel;

    private static String SCORESDIR = "TOPAALoc";
    static String SZDELIM = "|;,";
    DREM_NaiveBayes filteredClassifier;

    double dprevouterbestlog;
    double dtrainlike;//last trainlikelihood
    boolean bfilterbinding = false;
    double EPSILON =.01; 
    double EPSILONDIFF = .01;
    double BEPSILON =0.001;
    int nmaxchild;
    int ntotalcombined;//num filtered and non-filtered

    double[][] CONSTANTA;

    int MINPATH =5;
    static double RIDGE =1;
    static double MINSIGMA = .0001;
    double dminstddev = 0.5;

    String[] testgenenames;
    double[][] traindata;
    int[][] trainpval; 
    //NOTE: pval in variable name is an artificat from an old version of the code
    //the values in these arrays are the integer values for the TF-gene interaction

    String[] traingenenames;
    double[][] testdata;
    int[][] testpval;
    int[][] trainpma;
    int[][] testpma;

    int[][] trainpvalIndex;
    int[][] testpvalIndex;

    int[][] trainpvalTF;
    int[][] trainpvalTFIndex;
    int[][] testpvalTF;
    int[][] testpvalTFIndex;

    int[][] bindingpvalTF; //each row is a TF and gives the interaction value for the genes it regulates
    int[][] bindingpvalGene;  //each row is a gene and gives the interaction value for TFs regulating  the gene
    int[][] bindingpvalTFindex;  //each row is a TF and gives the index of genes the TF regulates
    int[][] bindingpvalGeneindex; //each row is a gene gives the index of TFs regulating the gene 

    String[] tfNames;
    int[] dBindingVals;
    HashMap htBinding;
    HashSet hsUniqueInput;
    

    Treenode treeptr;
    NumberFormat nf2;
    NumberFormat nf3;
    double dbestlog;
    Treenode bestTree = null;
    DREM_DataSet theDataSet;

    int[][][][] theInstancesTF;
    int[][][] theInstancesTFIndex;
    int[][][][] theInstances;
    int[][][] theInstancesIndex;
    int[][] ylabels;
    JLabel statusLabel2;
    JLabel statusLabel3;
    int numtotalPath = 1;
    double dbesttrainlike;

    int numbits;  //number of boolean items for the static vector
    double TRAINRATIO = .75;

    Random theRandom;

    int ntrain;
    int ntest;
    int numcols;
    int nholdout;

    double HOLDOUTRATIO =0;
    double[][] holdoutdata;
    int[][] holdoutpval;
    int[][] holdoutpma;
    int[][] holdoutpvalIndex;

    boolean[] bholdout;
    BigInteger[] storedbestpath;
    String szinitfileval;
    String szexpname;
    String sznodepenaltyval;
    String szconvergenceval;
    String szbinding;
    ArrayList savedColors = new ArrayList();
    double dgloballike;
    private int ntotalID;

    Hashtable htBackPts = new Hashtable();

    String szstaticsourceval;
    
    ///miRNA variables and tables
    //input variables from the IO
    static String miRNAInteractionDataFile = "";
    static String miRNAExpressionDataFile = "";
    static boolean checkStatusTF;     //should TF expression be scaled?
    static boolean checkStatusmiRNA;  //should miRNA be used as a regulator
    //values filled by the constructor
    int[] regulatorTypes;     //an arbitrary field to denote different types of regulators, e.g., 0=TF and 1=miRNA for each entry in RegulatorNames
    HashMap<String,Integer> RegulatorTypeHash;
    int numSplit = 1; //used to number splits for output

    // the new 3-matrix that is used to describe timepoint specific activity values
   int [][][]gene2Regulator2TimepointActivityValues;
   int [][][]regulator2Gene2TimepointActivityValues; //the reverse index first Tfs then the gene and the activity values
   double [][]RegulatorExpression;
   HashMap<String,Integer> regulatorExpressionIndex; //for any special regulator to be found in RegulatorExpression get the index 
   int numberSpecialRegulators;  //this is the number of miRNA genes read in from the expression data
   int numberTimePoints;   //the number of time points and at the same time the number of columns for the RegulatorExpression matrix (should be without 0 timepoint)
   static double miRNAScalingFactor = 1; // the weight for the logistic regression scaling of expression to activity values
   
   //for outputting the viterbi likelihood
   double[] geneViterbiLikelihoods;
   
   
   
    /**
     * Class constructor - provides the execution control on the method
     */
    public DREM_Timeiohmm(DREM_DataSet theDataSet,String szbinding, 
			 String sznumchildval, String szepsilonval,String szprunepathval,
			 String szdelaypathval, String szmergepathval, 
                         String szepsilonvaldiff,String szprunepathvaldiff,
			 String szdelaypathvaldiff, String szmergepathvaldiff,
                         String szseedval,
			 boolean bstaticcheckval,boolean ballowmergeval, int ninitsearchval,
                         String szinitfileval,  JLabel statusLabel, JLabel statusLabel15,
			 JLabel statusLabel2,JLabel statusLabel3, JLabel statuscountLabel,
			 JButton endSearchButton,boolean bstaticsearchval,
                         final boolean  brealXaxisDEF,final double dYaxisDEF,final double dXaxisDEF,
			 final double dnodekDEF,
			 final int nKeyInputTypeDEF,final double dKeyInputXDEF,final double dpercentDEF,
                         final JButton currentButton, String szexpname,String sznodepenaltyval,
			  boolean bpenalizedmodel, String szconvergenceval,String szminstddeval,String szstaticsourceval,  //miRNA
			  boolean checkStatusTF, boolean checkStatusmiRNA, String miRNAInteractionDataFile, String miRNAExpressionDataFile,
			  double miRNAScalingFactor
			  )
     throws Exception
    {
	this.szstaticsourceval = szstaticsourceval;
	this.szbinding = szbinding;
       this.szconvergenceval = szconvergenceval;
       this.dminstddev = Double.parseDouble(szminstddeval);
       this.sznodepenaltyval = sznodepenaltyval;
       this.statusLabel = statusLabel;
       this.statusLabel15 = statusLabel15;
       this.statusLabel2 = statusLabel2;
       this.statusLabel3 = statusLabel3;
       this.statuscountLabel = statuscountLabel;
       this.szexpname = szexpname;
       this.ballowmergeval = ballowmergeval;
       this.brealXaxisDEF =brealXaxisDEF;
       this.dYaxisDEF = dYaxisDEF;
       this.dXaxisDEF = dXaxisDEF;
       this.dnodekDEF = dnodekDEF;
       this.nKeyInputTypeDEF = nKeyInputTypeDEF;
       this.dKeyInputXDEF = dKeyInputXDEF;
       this.dpercentDEF = dpercentDEF;
       this.currentButton = currentButton;
       this.ninitsearchval = ninitsearchval;
       this.checkStatusTF = checkStatusTF;
       this.checkStatusmiRNA =checkStatusmiRNA;
       this.miRNAInteractionDataFile=miRNAInteractionDataFile;
       this.miRNAExpressionDataFile=miRNAExpressionDataFile;
       this.miRNAScalingFactor=1;//miRNAScalingFactor;

	BREGDREM = (!bstaticsearchval);
	if (BDEBUG)
	{
	   System.out.println(szepsilonval+"&&&&"+szseedval);
	}
        this.szinitfileval = szinitfileval;
        this.bfilterbinding = bstaticcheckval; 

        nf2 = NumberFormat.getInstance(Locale.ENGLISH);
        nf2.setMinimumFractionDigits(2);
        nf2.setMaximumFractionDigits(2);

        nf3 = NumberFormat.getInstance(Locale.ENGLISH);
        nf3.setMinimumFractionDigits(3);
        nf3.setMaximumFractionDigits(3);

        this.statusLabel2 = statusLabel2;
        this.statusLabel3 = statusLabel3;

        EPSILON = Double.parseDouble(szepsilonval)/100;
        DELAYMIN = Double.parseDouble(szdelaypathval)/100;
        RESPLITMIN  = Double.parseDouble(szprunepathval)/100;
        MERGEMIN  = Double.parseDouble(szmergepathval)/100;
        BEPSILON = Double.parseDouble(szconvergenceval)/100;

        EPSILONDIFF = Double.parseDouble(szepsilonvaldiff);
        DELAYMINDIFF = Double.parseDouble(szdelaypathvaldiff);
        RESPLITMINDIFF  = Double.parseDouble(szprunepathvaldiff);
        MERGEMINDIFF  = Double.parseDouble(szmergepathvaldiff);

        nrandomseed = Integer.parseInt(szseedval);
        theRandom = new Random(nrandomseed);
        nodepenalty = Double.parseDouble(sznodepenaltyval);
        this.bmodeldiff = bpenalizedmodel;

        nmaxchild = Integer.parseInt(sznumchildval);

        this.theDataSet = theDataSet;       
 
        CONSTANTA = new double[nmaxchild+1][];
        for (int nindex = 1; nindex <= nmaxchild; nindex++)
        {
	   CONSTANTA[nindex] = new double[nindex];
	   for (int njindex = 0; njindex < nindex; njindex++)
	       CONSTANTA[nindex][njindex] = 1.0/nindex;
        }

        if (szbinding.equals(""))
        {
	   BREGDREM = true;
        }
        else
        {
	   readTFGeneData(szbinding);
           buildFilteredClassifier();
           
           
        }
       //load miRNA expression and binding data miRNAInteractionDataFile = "";
     
        try
        {
        	if (!miRNAInteractionDataFile.equals("") && checkStatusmiRNA)
            {
        		
            	readRegulatorTypeData(miRNAInteractionDataFile);
            	
            	//System.out.println("Read in the Regulatortype table of length:" + regulatorTypes.length);
            	/* Debug 
            	for(int i = 0;i<5;i++){
            		System.out.println(tfNames[i] + " = " + regulatorTypes[i]);
            	}
            	for(int i = regulatorTypes.length-5;i<regulatorTypes.length;i++){
            		System.out.println(tfNames[i] + " = " + regulatorTypes[i]);
            	}
            	*/

         	       /*
         	        * run newf unction fillregulator2TimepointActivityValues()
         	        */
         	       fillregulator2TimepointActivityValues();
                
            }
        }
        catch (IOException ex)
        {
        	System.err.println(ex);
        	
        }
        
       // if(1==1){
       // 	return;
        //}
        //compute mean and std at each time point of genes assigned to the profile

        splitdata();  
        treeptr = new Treenode();

        boolean binitfile = (!szinitfileval.equals(""));
        if ((binitfile)&&(ninitsearchval==0))
        {	   

	   readInitTree(treeptr);
           computeOrders(treeptr);
	   combineTrainAndTest();
           viterbi(treeptr);
	   if (bindingpvalGene != null)
	   {
	      computeStats(treeptr,treeptr);
	      computeminparentlevel(treeptr);
	   }
           bsavedchange = true;
        }
        else
        {     
	   bsavedchange = false;

	   if ((binitfile)&&(ninitsearchval==1))
	   {
	       readInitTree(treeptr);
	   }
	   else 
	   {
              double[] dsigma = new double[traindata[0].length];
              double[] dmeans = new double[traindata[0].length];
              computeDataStats(traindata,trainpma, dsigma,dmeans);
              buildEmptyTree(0,treeptr,dsigma,dmeans);
	   }
	   
	   searchstage1();
           int numintervals = traindata[0].length-1;
           int[] path = new int[numintervals];

           int nremoved = 0;

      
	   if (endSearchButton != null)
	   {
              endSearchButton.setEnabled(false);
	   }

	   if (statusLabel3 != null)
	   {
              statusLabel3.setText(" ");
	   }

	   if (statusLabel2 != null)
	   {
              statusLabel2.setText(" ");    
	   }

 	   int NUMRESPLITS;
	   if (bmodeldiff)
	   {
              NUMRESPLITS = 0;
	   }
	   else
	   {
	      NUMRESPLITS = 1;
	   }

           for (int ni = 1; ni <= NUMRESPLITS; ni++)
           {
	      if (statusLabel3 != null)
	      {
                 statusLabel3.setText(" Deleting Paths: "+nremoved+" removed so far ");
	      }
 
              splitdata();
	      if (BVITERBI)
	      {
	         dbestlog = trainhmmV(treeptr,true);
	      }
	      else
	      {
	         dbestlog = trainhmm(treeptr,true);
	      }

              dbesttrainlike = dtrainlike;
 
	      if (!bmodeldiff)
	      {
	         if (BVITERBI)
	         {
                    dbestlog = testhmmV(treeptr);
	         }
	         else
	         {
                    dbestlog = testhmm(treeptr);
	         }
	      }

	      if (BDEBUG)
	      {
	         System.out.println("dbestlog = "+dbestlog);
	      }

	      boolean bdeleteagain = false;
              do
              {
	         if (BDEBUG)
	         {
                    System.out.println("trying to delete after resplit");
	         }

                 traverse(bestTree, 0,false);
                 dprevouterbestlog = dbestlog; 
	         dbestlog = Double.NEGATIVE_INFINITY;
                 bdeleteagain = traverseanddelete(path,treeptr,treeptr,true,
						 RESPLITMIN,RESPLITMINDIFF);
	         if (dbestlog == Double.NEGATIVE_INFINITY)
		    dbestlog = dprevouterbestlog;

 	         if (BDEBUG)
	         {
                    System.out.println("****** delete  best log likelihood "+dbestlog);
	         }

                 traverse(bestTree, 0,true);
	         if (bestTree != treeptr)
	         {
	            nremoved++;
	            numtotalPath--;
		    if (statuscountLabel != null)
		    {
	               statuscountLabel.setText(" Number of paths in model so far: "+numtotalPath);
                       statusLabel3.setText(" Deleting Paths: "+nremoved+" removed so far");
		       statusLabel2.setText(" "); 
		    }
                    treeptr = bestTree;
		 }

 	         if (BDEBUG)
		 {
                    System.out.println("CCC\tdelete\t"+dbesttrainlike+"\t"+dbestlog+"\t"+dprevouterbestlog);
		 }
	      }
	      while (bdeleteagain);
	   }

 	   boolean bagaindelay;
	   boolean bagaindelayouter;

	   int numdelay = 0;

	   do
	   {
	      bagaindelayouter = false;
	      for (int ndesiredlevel = 1; ndesiredlevel < numintervals; ndesiredlevel++)
	      {
	         do
                 {
	            if (!bmodeldiff)
	            {
                       if (BVITERBI)
                       {
		          dbestlog = testhmmV(treeptr);
		       }
                       else
                       {
		          dbestlog = testhmm(treeptr);
		       }
		    }

	            if (BDEBUG)
	            {
                       System.out.println("trying to delay "+ndesiredlevel+" "+dbestlog);
		    }

                    dprevouterbestlog = dbestlog; 

                    dbestlog = Double.NEGATIVE_INFINITY;
	            bagaindelay = traverseanddelay(path,treeptr,ndesiredlevel,treeptr,false);

	            if (dbestlog == Double.NEGATIVE_INFINITY)
	            {
	               dbestlog = dprevouterbestlog;
		    }
	            else
	            { 
		       numdelay++;
		       if (statusLabel3 != null)
		       {
		          statusLabel3.setText(" Number of delayed is "+numdelay+" so far");
		       }
		       treeptr = bestTree;  

		       double dimprovedelay = (dbestlog-dprevouterbestlog)/Math.abs(dbestlog);
                       String szimprovedelay = nf3.format(100*dimprovedelay) + "%";
		       String szimprovedelayDIFF = nf3.format(dbestlog-dprevouterbestlog);

		       if (statusLabel2 != null)
		       {
                          statusLabel2.setText(" Delay improvement: "+szimprovedelayDIFF+" ("+szimprovedelay+")");
		       }
		    }

	            if (BDEBUG)
	            {
                       System.out.println("****** delay  best log likelihood "+dbestlog);
		    }
		    traverse(bestTree, 0,false);
                     
                    treeptr = bestTree;

	            if (BDEBUG)
	            {
	               System.out.println("YYY\tdelay\t"+dbesttrainlike+"\t"+dbestlog+"\t"+dprevouterbestlog);
		    }

	            if (bagaindelay)
	            {
	               bagaindelayouter = true;
		    }
		 }
	         while (bagaindelay);
	      }
	   }
           while (bagaindelayouter);	 
	  
	   if (ballowmergeval)
	   {
              traverseandmerge(path);
	   }
	   treeptr = bestTree;
       
           traverse(bestTree, 0,false);
           if (BDEBUG)
           {
              System.out.println("Test set "+dbestlog);
              System.out.println("calling combine tranandtest");
	   }

           combineTrainAndTest();

           if (BVITERBI)
           {
	      trainhmmV(treeptr,true);
	   }
           else
           {
	      double dtemplog = trainhmm(treeptr,true);
	      nglobaltime++;
	      int numnodes = countNodes(treeptr,nglobaltime);
	      if (BDEBUGMODEL)
	      { 
	         System.out.println(nodepenalty+"\t final train is\t"+dtemplog+"\t"+
				numnodes+"\t"+(dtemplog+numnodes*nodepenalty)+"\t"+ dgloballike);
	      }
	   }
           traverse(bestTree, 0,false);
       
           boolean bagain;
       
           do 
           {
	      bagain = false;

              computeOrders(treeptr); 
              viterbi(treeptr);
	   
	      int[] bestpath = new int[path.length];
	      for (int nindex = 0; nindex < bestpath.length; nindex++)
	      {
	         bestpath[nindex] = -1;
	      }

              MinPathRec theMinPathRec = traverseanddeleteMinPath(path,bestpath,treeptr);
	      if (BDEBUG)
	      {
	         System.out.println("min is "+theMinPathRec.nval+"\t"+"level is "+theMinPathRec.nlevel);
	         for (int nindex = 0; nindex < bestpath.length; nindex++)
	         {
	            System.out.println(theMinPathRec.bestpath[nindex]);
		 }
	      }
	   
              if (theMinPathRec.nval < MINPATH)
	      {
                 deleteMinPath(theMinPathRec.bestpath,theMinPathRec.nlevel,treeptr); 
	         bagain = true;
                 traverse(treeptr, 0,true);

	         if (BVITERBI)
	         {
                    trainhmmV(treeptr,true);
		 }
	         else
	         {
                    trainhmm(treeptr,true);
		 }

	         if (BDEBUG)
	         {
	            System.out.println("after retrain");
		 }

                 traverse(treeptr, 0,true);
	     
	         nremoved++;
	         numtotalPath--;
	         if (statuscountLabel != null)
	         {
	            statuscountLabel.setText(" Number of paths in model so far: "+numtotalPath);
                    statusLabel3.setText(" Deleting Paths: "+nremoved+" removed so far");
	            statusLabel2.setText(" ");
		 }
	      }
           } while (bagain);
  
           if (bindingpvalGene !=null)
           {
	      computeStats(treeptr,treeptr);
	      computeminparentlevel(treeptr);
	   }
	}
    }


    /**
     * Sets up the stored data so that the training data includes all data except any external held out validation
     * data, meaning the data which might otherwise used for model selection is just for parameter learning
     */
    public void combineTrainAndTest()
    {
	nholdout = (int) (theDataSet.data.length * HOLDOUTRATIO);
        ntrain  = (theDataSet.data.length-nholdout);
        numcols = theDataSet.data[0].length;
        traindata = new double[ntrain][numcols];
	trainpma = new int[ntrain][numcols];
	trainpval = new int[ntrain][];
	trainpvalIndex = new int[ntrain][];
	trainpvalTF = new int[numbits][];
	trainpvalTFIndex = new int[numbits][];
	traingenenames = new String[ntrain];

        int ntrainindex = 0;
 
        for (int nindex = 0; nindex < theDataSet.data.length; nindex++)
	{
	   if (!bholdout[nindex])
	   {
              for (int ncol = 0; ncol < numcols; ncol++)
	      {
	         traindata[ntrainindex][ncol] = theDataSet.data[nindex][ncol];
		 trainpma[ntrainindex][ncol]  = theDataSet.pmavalues[nindex][ncol]; 
	      }

	      trainpval[ntrainindex] = bindingpvalGene[nindex];
	      trainpvalIndex[ntrainindex] = bindingpvalGeneindex[nindex];
	      traingenenames[ntrainindex] = theDataSet.genenames[nindex];
              ntrainindex++;  
	   }
	}
	makeTFindex(trainpval,trainpvalIndex,trainpvalTF,trainpvalTFIndex);

        loadInstances();
    }

    /**
     * Splits the non-held out validation data into a training set for learning the model parameters
     * and a test set for model selection
     */
    public void splitdata()
    {

	//splits data into training and testsets

	nholdout = (int) (theDataSet.data.length * HOLDOUTRATIO);
	if (bmodeldiff)
	{
           ntrain  = (theDataSet.data.length-nholdout);
           ntest   = 0;
	}
	else
	{
           ntrain  = (int)((theDataSet.data.length-nholdout)*TRAINRATIO);
           ntest   = theDataSet.data.length - ntrain - nholdout;
	}

        numcols = theDataSet.data[0].length;


        //build arrays with time-series training data
        //and binding p-value
	testgenenames = new String[ntest];

        testdata  = new double[ntest][numcols];
	testpma = new int[ntest][numcols];
        traindata = new double[ntrain][numcols];
	trainpma = new int[ntrain][numcols];
        testpval  = new int[ntest][];
	trainpval = new int[ntrain][];
	trainpvalTF = new int[numbits][];
	testpvalTF = new int[numbits][];
	trainpvalIndex = new int[ntrain][];
	testpvalIndex = new int[ntest][];
	trainpvalTFIndex = new int[numbits][];
	testpvalTFIndex = new int[numbits][];


	double[] foldrandom = new double[theDataSet.data.length];
	double[] foldrandomcopy = new double[theDataSet.data.length];

	if (bholdout == null)
	{
           holdoutdata = new double[nholdout][numcols];
	   bholdout = new boolean[theDataSet.data.length];

	   holdoutpval = new int[nholdout][numbits];
	   holdoutpma  = new int[nholdout][numcols];
	   holdoutpvalIndex = new int[nholdout][];

   	   for (int nindex = 0; nindex < foldrandom.length; nindex++)
	   {
	      foldrandom[nindex] =  theRandom.nextDouble();
	      foldrandomcopy[nindex] = foldrandom[nindex];
	   }
	   Arrays.sort(foldrandomcopy);
	   double dcutoff = foldrandomcopy[holdoutpval.length];
	
	   int nholdoutindex = 0;
	   
	   for (int nindex = 0; nindex < foldrandom.length; nindex++)
	   {
	      if (foldrandom[nindex] < dcutoff)
	      {
	         int nnonzero = 0;
		 holdoutpval[nholdoutindex] = bindingpvalGene[nindex];
		 holdoutpvalIndex[nholdoutindex] = bindingpvalGeneindex[nindex];

                 for (int ncol = 0; ncol < numcols; ncol++)
	         {
		    holdoutdata[nholdoutindex][ncol] =  theDataSet.data[nindex][ncol]; 
		    holdoutpma[nholdoutindex][ncol] = theDataSet.pmavalues[nindex][ncol];
		 }

		 bholdout[nindex] = true;
		 nholdoutindex++;
	      }
	      else
	      {
		  bholdout[nindex] = false;
	      }
	   }
	}

	/*---------------------------------------------*/
	//random drawing a set of ntrain elements from data.length elements
        int[] includetrain = new int[ntrain];
        boolean[] btrain = new boolean[theDataSet.data.length];
	if (BDEBUG)
	{
	   System.out.println(ntrain+" "+theDataSet.data.length);
	}

	int nincludeindex = 0;
	int nbtrainindex= 0;
	int nonholdout = 0;
	while (nincludeindex < ntrain)
	{
	   if (!bholdout[nbtrainindex])
	   {
	      includetrain[nincludeindex] = nbtrainindex;
              btrain[nbtrainindex] = true;
	      nincludeindex++;
	      nonholdout++;
	   }
	   nbtrainindex++;
	}
	if (BDEBUG)
	{
	   System.out.println("done");
	}

        //drawing nrandom elements from a set of numtotalannotated elements
        //where each element is equally likely
        for (; nbtrainindex < btrain.length; nbtrainindex++)
        {
	   if (!bholdout[nbtrainindex])
	   {
  	      if (theRandom.nextDouble() < ((double) ntrain/(double) (nonholdout+1)))
              {
	         int nreplaceindex =(int) Math.floor(ntrain*theRandom.nextDouble());
                 btrain[nbtrainindex] = true;
	         btrain[includetrain[nreplaceindex]] = false;
	         includetrain[nreplaceindex] = nbtrainindex;
	      }
              else
	      {
                 btrain[nbtrainindex] = false;
	      }
	      nonholdout++;
	   }
        }
	/*------------------------------------------------------*/

        int ntrainindex = 0;
        int ntestindex = 0;  
        for (int nindex = 0; nindex < btrain.length; nindex++)
	{
	    if (!bholdout[nindex])
	    {
	       if (btrain[nindex])
	       {
                  for (int ncol = 0; ncol < numcols; ncol++)
	          {
		     traindata[ntrainindex][ncol] = theDataSet.data[nindex][ncol]; 
		     trainpma[ntrainindex][ncol] = theDataSet.pmavalues[nindex][ncol];
		  }

		  trainpval[ntrainindex] = bindingpvalGene[nindex];
		  trainpvalIndex[ntrainindex] = bindingpvalGeneindex[nindex];
	          ntrainindex++;
		  
	       } 
	       else
	       {
		  testgenenames[ntestindex] = theDataSet.genenames[nindex];

                  for (int ncol = 0; ncol < numcols; ncol++)
	          {
		     testdata[ntestindex][ncol]=theDataSet.data[nindex][ncol]; 
		     testpma[ntestindex][ncol]  = theDataSet.pmavalues[nindex][ncol];
		  }

		  testpval[ntestindex] = bindingpvalGene[nindex];
		  testpvalIndex[ntestindex] = bindingpvalGeneindex[nindex];
                  ntestindex++;
		  
	       }
	    }
	}

	makeTFindex(trainpval,trainpvalIndex,trainpvalTF,trainpvalTFIndex);
	makeTFindex(testpval,testpvalIndex,testpvalTF,testpvalTFIndex);

	loadInstances();
    }

    /**
     * Generates pvalTF and pvalTFindex based on pval and pvalindex so that the rows correspond to each TF
     * and each entry in a row pvalTFindex corresponds to an index of a gene the TF regulates and the corresponding 
     * entry in pvalTF corresponds to the interaction value
     */
    public void makeTFindex(int[][] pval, int[][] pvalindex, int[][] pvalTF, int[][] pvalTFindex)
    {
	int[] counts = new int[pvalTF.length];
	for (int i = 0; i < pvalindex.length; i++)
	{
	    for (int j = 0; j < pvalindex[i].length; j++)
	    {
		counts[pvalindex[i][j]]++;
	    }
	}

	for (int i= 0; i < pvalTFindex.length; i++)
	{
	    pvalTF[i] = new int[counts[i]];
	    pvalTFindex[i] = new int[counts[i]];
	}

	//reusing counts as number found so far
	for (int i = 0; i < counts.length; i++)
	{
	    counts[i] = 0;
	}

	for (int ngene = 0; ngene < pvalindex.length; ngene++)
	{
	    for (int nregindex = 0; nregindex < pvalindex[ngene].length; nregindex++)
	    {
		int nTF = pvalindex[ngene][nregindex];
		int nTFregindex = counts[pvalindex[ngene][nregindex]];
		pvalTF[nTF][nTFregindex] = pval[ngene][nregindex] ;
		pvalTFindex[nTF][nTFregindex] = ngene;
		counts[nTF]++;
	    }
	}
    }

    /**
     * This class is responsible for manipulating the TF-gene data so that
     * it will be in format readily usable by a weighted classifier.
     * For a split with n children, the classifier needs n copies of each instance
     * because each instance will be assumed to have every label, but with different
     * weights for different labels.
     */
    void loadInstances()
    {
	//first dimension determines the number of instances we will have
	//each second dimension corresponds to an instance
	//the third dimension is the values in the instances
    	int timepoints=1;
    	
    	if (!miRNAInteractionDataFile.equals("") && checkStatusmiRNA){
    		timepoints = numberTimePoints;
    	}
    	theInstances = new int[timepoints][][][];
    	theInstancesTF = new int[timepoints][][][];
    	for(int time =0;time<timepoints;time++){
    		
    		theInstances[time] = new int[nmaxchild-1][][];
    		theInstancesTF[time] = new int[nmaxchild-1][][];
    	}
       ylabels = new int[nmaxchild-1][];
       theInstancesIndex = new int[nmaxchild-1][][];
      
       theInstancesTFIndex = new int[nmaxchild-1][][];

       for (int numchild = 2; numchild <= nmaxchild; numchild++)
       {
    	  for(int time =0;time<timepoints;time++){ 
			  theInstances[time][numchild-2] = new int[numchild*trainpval.length][];
			  theInstancesTF[time][numchild-2] = new int[numchild*numbits][];
    	  }
	  ylabels[numchild-2] = new int[numchild*trainpval.length];
	  theInstancesIndex[numchild-2]  = new int[numchild*trainpval.length][];
        
          theInstancesTFIndex[numchild-2] = new int[numchild*numbits][];

	  int nspot = 0;
          for (int ngene = 0; ngene < trainpval.length; ngene++)
          {
	     for (int nchild = 0; nchild < numchild; nchild++)
	     {
	    	 for(int time =0;time<timepoints;time++){
	    		 if (!miRNAInteractionDataFile.equals("") && checkStatusmiRNA){
	    			 theInstances[time][numchild-2][nspot] = gene2Regulator2TimepointActivityValues[time][ngene];
	    		 }else{
	    			 theInstances[time][numchild-2][nspot] = trainpval[ngene];
	    		 }
	    		 
	    	 }
		ylabels[numchild-2][nspot] = nchild;
		theInstancesIndex[numchild-2][nspot] = trainpvalIndex[ngene];
	        nspot++;
	     }
          }
          
      for(int time =0;time<timepoints;time++){
    	  makeTFindex(theInstances[time][numchild-2],theInstancesIndex[numchild-2],
		      theInstancesTF[time][numchild-2],theInstancesTFIndex[numchild-2]);
      }
      
      
      
    }
      
   }


    /**
     * Record of index and regulatory value 
     */
   private static class TFRegRec
   {
       int ntfindex;
       int nregval;

       TFRegRec(int ntfindex, int nregval)
       {
	   this.ntfindex = ntfindex;
	   this.nregval = nregval;
       }
   }

    ///////////////////////////////////////////////////////
   /**
    * Reads in the tf-gene interaction data currently in the format TF, gene, and if specified interaction value
    * where each column is delimitted by tabs
    */
    private void parseThreeColFormat(BufferedReader br) throws IOException
    {
	HashMap htGeneToTFArray = new HashMap();
	HashMap htTFtoInteger = new HashMap();
	int ntf = 0;
	String szLine;
	while ((szLine = br.readLine())!=null)
	{
	    StringTokenizer st = new StringTokenizer(szLine,"\t");
	    String szTF = st.nextToken();
	    String szGene = st.nextToken();
	    int ninput;
	    if (st.hasMoreTokens())
	    {
		String szToken = st.nextToken();
                try
		{
		   ninput = Integer.parseInt(szToken);
		}
		catch(NumberFormatException nfex)
		{
		    throw new IllegalArgumentException(szToken +" is not a valid score for a TF-gene interaction");
		}
	    }
	    else
	    {
		ninput = 1;
	    }

	    Integer objInt = (Integer) htTFtoInteger.get(szTF);
	    int ncurrTF;
	    if (objInt == null)
	    {
		ncurrTF = ntf;
		htTFtoInteger.put(szTF, new Integer(ntf));
		ntf++;
	    }
	    else
	    {
		ncurrTF = ((Integer) objInt).intValue();
	    }
	    ArrayList al = (ArrayList) htGeneToTFArray.get(szGene);
	    if (al == null)
	    {
		al = new ArrayList();
	    }
	    al.add(new TFRegRec(ncurrTF,ninput));
	    htGeneToTFArray.put(szGene,al);
	}
	br.close();

	numbits = htTFtoInteger.size();
	tfNames = new String[numbits];
	Iterator itrTFSet = htTFtoInteger.keySet().iterator();

	while (itrTFSet.hasNext())
	{
	    String szTF = (String) itrTFSet.next();
	    tfNames[((Integer) htTFtoInteger.get(szTF)).intValue()] = szTF;
	}


	Iterator itrGeneSet = htGeneToTFArray.keySet().iterator();
	while (itrGeneSet.hasNext())
	{
	    String szid = (String) itrGeneSet.next();
	    ArrayList al = (ArrayList) htGeneToTFArray.get(szid);
	    int numnonzero = al.size();


	     TFRegRec[] thePairsRecs = new TFRegRec[numnonzero];
	     for (int nbit = 0; nbit < numnonzero; nbit++)
	     {
		 thePairsRecs[nbit] = (TFRegRec) al.get(nbit);
	     }
	     Arrays.sort(thePairsRecs, new TFRegRecCompare());
	     int[] nonzeroindex = new int[numnonzero];
	     int[] nonzerovals = new int[numnonzero];
	    for (int i = 0; i < numnonzero; i++)
	    {
		TFRegRec theTFRec = thePairsRecs[i];
		nonzeroindex[i] = theTFRec.ntfindex;
		nonzerovals[i] = theTFRec.nregval;
	    }
	    loadBinding(szid, nonzeroindex, nonzerovals,numnonzero);
	}
    }

    //////////////////////////////////////////////////////////////////////////////////
    /**
     * Comparator object sorts strictly based on ntfindex
     */
    private class TFRegRecCompare implements Comparator
    {
	public int compare(Object o1, Object o2)
	{
	    TFRegRec tfr1 = (TFRegRec) o1;
	    TFRegRec tfr2 = (TFRegRec) o2;

	    if (tfr1.ntfindex < tfr2.ntfindex)
	    {
		return -1;
	    }
	    else if (tfr1.ntfindex > tfr2.ntfindex)
	    {
		return 1;
	    }
	    else
	    {
		return 0;
	    }
	}
    }


    /////////////////////////////////////////////////////////////////////////////////
    /**
     * Reads in the TF-gene input data assuming the header is already read and 
     * the data is in grid format
     */
    private void parseGridFormat(BufferedReader br) throws IOException
    {
       int[] nonzeroindex = new int[numbits];
       int[] nonzerovals = new int[numbits];
       String szLine;
       StringTokenizer st;

       while ((szLine = br.readLine()) != null)
       {
          int numnonzero = 0;

          if (!szLine.trim().equals(""))
	  {
	     st = new StringTokenizer(szLine,"\t");
	     int numTokens = st.countTokens();
	     if (numbits != (numTokens-1))
	     {
	        throw new IllegalArgumentException(
                          "Found a line with "+(numTokens-1)+" entries, expecting "+numbits);
	     }
	     String szid = st.nextToken();

             for (int nindex = 0; nindex < numbits; nindex++)
	     {
		String sznum = st.nextToken();
		try
		{   
		   int tempval = Integer.parseInt(sznum);
		   if (tempval != 0)
		   {
		      nonzeroindex[numnonzero] = nindex;
		      nonzerovals[numnonzero] = tempval;
		      numnonzero++;
		   }
		}
		catch (NumberFormatException ex)
	        {
		    if ((numbits == 2) && (nindex == 0))
		    {
		       throw new IllegalArgumentException("If TF-gene data is in column format, then the first two "+
							  "columns must have the headers 'TF' and 'Gene'");
		    }
		    else
		    {
		       throw new IllegalArgumentException(sznum+" is not a valid value for a TF-gene interaction!");
		    }
		}
	     }

	     //storing each vector of p-values in hashtable with gene identifier
	     loadBinding(szid, nonzeroindex, nonzerovals,numnonzero);
	  }
       }
       br.close();
    }


	/**
     * Loading in the RegulatorType data
     */
    public void readRegulatorTypeData(String regulatorTypeFile) throws IOException
    {
       RegulatorTypeHash = new HashMap<String,Integer>();
       BufferedReader br = null;

       try
       {
          br = new BufferedReader(new InputStreamReader(
                             new GZIPInputStream(new FileInputStream(regulatorTypeFile))));
       }
       catch (IOException ex)
       {
          br = new BufferedReader(new FileReader(regulatorTypeFile));
       }
       //get header line;
       String szLine = br.readLine();
       if (szLine == null)
       {
          throw new IllegalArgumentException("Empty Regulator type input file found!");
       }else{
    	   while ((szLine = br.readLine())!=null)
		   	{
		    	
		   	    StringTokenizer st = new StringTokenizer(szLine,"\t");
		   	    String regulatorID = st.nextToken();
		   	    String regulatorType = st.nextToken();
		   	    
		   	 try
				{   
		   		 	Integer regValue = (Integer) Integer.parseInt(regulatorType);
		   		 	RegulatorTypeHash.put(regulatorID, regValue);
				}
				catch (NumberFormatException ex)
				{
				       throw new IllegalArgumentException("Invalid Value for Regulator type");
				}
		   	    
		   	
		   	}
      }
       br.close();
       //after hashmap was read in fill the array regulatorTypes
       //for that find out which index an regulator has
       regulatorTypes=new int[tfNames.length];
       for(int i=0;i < tfNames.length;i++){
    	   try{
    		   	regulatorTypes[i] = RegulatorTypeHash.get(tfNames[i]).intValue();
           }
    	   catch(Exception e){
    		   throw new IllegalArgumentException("Missing Reg Value for a Regulator in RegulatorTypeHash");
    	   }
       }
    }
    /*
     * This function uses the Regulatorexpression array and 
     */
    public void fillregulator2TimepointActivityValues(){
    	/*
		    double [][]regulator2TimepointActivityValues;
double [][]RegulatorExpression;
int numberSpecialRegulators;  //this is the number of miRNA genes read in from the expression data
int numberTimePoints;   //the number of time points and at the same time the number of columns for the RegulatorExpression matrix (should be without 0 timepoint)
*/

    	/*
    	 * the 3-dimensional matrix regulator2TimepointActivityValues is filled with activity values
    	 * in case of TFs these activity values are simply the binding value
    	 * for an miRNA the function bindingAndExpression2Activity is called
    	 *  2. dimension : index of gene in Expression dataset 
    	 * 	3. dimension : number of Regulator
    	 *  1. dimension : Activity value for each of numberTimePoints many timepoints  
    	 */
    	//get the first index which is a microRNA to correct offset in RegulatorExpression
    int tfs=0,mirs=0;

    	for(int i=0;i<regulatorTypes.length;i++){
    		if(regulatorTypes[i] == 1){
    			mirs++;
    		}else{
    			
    		tfs++;
    		}
    		//	System.out.print(regulatorTypes[i]);
    			
    			//break;
    		//}
    	}
    	System.out.println("Found "+tfs+ " TFs and "+mirs +"miRs");
    	numberTimePoints=RegulatorExpression[0].length;

    	//System.out.println("numcols regulatorExpression"+RegulatorExpression[0].length);
		//System.out.println(regulatorTypes.length + " " + RegulatorExpression.length + " " + bindingpvalTF.length + " " +   tfs + " " + mirs + " "+ numberTimePoints) ;
		gene2Regulator2TimepointActivityValues = new int[numberTimePoints][][];
		for(int time =0;time<numberTimePoints;time++){
    			
			gene2Regulator2TimepointActivityValues[time] = new int[theDataSet.data.length][];

    	for(int geneIndex=0;geneIndex<theDataSet.data.length;geneIndex++){
    		
    		gene2Regulator2TimepointActivityValues[time][geneIndex] = new int[bindingpvalGene[geneIndex].length];

	    	for(int numRegulator=0;numRegulator<bindingpvalGeneindex[geneIndex].length;numRegulator++){
	    		int bindingValue = bindingpvalGene[geneIndex][numRegulator];
	    		int bindingIndexValue = bindingpvalGeneindex[geneIndex][numRegulator];
	    		    
	    			if(regulatorTypes[bindingIndexValue] == 1){
	    				if(bindingValue == 0){
	    					gene2Regulator2TimepointActivityValues[time][geneIndex][numRegulator] = 0;
	    				}else{
	    					//because classifier does not support doubles yet
	    					//System.out.println("offset "+offset+ "bindingIndexValue "+bindingIndexValue);
	    					//use here the entry from the RegulatorExpression matrix
	    					Integer specialRegulatorPositionInExpressionMatrix = regulatorExpressionIndex.get(tfNames[bindingIndexValue].toUpperCase());
	    					//if doesnt exists use only the bindingvalue as if it were a TF
	    					if( specialRegulatorPositionInExpressionMatrix  != null){
	    						
	    						double value=RegulatorExpression[specialRegulatorPositionInExpressionMatrix.intValue()][time];
	    						if(Math.abs(value) < 0.25 ){
	    							value=0;
	    								//if(Math.abs(value) > 0 ){
	    								//	value=1;
	    								//}
	    							
	    						}else{
	    							//System.out.println("Using scaling factor: "+miRNAScalingFactor);
	    							value=logitShiftZeroNegative(value,miRNAScalingFactor);
	    						}
		    					
		    					gene2Regulator2TimepointActivityValues[time][geneIndex][numRegulator] = (int)Math.signum( value);
		    					//gene2Regulator2TimepointActivityValues[time][geneIndex][numRegulator] = (int) (value*2);
	    						//gene2Regulator2TimepointActivityValues[time][geneIndex][numRegulator] = (int)Math.pow(Math.signum( value), 2.0);
		    					
	    					}else{
	    						//System.out.println("Couldnt find entry for regulator " + tfNames[bindingIndexValue]);
	    						gene2Regulator2TimepointActivityValues[time][geneIndex][numRegulator] = bindingValue;
	    					}

	    					
	    				}
	    				
	    			}else{
	    				gene2Regulator2TimepointActivityValues[time][geneIndex][numRegulator] =bindingValue; 
	    			}
	    		}
	    	}
    	}
    	
    	//get the reverse index by reusing code from makeTFindex for doubles and timepoints
    	
		regulator2Gene2TimepointActivityValues = new int[numberTimePoints][][];
		for(int time =0;time<numberTimePoints;time++){
			regulator2Gene2TimepointActivityValues[time]= new int[regulatorTypes.length][];
		}
    	
    	int[] counts = new int[regulatorTypes.length];
    	for (int i = 0; i < bindingpvalGeneindex.length; i++)
    	{
    	    for (int j = 0; j < bindingpvalGeneindex[i].length; j++)
    	    {
    		counts[bindingpvalGeneindex[i][j]]++;
    	    }
    	}

    	for (int i= 0; i < regulator2Gene2TimepointActivityValues[0].length; i++)
    	{
    		for(int time =0;time<numberTimePoints;time++){
    			regulator2Gene2TimepointActivityValues[time][i] = new int[counts[i]];
    		//	regulator2Gene2TimepointActivityValues[time]= new double[regulatorTypes.length][];
    		}
    		
    	   
    	}

    	//reusing counts as number found so far
    	for (int i = 0; i < counts.length; i++)
    	{
    	    counts[i] = 0;
    	}

    	for (int ngene = 0; ngene < bindingpvalGeneindex.length; ngene++)
    	{
    	    for (int nregindex = 0; nregindex < bindingpvalGeneindex[ngene].length; nregindex++)
    	    {
    		int nTF = bindingpvalGeneindex[ngene][nregindex];
    		int nTFregindex = counts[bindingpvalGeneindex[ngene][nregindex]];
    		for(int time =0;time<numberTimePoints;time++){
    			//System.out.println(nTF + " " + nTFregindex + " " + ngene+ " " +nregindex);
    			regulator2Gene2TimepointActivityValues[time][nTF][nTFregindex] = gene2Regulator2TimepointActivityValues[time][ngene][nregindex];
    		}
    		
    		counts[nTF]++;
    	    }
    	}
    	
    
    	//System.out.println("Finished exp.based matrices " + regulatorTypes.length + " " + RegulatorExpression.length + " " + bindingpvalTF.length + " " +   tfs + " " + mirs + " "+ numberTimePoints) ;
 	
	    	/*debug
	    	 * 
	    	 */
    	
    	//int geneIndex=755;    		    		
		    
    	 try{
    		  // Create file 
    		  FileWriter fstream = new FileWriter("/Users/Marcel/Projects/DREM/sbcmu/branches/Marcel-drem-branch/mirDREMHackRegulatorExpressionMatrix.txt");
    		  BufferedWriter out = new BufferedWriter(fstream);
    		  //out.write("Hello Java");
    		  //Close the output stream
    		  System.out.println("jhaslekfhasdhfaskdjh  " + regulator2Gene2TimepointActivityValues[1].length + " " + tfNames.length);
    		for(int numRegulator=0;numRegulator<regulator2Gene2TimepointActivityValues[1].length;numRegulator++){
	    	for(int geneIndex=0;geneIndex<regulator2Gene2TimepointActivityValues[1][numRegulator].length;geneIndex++){
		    		
		    		double bindingValue = (double)bindingpvalTF[numRegulator][geneIndex];
		    		int bindingIndexValue = bindingpvalTFindex[numRegulator][geneIndex];
		    		out.write(theDataSet.genenames[bindingIndexValue] +" "+ tfNames[numRegulator] + " ");
		    		
		    		for(int time =0;time<numberTimePoints;time++){
		    			out.write(regulator2Gene2TimepointActivityValues[time][numRegulator][geneIndex]+ " ");
		    			
		    		
		    		}
		    		out.write("\n");
		    }
    		}
	    	out.close();
    	}catch (Exception e){//Catch exception if any
		  System.err.println("Error: " + e.getMessage());
		  }
    
		    //System.exit(0);
		    /*
	    	System.out.println("Regulator expression line ");
	    	for(int i=0;i<numberTimePoints;i++){
	    		System.out.print(RegulatorExpression[0][i] + " ");
	    	}
	    	*/
	    	//write out the whole matrix for debuging
	    	
	    	 try{
	    		  // Create file 
	    		  FileWriter fstream = new FileWriter("/Users/Marcel/Projects/DREM/sbcmu/branches/Marcel-drem-branch/miRNAData/TimePointActivityValuesDefault.txt");
	    		  BufferedWriter out = new BufferedWriter(fstream);
	    		  for(int i=0;i<regulator2Gene2TimepointActivityValues[0].length;i++){
	    			  out.write("Timepoint"+i+"\n");
	    			  for(int a=0;a<regulator2Gene2TimepointActivityValues[i].length;a++){
	    				  out.write(tfNames[a]+" ");
	    				  for(int b =0;b<regulator2Gene2TimepointActivityValues[i][a].length;b++){
	    					  out.write(regulator2Gene2TimepointActivityValues[i][a][b]+" ");
	    				  }
	    				  out.write("\n");
	    			  }
	    		  }
	    		  
	    		  //Close the output stream
	    		  out.close();
	    		  }catch (Exception e){//Catch exception if any
	    		
	    		  System.err.println("Error in the writing of the timepointactivity File: " + e.getMessage());
	    		  }
	    	 
    	//System.exit(1);
    }
    
    
    public double logit(double x, double w){
    	return(1/(1+Math.exp(-w*x)));
    	
    }
    /*
     * A modified version of the logit function that shifts the logit function to 0,
     * s.t. when x is 0 the function returns 0, instead of 0.5 normally. 
     * Also instead of [0,1] the function outputs values in the range [-1,1] to allow for negative influence.
     * As with a normal logit function the weight w can be used to control the steepness of the function. 
     * Currently, it is assumed that the function is only called for entries that are supposed
     * to be regulating, that means if there is no regulatory relationship than logitShiftZeroNegative
     * should always return 0, but that has to be controlled before.
     */
    		
    public double logitShiftZeroNegative(double x,double w){
    	 if(x == 0){
    		    return(0);
    		  }
    		  else{
    		    return(Math.signum(x) *((logit(Math.abs(x),w)-0.5)*2));
    		  }
    }
    
    /////////////////////////////////////////// 
    /**
     * Responsible for loading the TF-gene interaction input data from the file into the variable fields
     */
    public void readTFGeneData(String szbinding) throws IOException
    {
       htBinding = new HashMap();
       hsUniqueInput = new HashSet();
       BufferedReader br = null;

       try
       {
          br = new BufferedReader(new InputStreamReader(
                             new GZIPInputStream(new FileInputStream(szbinding))));
       }
       catch (IOException ex)
       {
          br = new BufferedReader(new FileReader(szbinding));
       }

       String szLine = br.readLine();
       StringTokenizer st = new StringTokenizer(szLine,"\t");
       String szh1="";

       if (szLine == null)
       {
          throw new IllegalArgumentException("Empty TF-gene interaction input file found!");
       }
       else if (szLine.startsWith("\t"))
       {
          numbits = st.countTokens();
       }
       else
       {
          numbits = st.countTokens()-1;
	  szh1 = st.nextToken();
       }


       tfNames = new String[numbits];

       for (int ntfindex = 0; ntfindex < numbits; ntfindex++)
       {
          tfNames[ntfindex] = st.nextToken();
       }


       boolean bthreecol = (((numbits ==2))&&(szh1.equalsIgnoreCase("TF"))
	                    &&(tfNames[0].equalsIgnoreCase("GENE")));

       if (bthreecol)
       {
	   parseThreeColFormat(br);
       }
       else
       {
	   parseGridFormat(br);
       }



       hsUniqueInput.add(new Integer(0));
       if (bfilterbinding)
       {
          //filter those genes without binding data
	  int nbinding = 0;  //count of the number of genes with binding info

		//finding miRNA genes NOTE that the same is done in filtergenesthreshold2change in DataSetCore
	    Pattern p = Pattern.compile("MMU-");
	  
          //first determining how many genes we have binding data for
	  Object[] hitA  = new Object[theDataSet.data.length];
	  if(checkStatusmiRNA){
		  numberSpecialRegulators=0;
		  //One initial run to get the number of miRNAs
		  for (int nsrow = 0; nsrow < theDataSet.data.length; nsrow++)
		  {    
			  			//System.out.println(theDataSet.genenames[nsrow]);
	 	        		Matcher m = p.matcher(theDataSet.genenames[nsrow]);
	 	        		if(m.find()){
	 	        			
	 	        			numberSpecialRegulators++;
	 	        			//System.out.println("Found MIR at " + nsrow + " name "+ theDataSet.genenames[nsrow]);
	 	        		}
		  }
	  }
	  System.out.println("Found " + numberSpecialRegulators + " microRNA regulators ");
	  int currentRow = 0;
	  regulatorExpressionIndex = new HashMap<String,Integer>();
	  RegulatorExpression = new double[numberSpecialRegulators][];
	  for (int nrow = 0; nrow < theDataSet.data.length; nrow++)
	  {
		  
		  	boolean doit = true;
 	        //check if the gene is a miRNA then we will not use it
 	        if(checkStatusmiRNA){
 	        		Matcher m = p.matcher(theDataSet.genenames[nrow]);
 	        		if(m.find()){
 	        				doit =false;
 	        				regulatorExpressionIndex.put(theDataSet.genenames[nrow], new Integer(currentRow));
 	        			   RegulatorExpression[currentRow] = new double[theDataSet.numcols];
 	        			   for(int j = 0;j<theDataSet.numcols;j++){
 	        				  // copy the expression data for the miRNAs        			   
 	        				  RegulatorExpression[currentRow][j] = theDataSet.data[nrow][j];
 	        				   
 	        			   }
  				
 	        			  currentRow++;
 	 	        		//System.out.println("ID :" + theDataSet.genenames[nrow] + "is :" + doit);
 	        		}
 	        		
 	        }
	  
	  

	     Object obj = getBindingObject(theDataSet.genenames[nrow],theDataSet.probenames[nrow]); 

  	     if (obj != null)
	     {
  	    	 
  	    	 if(doit){
			        hitA[nrow] = obj;
			        nbinding++;
 	        }else{
 	        	
 	        	hitA[nrow] = null;
 	        }
	     }
	     else
	     {
	    	 
	 	        	hitA[nrow] = null;
	  }
	  }
              
	  if (BDEBUG)
	  {
             System.out.println("nbinding = "+nbinding);
          }

          bindingpvalGene= new int[nbinding][];
          bindingpvalGeneindex = new int[nbinding][];

	  int nbindingindex = 0;
	  boolean[] bbindingdata = new boolean[theDataSet.data.length];
	  //stores whether or not should keep gene

          //going through all data values storing into 
          //bindingpval binding values
          //flagging for filtering those records without binding
          for (int nrow = 0; nrow < theDataSet.data.length; nrow++)
          {
	     if (hitA[nrow] != null)
	     {
	        BindingGeneRec theBindingGeneRec = (BindingGeneRec) hitA[nrow]; 

	        bindingpvalGene[nbindingindex] = theBindingGeneRec.bindingpvalGene;
	        bindingpvalGeneindex[nbindingindex] = theBindingGeneRec.bindingpvalGeneindex; 
	        for (int nindex =0; nindex < theBindingGeneRec.bindingpvalGene.length; nindex++)
	        {
	           hsUniqueInput.add(new Integer(theBindingGeneRec.bindingpvalGene[nindex]));
	        }
	        nbindingindex++;
                bbindingdata[nrow] = true; 
	     }
	     else
	     {
	        bbindingdata[nrow] = false;
	     }
	  }
      	//System.out.println("Length of Regulator expression matrix" + RegulatorExpression.length);

	  //this line below was causing a bug previously
          //theDataSet = (DREM_DataSet) theDataSet.filtergenesgeneral(bbindingdata, nbinding, true);
	  theDataSet = new DREM_DataSet(theDataSet.filtergenesgeneral(bbindingdata, nbinding, true),theDataSet.tga);
	}
	else
	{
	   //not filtering genes with missing p-values instead setting to 0
	   //transfering binding p-values in a hashmap to an array
	   //0 values if do not have a p-value for that gene
	   //bindingpval = new double[theDataSet.data.length][numbits];
	   bindingpvalGene = new int[theDataSet.data.length][];//[numbits];
	   bindingpvalGeneindex = new int[theDataSet.data.length][];

	   for (int nrow = 0; nrow < theDataSet.data.length; nrow++)
	   {
	     Object obj = getBindingObject(theDataSet.genenames[nrow], theDataSet.probenames[nrow]);

  	     if (obj != null)
	     {
		BindingGeneRec theBindingGeneRec = (BindingGeneRec) obj;
	        bindingpvalGene[nrow] = theBindingGeneRec.bindingpvalGene;
	        bindingpvalGeneindex[nrow] = theBindingGeneRec.bindingpvalGeneindex; 
	        for (int nindex =0; nindex < theBindingGeneRec.bindingpvalGene.length; nindex++)
	        {
	           hsUniqueInput.add(new Integer(theBindingGeneRec.bindingpvalGene[nindex]));
	        }
	     }
	     else
	     {
		 bindingpvalGene[nrow] = new int[0];
		 bindingpvalGeneindex[nrow] = new int[0];
	     }
          }
       }
	  
       //System.out.println("Number of selected genes is "+bindingpvalGene.length); 
       bindingpvalTFindex = new int[numbits][];
       bindingpvalTF = new int[numbits][];
       makeTFindex(bindingpvalGene, bindingpvalGeneindex, bindingpvalTF, bindingpvalTFindex);
       hsUniqueInput.add(new Integer(0));
       Iterator itrKeys = hsUniqueInput.iterator();
       int nel = 0;

       dBindingVals = new int[hsUniqueInput.size()];
       while (itrKeys.hasNext())
       {
          Integer key = (Integer) itrKeys.next();
	  dBindingVals[nel] = key.intValue();
	  nel++;
       }
       Arrays.sort(dBindingVals);
      
    }


    /**
     * A recording contain an array of interaction values and annother array containing the indicies they
     * correspond to
     */
    static class BindingGeneRec
    {
	int[] bindingpvalGene;
	int[] bindingpvalGeneindex;
    }

    /**
     * Assume geneindex1 and geneindex2 are sorted arrays
     * Returns a BindingGeneRec where bindingpvalGeneindex has the union of geneindex1 and geneindex2
     * and bindingpvalGene has the corresponding values using the maximum to resolve disagreements
     */
    private static BindingGeneRec mergeArrays(int[] geneval1, int[] geneindex1, int[] geneval2,int[] geneindex2)
    {

	int nindex1 = 0;
	int nindex2 = 0;
	int nmatch = 0;

	while ((nindex1 < geneindex1.length)&&(nindex2 < geneindex2.length))
	{
	    if (geneindex1[nindex1] == geneindex2[nindex2])
	    {
		nmatch++;
		nindex1++;
		nindex2++;
	    }
	    else if (geneindex1[nindex1] < geneindex2[nindex2])
	    {
		nindex1++;
	    }
	    else if (geneindex2[nindex2] < geneindex1[nindex1])
	    {
		nindex2++;
	    }
	}

	int nmergecount = geneindex1.length + geneindex2.length - nmatch;

	BindingGeneRec theBindingGeneRec = new BindingGeneRec();
	theBindingGeneRec.bindingpvalGene = new int[nmergecount];
	theBindingGeneRec.bindingpvalGeneindex = new int[nmergecount];

	int nmergeindex = 0;
	nindex1 = 0;
	nindex2 = 0;
	while ((nindex1 < geneindex1.length)&&(nindex2 < geneindex2.length))
	{
	    if (geneindex1[nindex1] == geneindex2[nindex2])
	    {
		theBindingGeneRec.bindingpvalGene[nmergeindex] = Math.max(geneval1[nindex1], geneval2[nindex2]);
		theBindingGeneRec.bindingpvalGeneindex[nmergeindex] = geneindex2[nindex2];
		nindex1++;
		nindex2++;
	    }
	    else if (geneindex1[nindex1] < geneindex2[nindex2])
	    {
		theBindingGeneRec.bindingpvalGene[nmergeindex] = geneval1[nindex1];
		theBindingGeneRec.bindingpvalGeneindex[nmergeindex] = geneindex1[nindex1];
		nindex1++;
	    }
	    else if (geneindex2[nindex2] < geneindex1[nindex1])
	    {
		theBindingGeneRec.bindingpvalGene[nmergeindex] = geneval2[nindex2];
		theBindingGeneRec.bindingpvalGeneindex[nmergeindex] = geneindex2[nindex2];
		nindex2++;
	    }
	    nmergeindex++;
	}

	while (nindex2 < geneindex2.length)
	{
           theBindingGeneRec.bindingpvalGene[nmergeindex] = geneval2[nindex2];          
           theBindingGeneRec.bindingpvalGeneindex[nmergeindex] = geneindex2[nindex2];
	   nmergeindex++;
	   nindex2++;
	}
	
        while (nindex1 < geneindex1.length)
	{
          theBindingGeneRec.bindingpvalGene[nmergeindex] = geneval1[nindex1];
          theBindingGeneRec.bindingpvalGeneindex[nmergeindex] = geneindex1[nindex1];
	  nmergeindex++;
	  nindex1++;
	}

	return theBindingGeneRec;
    } 

    /**
     * Stores into htbinding the mapping of the gene szid to its non-zero TF-gene interactions given by
     * nonzeroindex and nonzerovals 
     */
    public void loadBinding(String szid, int[] nonzeroindex, int[] nonzerovals,  int numnonzero)
    {
       String szfull = szid.toUpperCase(Locale.ENGLISH);
       StringTokenizer stIDs = new StringTokenizer(szfull,SZDELIM);

       BindingGeneRec rec = new BindingGeneRec();
       rec.bindingpvalGeneindex = new int[numnonzero];
       rec.bindingpvalGene = new int[numnonzero];
       for (int i = 0; i < numnonzero; i++)
       {
	   rec.bindingpvalGeneindex[i] = nonzeroindex[i];
	   rec.bindingpvalGene[i] = nonzerovals[i];
       }

       while (stIDs.hasMoreTokens())
       {
          //union if gene matches multiple hits in binding file, takes last one seen if multiple non-zero
	  String sztoken =stIDs.nextToken();
	  BindingGeneRec currec = (BindingGeneRec) htBinding.get(sztoken);

          if (currec != null)
          {
	     rec = mergeArrays(rec.bindingpvalGene, rec.bindingpvalGeneindex,
                                  currec.bindingpvalGene, currec.bindingpvalGeneindex);
	  }
	  htBinding.put(sztoken, rec);

	  StringTokenizer stu = new StringTokenizer(sztoken,"_");
	  if (stu.countTokens() > 1)
	  {
	     String szfirsttoken = stu.nextToken();
	     currec =(BindingGeneRec) htBinding.get(szfirsttoken);
	     if (currec != null)
	     {
	        rec = mergeArrays(rec.bindingpvalGene, rec.bindingpvalGeneindex,
                                  currec.bindingpvalGene, currec.bindingpvalGeneindex);
	     }
	     htBinding.put(szfirsttoken, rec);
	  }
       }
    }

    /**
     * Returns an entry of htBinding corresponding to szprobename or szgenename
     */
    Object getBindingObject(String szgenename, String szprobename)
    {

       StringTokenizer st = new StringTokenizer(szprobename,SZDELIM); 
       String sztoken;
       Object obj = null;

       while ((st.hasMoreTokens()) && (obj == null))
       {
	   sztoken = st.nextToken();
	   obj = htBinding.get(sztoken);
       }

       if (obj == null)
       {
           st = new StringTokenizer(szgenename,SZDELIM); 
           while ((st.hasMoreTokens()) && (obj == null))
           {
	      sztoken = st.nextToken();
	      obj = htBinding.get(sztoken);
           }
       }

       return obj;
    }


    //////////////////////////////////////////////////

    /**
     * Computes the average and standard deviation expression level at each time point
     */    
    public void computeDataStats(double[][] data, int[][] pma, double[] dsigmas,double[] dmeans)
    {
	double dsum ;
	double dsumsq ;
	int npoints;
	double dsigmaavg = 0;
	for (int ncol = 0; ncol < data[0].length; ncol++)
	{
	    dsum = 0;
	    dsumsq = 0;
	    npoints = 0;
	    //need to handle 0 or 1 point error
            for(int nrow = 0; nrow < data.length; nrow++)
	    {
		if (pma[nrow][ncol] != 0)
		{
	           dsum += data[nrow][ncol];
	           dsumsq += Math.pow(data[nrow][ncol],2);
		   npoints++;
		}
	    }
	    dmeans[ncol]= dsum/npoints;
	    dsigmas[ncol] = Math.sqrt((dsumsq- Math.pow(dsum,2)/npoints)/(npoints-1));
	    if (BDEBUG)
	    {
	       System.out.print(dsigmas[ncol]+"\t");
	    }
	    dsigmaavg+= dsigmas[ncol];
	    if (BDEBUG)
	    {
	       System.out.println("###"+dsigmas[ncol]);
	    }
	}
	DEFAULTSIGMA = dsigmaavg/data[0].length;
	if (BDEBUG)
	{
	   System.out.println("[[[]]]"+DEFAULTSIGMA);
	   System.out.println();
	}
    }

    ///////////////////////////////////////////////////
    /**
     * Uses DREM_NaiveBayes to build a classifier which predicts given the set of transcription
     * factors predicted to regulate a gene whether it would appear filtered or not
     */    
    public void buildFilteredClassifier()
    {
       Iterator itrgenes = theDataSet.htFiltered.keySet().iterator();
       int numfiltered = theDataSet.htFiltered.size();

       int[][] filteredinput = new int[numfiltered][];
       int[][] filteredinputIndex = new int[numfiltered][];

       int nfilteredhits = 0;
       int[] ALLZEROES = new int[0];

       int nindex = 0;
       while (itrgenes.hasNext())
       {
	   //going through filtered genes
           Object geneobj = itrgenes.next();
	   String szprobe = (String) theDataSet.htFiltered.get(geneobj);
	   String szgeneobj = (String) geneobj;
	   //getBindingObject finds the first match for szgeneobj and szprobe
	   BindingGeneRec theBindingGeneRec = (BindingGeneRec) getBindingObject(szgeneobj, szprobe);
	   if (theBindingGeneRec != null)
	   {
	       filteredinput[nindex] = theBindingGeneRec.bindingpvalGene;
	       filteredinputIndex[nindex] = theBindingGeneRec.bindingpvalGeneindex;
	       nfilteredhits++;
	   }
	   else
	   {
	       if (!bfilterbinding)
	       {
		   //not filtering binding using all zeros insted
		   filteredinput[nindex] = ALLZEROES;
		   filteredinputIndex[nindex] = ALLZEROES; //really empty
	       }
	       else
	       {
		   filteredinput[nindex] = null;
		   filteredinputIndex[nindex] = null;
	       }
	   }
	   nindex++;
	}

       int nfinalfilter;
       if (bfilterbinding)
       {
	   nfinalfilter = nfilteredhits;
       }
       else
       {
	   nfinalfilter = numfiltered;
       }
       ntotalcombined = bindingpvalGene.length + nfinalfilter;

       if (BDEBUG)
       {
          System.out.println(bindingpvalGene.length +" $$$$$$$$$$ "+nfinalfilter);
       }
       //making new array with filtered and non-filtered
       //need to do this TF wise
       int[][] combinedbinding = new int[ntotalcombined][];
       int[][] combinedbindingIndex = new int[ntotalcombined][];
       int[] filteredlabel = new int[ntotalcombined];
       double[] trainweight = new double[ntotalcombined];
       for (int ni = 0; ni < bindingpvalGene.length; ni++)
       {
          filteredlabel[ni] = 1;
	  combinedbinding[ni] = bindingpvalGene[ni];
	  combinedbindingIndex[ni] = bindingpvalGeneindex[ni];	     
       }
         
       for (int ni = bindingpvalGene.length; ni < filteredlabel.length; ni++)
       {
          filteredlabel[ni] = 0;
       }
       
       int nfilteredindex = 0;
       int ntotalindex = bindingpvalGene.length;
       while ((nfilteredindex < filteredinput.length)&&(ntotalindex < combinedbinding.length))
       {
	   if (filteredinput[nfilteredindex] != null)
	   {
	      combinedbinding[ntotalindex] = filteredinput[nfilteredindex];
	      combinedbindingIndex[ntotalindex] = filteredinputIndex[nfilteredindex];	      
	      ntotalindex++;
	   }
	   nfilteredindex++;
       }

       for (int ni = 0; ni < trainweight.length; ni++)
       {
	   trainweight[ni] = 1;
       }

       //combinedbinding input values
       //filtered label y-labels
       if (dBindingVals.length > 0)
       {
           filteredClassifier = new DREM_NaiveBayes(combinedbinding,combinedbindingIndex,numbits,
                                                    filteredlabel, dBindingVals, 2);
       }
       else
       {
	   filteredClassifier = null;
       }

       if (BDEBUG)
       {
          System.out.println(filteredClassifier);
       }
    }
   
    
    ////////////////////////////////////////////////////
    /**
     * Displays the current temporary DREM model, from which a search
     * is performed for an improved model
     */
    public void displayTempMap() throws Exception
    {
       DREM_IO.bdisplaycurrent = false;
       final DREM_Timeiohmm fthishmm = this;
       if (BDEBUG)
       {
          System.out.println("before hmmgui");
       }

       final Treenode treecopy =(Treenode) treeptr.clone();

       computeOrders(treecopy);

       viterbi(treecopy);
       if (bindingpvalGene !=null)
       {
          computeStats(treecopy,treecopy);
	  computeminparentlevel(treecopy);
       }

       ((DREM_GoAnnotations) theDataSet.tga).buildRecDREM(treecopy,theDataSet.genenames);

       traverse(bestTree, 0,false);

       try
       {         
          javax.swing.SwingUtilities.invokeAndWait( 
          new Runnable() 
          {
             public void run() 
             {
	        progressDREMGui = new DREMGui(fthishmm,treecopy, brealXaxisDEF,dYaxisDEF,dXaxisDEF,
					  nKeyInputTypeDEF,dKeyInputXDEF,dpercentDEF,"(Not Final Model)",dnodekDEF);
	        edu.umd.cs.piccolo.PCanvas.CURRENT_ZCANVAS = null;
                progressDREMGui.setLocation(15,40);
                progressDREMGui.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

		progressDREMGui.setVisible(true);
                progressDREMGui.addWindowListener(new WindowAdapter() 
                {
                   public void windowClosing(WindowEvent we) 
                   {
		      progressDREMGui.closeWindows();
		   }
		});        
	     }
	  });
       }
       catch (InterruptedException iex)
       {
          iex.printStackTrace(System.out);
       }
       catch (java.lang.reflect.InvocationTargetException itex)
       {
          itex.printStackTrace(System.out);
       }   
       if (currentButton != null)
       {
          currentButton.setEnabled(true);
       }

    }


    //////////////////////////////////////////////////
    /**
     * Executes the first phase of the structure search
     * Considers adding and deleting paths, does not consider 
     * merges or delays
     */
    public void searchstage1() throws Exception
    {
       String szDIFF = "";
       String szpercent = "";
       int numintervals = traindata[0].length-1;
       int[] path = new int[numintervals];

       traverse(treeptr, 0,false);

          
       if (BVITERBI)
       {
          dbestlog =trainhmmV(treeptr,true);
       }
       else
       {
          dbestlog = trainhmm(treeptr,true);
       }
       traverse(treeptr, 0,false);

       //////////////////////////////
	
       double dprevbestlog;
       dprevouterbestlog=Double.NEGATIVE_INFINITY;

       if (!bmodeldiff)
       {
          if (BVITERBI)
          {
             dbestlog = testhmmV(treeptr);
          }
          else
          {
             dbestlog = testhmm(treeptr);
          }
       }
       dbesttrainlike = Double.NEGATIVE_INFINITY;
       boolean bendsearchlocal; 

       do 
       {
          if (BDEBUG)
          {
	     System.out.println("&&&& "+numtotalPath);
	  }
          //outer loop handles the re-splitting of the data
	  //and whether we should try to add and then delete nodes

  	  if (dprevouterbestlog != Double.NEGATIVE_INFINITY)
	  {

	     if (statusLabel != null)
	     {
	        statusLabel.setText(" Current score: "+nf2.format(dbestlog));
	        statusLabel15.setText(" Current score improvement: "+szDIFF+" ("+szpercent+")");
	        statusLabel3.setText(" Next score: "+nf2.format(dbestlog));
	        statusLabel2.setText(" Next score improvement: 0 (0.000%)");
	        statuscountLabel.setText(" Number of paths in model so far: "+numtotalPath);
	     }
             String szepsilonpercent = nf3.format(100*EPSILON) + "%";
	  }
  	  dprevouterbestlog = dbestlog;

          traverse(treeptr, 0,false);

          double dtemplog;

	  bestTree = treeptr;

	  if (BDEBUG)
	  {
  	     System.out.println("trying to add");
	  }
          dprevbestlog = dbestlog;

          traverse(bestTree, 0,false);
          traverseandadd(path,treeptr,treeptr);
	  if (BDEBUG)
	  {
             System.out.println("****** adding best log likelihood "+dbestlog);
	  }
          traverse(bestTree, 0,false);
         
	  if (BDEBUG)
	  { 
	     System.out.println("after traverse");
	  }
          treeptr = bestTree;
 
	  if (BDEBUG)
	  { 
	     System.out.println("$$$$$$$$$$$$$$$terminate "+dbestlog+"\t"+dprevbestlog+"\t"+
                (dbestlog-dprevbestlog)/Math.abs(dbestlog)+"\t"+(dbestlog-dprevbestlog));
	  }

          if (BDEBUG)
	  {
	     System.out.println("YYY\tadd\t"+dbesttrainlike+"\t"+dbestlog);
	  }

	  if (dbestlog > dprevbestlog)
	  {
             numtotalPath++;
	  }

	  while ((dbestlog - dprevbestlog)>0)
          {
	     if (BDEBUG)
	     {
                System.out.println("trying to delete");
	     }
                
             dprevbestlog = dbestlog; 
               
             traverseanddelete(path,treeptr,treeptr,false,0,0);
	        
             if (BDEBUG)
	     {
                System.out.println("****** delete  best log likelihood "+dbestlog);
	     }
                
             traverse(bestTree, 0,false);
              
             treeptr = bestTree;
	         
	     if (BDEBUG)
	     {
	        System.out.println("YYY\tdelete\t"+dbesttrainlike+"\t"+dbestlog);
	     }

	     if (dbestlog > dprevbestlog)
	     {
	        numtotalPath--;
	     }
	  }

	  if (BDEBUG)
	  {
	     System.out.println("after delete "+dbestlog+"\t"+dprevouterbestlog);
	     System.out.println("*************terminate "+(dbestlog-dprevouterbestlog)+"\t"+
			    (dbestlog-dprevouterbestlog));
	     System.out.println("ZZZ\t"+dbesttrainlike+"\t"+dbestlog);
	  }

	  szpercent = nf3.format(100*(dbestlog-dprevouterbestlog)/Math.abs(dbestlog)) + "%";
	  szDIFF = nf3.format(dbestlog-dprevouterbestlog);

	  bendsearchlocal = DREM_IO.bendsearch;

	  if (DREM_IO.bdisplaycurrent)
	  {
	     displayTempMap();  
	  }
	     
	  if (BDEBUG)
	  {
	     System.out.println("$"+EPSILON+" "+dbestlog+" "+dprevouterbestlog+" "+EPSILONDIFF);
	  }

       }
       while ((((dbestlog-EPSILON*Math.abs(dbestlog)-dprevouterbestlog)>EPSILONDIFF)
                  &&(!bendsearchlocal)&&!bmodeldiff) ||
		 (bmodeldiff && (dbestlog>dprevouterbestlog)&&(!bendsearchlocal)));

       if (statusLabel15 != null)
       {
          statusLabel15.setText(" Final Main Score Improvement: "+szDIFF+" ("+szpercent +")");
          statusLabel.setText(" Final Main Score: "+nf2.format(dbestlog));
          statuscountLabel.setText(" Number of paths in model so far: "+numtotalPath);
       }
    }


    ////////////////////////////////////////////////////////////////////////

    /**
     * Assigns to the nminparentlevel in all nodes the level of the most immediate ancestor
     * with two or more children
     */
    public void computeminparentlevel(Treenode ptr)
    {
       if (ptr != null)
       {
          if ((ptr.parentptrA == null)||(ptr.parentptrA.length == 1))
          { 
      	     if (ptr.parent == null)
	     {
	        ptr.nminparentlevel = ptr.ndepth;
	        ptr.minparentptr = ptr.parent;
	     }
	     else  
	     {
	        if (ptr.parent.numchildren >= 2)
	        {
                   ptr.nminparentlevel = ptr.ndepth;
                   ptr.minparentptr = ptr.parent;
                }
	        else
	        {
	           ptr.nminparentlevel = ptr.parent.nminparentlevel;
	           ptr.minparentptr = ptr.parent.minparentptr;
		}
	     }
	  }
	  else
	  {	
	     Treenode[] tempptrA = new Treenode[ptr.parentptrA.length];
	     int ndepth = ptr.ndepth;
	     for (int nindex =0 ; nindex < tempptrA.length; nindex++)
	     {
	        tempptrA[nindex] = ptr.parentptrA[nindex];
	     }
		
	     boolean bfoundit = false;
	     while (!bfoundit)
	     {
	        int nj = 1;
		boolean ballsame = true;
	        while ((ballsame)&&nj<tempptrA.length)
		{
		   if (tempptrA[nj] != tempptrA[nj-1])
		   {
		      ballsame = false;
		   }
		   else 
		   {
		      nj++;
		   }
		}
		  
                ndepth--;
	        bfoundit = ballsame;
	        for (int nindex =0 ; nindex < tempptrA.length; nindex++)
	        {
	           tempptrA[nindex] = tempptrA[nindex].parent;
		}
	     }

	     ptr.nminparentlevel = ndepth;
	     ptr.minparentptr = tempptrA[0];
	  }
	        
          for (int nindex = 0; nindex < ptr.nextptr.length; nindex++)
	  {
	     computeminparentlevel(ptr.nextptr[nindex]);
	  } 
       }
    }


    /**
     * Responsible with helper functions for merging paths. Paths must share a common most
     * recent split and no splits after a merge are allowed
     */
    public void traverseandmerge(int[] path) throws Exception
    {

	computeNumLeaves(bestTree);
	if (BDEBUG)
	{
	   System.out.println("in traverse and merge path.length = "+path.length);
	}

	traverse(bestTree,0,false);

        for (int nparentlevel = path.length-2; nparentlevel >=0; nparentlevel--)
	{
	   for (int nmergingdepth = path.length; nmergingdepth > nparentlevel+1; nmergingdepth--)
  	   {
	       //nmergingdepth is the depth of the merging
               //parent level is the common ancestor
		Treenode origbestTree;
                do
		{
                   dprevouterbestlog = dbestlog; 
                   dbestlog = Double.NEGATIVE_INFINITY;

		    if (BDEBUG)
		    {
		       System.out.println("calling traverseandmergehelp "+nmergingdepth+" "+nparentlevel);
		    }
		    origbestTree = bestTree;
		    traverseandmergehelp(path,0,nmergingdepth, nparentlevel,origbestTree,origbestTree);
         	    if (dbestlog == Double.NEGATIVE_INFINITY)
		        dbestlog = dprevouterbestlog;
		}
		while (origbestTree != bestTree);
	    }
	}

    }

    /**
     * Helper function for traverseandmerge used to recursively search for places to merge nodes
     */
    private void traverseandmergehelp(int[] path, int nlevel,int nmergingdepth, int nparentlevel, Treenode ptr,
				      Treenode origroot) throws Exception
    {
       
        if (nlevel <= nmergingdepth)
	{
	   for (int nindex = 0; nindex < ptr.numchildren; nindex++)
	   {
              path[nlevel] = nindex;
	      traverseandmergehelp(path,nlevel+1,nmergingdepth,
                                   nparentlevel,ptr.nextptr[nindex], origroot);
           }
	}
	
        if (nlevel == nmergingdepth)
	{
	   if (BDEBUG)
	   {
	      System.out.println("nparentlevel = "+nparentlevel+" nmergindepth = "+nmergingdepth+
                               " nlevel = "+nlevel+" mean = "+ptr.dmean);
	   }
           mergenode(path,nmergingdepth, nparentlevel,origroot);
	} 
    }


    /**
     * Computes the number of paths to leaves accessible from each node in the 
     * tree pointed to by ptr
     */
    public int computeNumLeaves(Treenode ptr)
    {
	if (ptr.numchildren == 0)
        {
	    return 1;    
	}
	else
	{
	   int nsum = 0;
	   for (int nindex = 0; nindex < ptr.numchildren; nindex++)
           {
	      nsum += computeNumLeaves(ptr.nextptr[nindex]);
	   }

	   if (BDEBUG)
	   {
	      System.out.println("ptr.dmean = "+ptr.dmean+" nsum = "+nsum);
	   }

	   ptr.numdownleaves = nsum;

	   return nsum;
	}
    }

    //////////////////////////////////////////////////////////////////////////////////////////
    /**
     * Returns true iff all nodes at nleveltogo only have one path to the leaves
     * Stores in hsLevel all nodes at nleveltogo is 0
     */
    public boolean findnodesAtLevel(Treenode treeptr, int nleveltogo, HashSet hsLevel)
    {
	if (nleveltogo == 0)
	{
	    hsLevel.add(treeptr);
	    if (treeptr.numdownleaves >= 2) 
                return false;
	    else
		return true;
	}
	else
	{
	    boolean ballsingles  = true;
	    for (int nindex = 0; nindex < treeptr.numchildren; nindex++)
	    {
		ballsingles= (ballsingles) && (findnodesAtLevel(treeptr.nextptr[nindex],nleveltogo-1,hsLevel));
	    }
	    return ballsingles;
	}
    }

    //////////////////////////////////////////////////////////////////////////////////////////////////
    /**
     * Helper function of traverseandmergehelp responsible for finding valid merges and 
     * evaluating them that are along path1 and at depth nmergingdepth
     */
    private void mergenode(int[] path1, int nmergingdepth, int nparentlevel, Treenode origroot) throws Exception
    {
       double dlog;

       if (BDEBUG)
       {
          System.out.println("nmerginglevel = "+nmergingdepth);
          System.out.println("nparentlevel = "+nparentlevel);
          System.out.print("Path: ");
          for (int i = 0; i < nparentlevel; i++)
          {
	     System.out.print(path1[i]+" ");
          }
          System.out.println();
       }

       Treenode tempptr = origroot;
       for (int nindex  = 0; nindex <nparentlevel; nindex++)
       {
	   tempptr = tempptr.nextptr[path1[nindex]];
       }

       if ((tempptr.numchildren >= 2))
       {
	   HashSet hsLevel = new HashSet();
	   boolean ballsingles = findnodesAtLevel(tempptr,(nmergingdepth-nparentlevel),hsLevel);
	   //ballsingles - is true if no more splits among nodes being merged	   

	   int numatLevel = hsLevel.size();
	   //only binary for now
	   if (BDEBUG)
	   {
	      System.out.println("numatLevel = "+numatLevel);
	   }

	   if ((numatLevel == tempptr.numchildren)&&(ballsingles))
	   {
	      //not allowing any downstream splits from parent node
	      //either before the level being merged, should have been accepted before
	      //among merged nodes, not allowing any resplits
	      //require ballsingles - to be true
              //also cannot have any splits 
	      //assume binary for now

 	      if (BDEBUG)
	      {
	         System.out.println("before clone");
	      }
	         
              traverse(origroot,0,false);
              Treenode treeroot = (Treenode) origroot.clone();
	      if (BDEBUG)
	      {
	         System.out.println("after clone");
	      }
	      traverse(treeroot,0,false);

	      //traversing to the parent
	      tempptr = treeroot;
              for (int nindex  = 0; nindex <nparentlevel; nindex++)
              {
	         tempptr = tempptr.nextptr[path1[nindex]];
	      }

	      Treenode parentptr = tempptr;

	      //travering to the nodes for merging
	      Treenode splitptr = null;
	      for (int nindex = nparentlevel; nindex < nmergingdepth; nindex++) 
	      {
	         tempptr = tempptr.nextptr[path1[nindex]];	     
	      }

      	      if (BDEBUG)
	      {
	         System.out.println(nmergingdepth+" parent mean "+parentptr.dmean+" tempptr.dmean "
                                            +tempptr.dmean+" split mean ");
	      }

	      boolean bvalidmerge = false;
	      ArrayList newparentptrA = null;
	      for (int notherchild = 0; notherchild < parentptr.numchildren; notherchild++)
	      {
	         if (BDEBUG)
		 {
		    System.out.println(notherchild+"\t"+bvalidmerge);
		 }

	         if (notherchild != path1[nparentlevel])
	         {  
         	    splitptr = parentptr.nextptr[notherchild];
	                
 	            for (int nindex = nparentlevel+1; nindex < nmergingdepth; nindex++) 
	            {
	               splitptr = splitptr.nextptr[0];
		    }
                         
		    if (splitptr != tempptr)
		    {
		       //its possible two nodes have already been merged on this level
		       //but there are two paths two them, we do not need to adjust parent
		       //pointers if just taking a different path to the main merging node 
		       if (!bvalidmerge)
		       {
		          //we haven't tried merging yet, just do this once to load the merging node 
			  //parents into the list
			  newparentptrA = new ArrayList();
			  if (tempptr.parentptrA == null)
			  {
			     //just single parent add to parent list
			     newparentptrA.add(tempptr.parent);
			     if (BDEBUG)
			     {
	                        System.out.println("A "+tempptr.dmean+" now links to "+tempptr.parent.dmean);
			     }
			  }
			  else
			  { 
			     for (int i = 0; i < tempptr.parentptrA.length; i++)
			     {
			        //add all parent links to merging state
			        newparentptrA.add(tempptr.parentptrA[i]);
			        if (BDEBUG)
			        {
	                           System.out.println("B "+tempptr.dmean+" now links to "+tempptr.parentptrA[i].dmean);
				}
			     }
			  }

			  bvalidmerge = true;

	                  if (BDEBUG)
	                  {
	                     if (tempptr.nextptr[0]!=null) 
                                System.out.println("mean is "+tempptr.nextptr[0].dmean);
		             System.out.println("VALID MERGE");
			  }
		       }
		           
		       if (BDEBUG)
		       {
	                  System.out.println(splitptr.dmean+" ");
		       }

		       if (splitptr.parentptrA == null)
		       {
		          splitptr.parent.nextptr[0] = tempptr;
		          newparentptrA.add(splitptr.parent);
			  if (BDEBUG)
		          {
	                     System.out.println("C "+tempptr.dmean+" now links to "+splitptr.parent.dmean);
			  }
		       }
		       else
		       {
		           for (int i = 0; i < splitptr.parentptrA.length; i++)
			   {
		              splitptr.parentptrA[i].nextptr[0] = tempptr;
		       	      newparentptrA.add(splitptr.parentptrA[i]);
			      if (BDEBUG)
			      {
	                         System.out.println("D "+tempptr.dmean+" now links to "+splitptr.parentptrA[i].dmean);
			      }
			   }
		       }

		       if (tempptr.nextptr[0] != null)
		       {
		          tempptr.nextptr[0].parent = tempptr;
		          tempptr.nextptr[0].parentptrA = null;
		       }

		       if (parentptr == splitptr.parent)
		       {
		          parentptr.numchildren--;
		       }
		    }
		 }
	      }

	      if (bvalidmerge)
	      {
	         //copying over new parent nodes
	         int nsize = newparentptrA.size();
	         tempptr.parentptrA = new Treenode[nsize];
	         for (int i = 0; i < nsize; i++)
	         {
	            tempptr.parentptrA[i] = (Treenode) newparentptrA.get(i);
	         }
	         if (BDEBUG)
	         {
                    System.out.println("MERGED TREE");
      	         }
	         traverse(treeroot,0,false);
	             
                 if (BVITERBI)
	         {
	            dlog = trainhmmV(treeroot,true);
		 }
	         else
                 {
		    dlog =trainhmm(treeroot,true);
		 }
 
		 if (BDEBUG)
		 {
	            System.out.println("after training:");
		 }

	         traverse(treeroot,0,false);

		 if (!bmodeldiff)
		 {
                    if (BVITERBI)
	            {
	               dlog = testhmmV(treeroot);
		    }
	            else
	            {
      	               dlog =testhmm(treeroot);
		    }
		 }

	         double dimprovemerge = (dlog-dprevouterbestlog)/Math.abs(dlog);
                 if (BDEBUG)
	         {		
                    System.out.println("merge* "+dimprovemerge+"\t"+MERGEMIN+"\t"
                                            +dlog+"\t"+dprevouterbestlog+"\t"+dbestlog);
		 }

		 if (((!bmodeldiff)&&
                      (((dlog+MERGEMIN*Math.abs(dlog)-dprevouterbestlog)>=MERGEMINDIFF)&&(dlog>dbestlog)))||
		       (bmodeldiff&&(dlog>=dprevouterbestlog)&&(dlog>dbestlog)))
                 {
                    bestTree = treeroot;
		    computeNumLeaves(bestTree);
                    dbestlog = dlog;
		    if (BDEBUG)
		    {
		       System.out.println("in merge "+dbestlog+" best tree is");
		       traverse(treeroot,0,false);
		    }
		
		    double dimprove = (dbestlog-dprevouterbestlog)/Math.abs(dbestlog);
                    String szimprove = nf3.format(100*dimprove) + "%";
		    String szimproveDIFF = nf3.format(dbestlog-dprevouterbestlog);
		    if (statusLabel2 != null)
	                 statusLabel2.setText(" Merge change: "+szimproveDIFF+" ("+szimprove+")"+
                                              " (Score "+nf2.format(dbestlog)+")");
		 }
	      }
	   }
       }
    }

    ///////////////////////////////////////////////////////////////////////
    /**
     * A record containing a node id, mean, and standard deviation
     * used for ordering the children node
     */
    static class OrderRec
    {
	int nid;
	double dmean;
	double dsigma;

	OrderRec(double dmean, double dsigma, int nid)
	{
	    this.nid = nid;
	    this.dmean = dmean;
	    this.dsigma = dsigma;
	}
    }

    /**
     * Comparator for OrderRec sorts first on dmean, then dsigma, then id all
     * in increasing order.
     */
    static class OrderRecCompare implements Comparator
    {
        public int compare(Object o1, Object o2)
	{
	    OrderRec or1 = (OrderRec) o1;
	    OrderRec or2 = (OrderRec) o2;

	    if (or1.dmean < or2.dmean)
		return -1;
	    else if (or1.dmean > or2.dmean)
		return 1;
	    else if (or1.dsigma < or2.dsigma)
		return -1;
	    else if (or1.dsigma > or2.dsigma)
		return 1;
	    else if (or1.nid < or2.nid)
		return -1;
	    else if (or1.nid > or2.nid)
		return 1;
	    else 
		return 0;
	}
    }

    ///////////////////////////////////////////////////////////////////////
    /**
     * Sorts the children of each node in treeptr and descendants
     * based on OrderRecCompare
     */
    public void computeOrders(Treenode treeptr)
    {
       if (treeptr.numchildren >=1)
       {
          if (treeptr.numchildren >= 2)
	  {
             OrderRec[] theOrderRecs = new OrderRec[treeptr.numchildren];
             for (int nindex = 0; nindex < treeptr.numchildren; nindex++)
             {
                theOrderRecs[nindex] = new OrderRec(treeptr.nextptr[nindex].dmean, 
                                                    treeptr.nextptr[nindex].dsigma, nindex);
	     }
	     Arrays.sort(theOrderRecs, new OrderRecCompare());
	     treeptr.orderA = new int[theOrderRecs.length];

	     for (int nindex = 0; nindex < treeptr.orderA.length; nindex++)
	     {
		 treeptr.orderA[nindex] = theOrderRecs[nindex].nid;
	     }
	  }


          for (int nindex = 0; nindex < treeptr.numchildren; nindex++)
          {
	      computeOrders(treeptr.nextptr[nindex]);
	  }
       }
    }


    ///////////////////////////////////////////////////////////////////////


    /**
     * Builds the initial tree which is just a single chain with mean and standard
     * deviation for each node being the global mean and standard deviation at 
     * the time point
     */
    public void buildEmptyTree(int ncurrdepth,
			       Treenode currnode, double[] dsigma, double[] dmean)
    {
	currnode.dsigma = Math.max(Math.max(dsigma[ncurrdepth],dminstddev),MINSIGMA);
       if (ncurrdepth+1 < dsigma.length)
       {
          currnode.numchildren = 1;
          currnode.timepoint=ncurrdepth;
          currnode.nextptr[0] = new Treenode(currnode);
          currnode.nextptr[0].dmean = dmean[ncurrdepth];
	  currnode.nextptr[0].parent = currnode;
	  if (BREGDREM)
	  {
	      currnode.ptrans[0] = 1;
	  }
          buildEmptyTree(ncurrdepth+1,currnode.nextptr[0], dsigma,dmean);
       }
    }

    /**
     * Initializes the model parameters to those in szinitfileval
     */    
    public void readInitTree(Treenode currnode) throws IOException
    {

	BufferedReader brinit = new BufferedReader(new FileReader(szinitfileval));
	String szfirstline = brinit.readLine();
	boolean bmergedtree = false;

	if (szfirstline.equalsIgnoreCase("MERGED TREE"))
	{
            szfirstline = brinit.readLine();
	    bmergedtree = true;
	}

	if (bmergedtree)
	{
	    if (ninitsearchval == 1)
	    {
		throw new IllegalArgumentException("Saved model has merges, but option allowed to start "+
			       "search from model is selected.\n"+
                              "Search may not begin from model with merges.  "+
                              "Consider option to use the saved model as is.");
	    }

	    if (!ballowmergeval)
	    {
	       throw new IllegalArgumentException("Saved model has merges, but merges are not selected to be allowed.");
	    }
	}

	StringTokenizer stfirstline = new StringTokenizer(szfirstline,"\t");
	if (stfirstline.countTokens() < 2)
	{
	    throw new IllegalArgumentException("Not a valid saved model file!");
	}

	String szfirsttoken = stfirstline.nextToken();
	int numcoeff = Integer.parseInt(stfirstline.nextToken());
	if ((numcoeff != tfNames.length)&&(!szfirsttoken.startsWith("REGDREM")))
	{
	    throw new IllegalArgumentException("Number of coefficients ("+numcoeff+") in the saved model does not "+                               
                                        "match the number of coefficients in the static input file ("+tfNames.length+")");
	}

	if (!(szfirsttoken.startsWith("REGDREM"))&&(BREGDREM))
	{
	    throw new IllegalArgumentException("'Use Transcription Factor-gene Interaction Data to Build Model' under 'Main Search Options' is unselected, "+
                                               "but saved model was built using the data.");
	}
	else if ((szfirsttoken.startsWith("REGDREM"))&&(!BREGDREM))
	{
	    throw new IllegalArgumentException("'Use Transcription Factor-gene Interaction Data to Build Model' under 'Main Search Options' is selected, "+
                                               "but saved model was built without the data.");
	}

	int ndepth = readInitTreeHelp(currnode, brinit,numcoeff,bmergedtree);

	if (ndepth != numcols)
	{
	    throw new IllegalArgumentException("Number of time points in the initial model ("+
                                               ndepth+") does not match number of time points in the data ("+numcols+")");
	}

	String szLine = brinit.readLine();
	if ((szLine != null) && (szLine.equals("COLORS")))
	{
	    readColors(brinit);
	}

	if (bmergedtree)
	{
	    HashMap createdNodes = new HashMap();
	    mergeDuplicates(currnode,createdNodes);
	}
    }

    /**
     * Helper function for reading the model parameters from a file
     */
    private int readInitTreeHelp(Treenode currnode, BufferedReader brinit, 
                                int numcoeff,boolean bmergedtree) throws IOException
    {
	String szLine = brinit.readLine();
	StringTokenizer st = new StringTokenizer(szLine,"\t");
	int nID;

	if (bmergedtree)
	{
	    nID = Integer.parseInt(st.nextToken());
	    currnode.nID = nID;
	}

	currnode.dmean = Double.parseDouble(st.nextToken());
	currnode.dsigma = Double.parseDouble(st.nextToken());
	currnode.numchildren = Integer.parseInt(st.nextToken());


  	int numcoefftoread;
	
        if (currnode.numchildren <= 1)
	{
	   numcoefftoread = 0;
	   currnode.binit = false;
	}
        else if (currnode.numchildren == 2)
        {
           numcoefftoread = numcoeff + 1;
	   currnode.binit = true;
	   numtotalPath++;
	}
	else
        {
	   if (currnode.numchildren > nmaxchild)
	   {
	      throw new IllegalArgumentException("Number of paths out of a node in the initial model file ("+
                                                     currnode.numchildren+") exceeds the maximum allowed "+nmaxchild);
	        
	   }
	   numtotalPath += currnode.numchildren-1;
	   numcoefftoread = (numcoeff+1)*(currnode.numchildren-1);
	   currnode.binit = true;
	}

	if ((numcoefftoread==0)&&(BREGDREM))
        {
	   currnode.ptrans[0] = 1;
	}
	else if (numcoefftoread > 0)
	{
	   if (BREGDREM)
	   {
	      for (int nindex = 0; nindex < currnode.numchildren; nindex++)
	      {
	         currnode.ptrans[nindex] = Double.parseDouble(brinit.readLine());
	      }
	   }
	   else
	   {
	      double[] dcoeff = new double[numcoefftoread];
	      String szcoeff;
	      StringTokenizer stcoeff;
	      for (int ncoeffindex = 0; ncoeffindex < numcoefftoread; ncoeffindex++)
	      {
	         szcoeff = brinit.readLine();
	         stcoeff = new StringTokenizer(szcoeff,"\t");
	         String szcoeffname = stcoeff.nextToken();
	         int nmodrow = ncoeffindex % (tfNames.length + 1); 
	         if ((nmodrow!= 0)&&(!szcoeffname.equals(tfNames[nmodrow-1])))
	         {
		    throw new IllegalArgumentException(ncoeffindex+" "+(tfNames.length+1)+" "+
                                             "Transcription factor "+szcoeffname +" in saved model  "+
					     "does not match transcription factor "+tfNames[nmodrow-1]+".");  
		 }
	         dcoeff[ncoeffindex] = Double.parseDouble(stcoeff.nextToken());
	      }

	      if (!miRNAInteractionDataFile.equals("") && checkStatusmiRNA){
	    		int usedTimepoint = Math.min(currnode.ndepth+1, numberTimePoints-1);
	    		currnode.tranC = 
	 			   new DREM_FastLogistic2(theInstancesIndex[currnode.numchildren-2],
	 					  theInstances[usedTimepoint][currnode.numchildren-2], theInstancesTFIndex[currnode.numchildren-2], theInstancesTF[usedTimepoint][currnode.numchildren-2],
	 		              ylabels[currnode.numchildren-2],currnode.numchildren,currnode.recweight,numbits,regulatorTypes);
	    		
	    	}else{
	      
	      currnode.tranC = new DREM_FastLogistic2(theInstancesIndex[currnode.numchildren-2],
					     theInstances[0][currnode.numchildren-2],
                                             theInstancesTFIndex[currnode.numchildren-2],
                                             theInstancesTF[0][currnode.numchildren-2], 
                                            ylabels[currnode.numchildren-2],
					    currnode.numchildren,dcoeff,numbits, regulatorTypes);
	    	}
	   }
	}

	if (currnode.numchildren == 0)
	{
           return 1;
	}
	else
	{
	   int ndepth;
           currnode.nextptr[0] = new Treenode(currnode);
           currnode.nextptr[0].parent = currnode;
	   ndepth = readInitTreeHelp(currnode.nextptr[0],brinit,numcoeff,bmergedtree);
  	   for (int nchild = 1; nchild < currnode.numchildren; nchild++)
	   {
	      currnode.nextptr[nchild] = new Treenode(currnode);
	      currnode.nextptr[nchild].parent = currnode;
	      if (ndepth != readInitTreeHelp(currnode.nextptr[nchild],brinit,numcoeff,bmergedtree))
	      {
	         throw new IllegalArgumentException("Invalid saved model file.  Two paths are not of the same length.");
	      }
	   }
	   return (ndepth +1);
	}
    }

    
    /**
     * When reading a model with merges from a file some of the states can be listed more than once
     * this procedures makes it so that in the internal representation the state only exists once
     */
    private void mergeDuplicates(Treenode currnode,HashMap createdNodes)
    {
	if (currnode != null)
	{
	    createdNodes.put(new Integer(currnode.nID),currnode);
	    for (int nchild = 0; nchild < currnode.numchildren; nchild++)
	    {
		Treenode tnode = (Treenode) createdNodes.get(new Integer(currnode.nextptr[nchild].nID));
		if (tnode == null)
		{
		    mergeDuplicates(currnode.nextptr[nchild],createdNodes);
		}
		else
	        {
		    currnode.nextptr[nchild] = tnode;
		    if (tnode.parentptrA == null)
		    {
			tnode.parentptrA = new Treenode[2];
			tnode.parentptrA[0] = tnode.parent;
			tnode.parentptrA[1] = currnode;
		    }
		    else
		    {
			Treenode[] temptr = tnode.parentptrA;
			tnode.parentptrA = new Treenode[tnode.parentptrA.length];
			for (int nindex = 0; nindex < temptr.length; nindex++)
			{
			    tnode.parentptrA[nindex] = temptr[nindex];
			}
			tnode.parentptrA[temptr.length-1] = currnode;
		    }
		}
	    }
	}
    }

    /**
     * Loads saved colors for a DREM map
     */
    public void readColors(BufferedReader brinit) throws IOException
    {
	savedColors = new ArrayList();
	String szLine;
	while ((szLine=brinit.readLine()) != null)
	{
	   if (!szLine.trim().equals(""))
	   {
	       StringTokenizer st = new StringTokenizer(szLine,"\t");
	       if (st.countTokens() != 4)
	       {
		   throw new IllegalArgumentException("A color line has "+st.countTokens()+" values expecting 4");
	       }
	       else
	       {
		   float f1,f2,f3,f4;
		   f1 = Float.parseFloat(st.nextToken());
		   f2 = Float.parseFloat(st.nextToken());
		   f3 = Float.parseFloat(st.nextToken());
		   f4 = Float.parseFloat(st.nextToken());
		   savedColors.add(new Color(f1,f2,f3,f4));
	       }
	   }
	}
    }


    //////////////////////////////////////////////////////////////////////
    /**
     * Helper function to traverseanddelayhelp that manipulates a split so that it occurs
     * one time point later
     */
    private Treenode delaysplit(int[] path, int ndesiredlevel, Treenode root,int nchildcombine)
    {
        Treenode treeroot = (Treenode) root.clone();
	Treenode ptr = treeroot;

        for(int nindex = 0; nindex < ndesiredlevel-1; nindex++)
	{
	   ptr = ptr.nextptr[path[nindex]];
	}
	Treenode removeptr = ptr.nextptr[path[ndesiredlevel-1]];
    
        if (!removeptr.bchange)
	{
	    return null;
	}
	else
	{
           for (int nj = path[ndesiredlevel-1]+1; nj < ptr.numchildren; nj++)   
           {
              ptr.nextptr[nj-1] = ptr.nextptr[nj];
           }

           ptr.numchildren--; 
           ptr.binit = false;
	   
	   if (BREGDREM)
           {
              double dsum = 0; 
              for (int nindex = 0; nindex < ptr.numchildren; nindex++)
	      {
	         dsum += ptr.ptrans[nindex]; 
	      }

              for (int nindex = 0; nindex < ptr.numchildren; nindex++)
              {
	         ptr.ptrans[nindex]/=dsum; 
	      }
	   }

	   int ncurrnumchild = ptr.nextptr[nchildcombine].numchildren;

	   Treenode combineptr = ptr.nextptr[nchildcombine];
	   for (int nindex = 0; nindex < removeptr.numchildren ; nindex++)
	   {
               combineptr.nextptr[nindex+ncurrnumchild]= removeptr.nextptr[nindex];
	       removeptr.nextptr[nindex].parent = combineptr;
	   }


	   if (BREGDREM)
	   {
              for (int nindex = 0; nindex < combineptr.numchildren; nindex++)
	      {    
                 combineptr.ptrans[nindex] = combineptr.ptrans[nindex]*0.5; 
	      } 

	      for (int nindex = 0; nindex < removeptr.numchildren; nindex++)
	      { 
		 combineptr.ptrans[nindex+combineptr.numchildren] = removeptr.ptrans[nindex]*0.5;
	      }
	   }
	   combineptr.numchildren += removeptr.numchildren;
	   combineptr.binit = false;
	}
        return treeroot;
    }

    //////////////////////////////////////////////////////////////////////
    /**
     * Deletes a child from the specified path on a cloned version of the root node
     */
    public  Treenode deletepath(int[] path, int ndesiredlevel, Treenode root)
    {
	//used to be call deleteleaf
        Treenode treeroot = (Treenode) root.clone();
	Treenode ptr = treeroot;

        for(int nindex = 0; nindex < ndesiredlevel-1; nindex++)
	{
	   ptr = ptr.nextptr[path[nindex]];
	}
    
        if (!ptr.nextptr[path[ndesiredlevel-1]].bchange)
	{
	    return null;
	}
	else
	{
           for (int nj = path[ndesiredlevel-1]+1; nj < ptr.numchildren; nj++)   
           {
              ptr.nextptr[nj-1] = ptr.nextptr[nj];
           }

           ptr.numchildren--; 
           ptr.binit = false;
	   
	   if (BREGDREM)
           {
              double dsum = 0; 
              for (int nindex = 0; nindex < ptr.numchildren; nindex++)
	      {
	         dsum += ptr.ptrans[nindex]; 
	      }

              for (int nindex = 0; nindex < ptr.numchildren; nindex++)
              {
	         ptr.ptrans[nindex]/=dsum; 
	      }
	   }
	}
        return treeroot;
    } 
   
    ////////////////////////////////////////////////////////////////////////
    /**
     * With its helper functions adds the specified path to the model
     */
    public void traverseandadd(int[] path,Treenode ptr,Treenode origroot) throws Exception
    {
       traverseandaddhelp(path,0,ptr,origroot);
    }
    //////////////////////////////////////////////////////////////////////


    /**
     * Helper function for traverseandaddhelp recursively tries to add paths 
     * to the model, and then evaluates the improvement
     */
    private void traverseandaddhelp(int[] path, int nlevel,
				   Treenode ptr, Treenode origroot) throws Exception
    {
	//searches for the best place to add a node at current level
        //tries adding path at current level       
        if ((nlevel < path.length)&&(!DREM_IO.bendsearch))
	{
	    for (int nindex = 0; nindex < ptr.numchildren; nindex++)
	    {
	       path[nlevel] = nindex;
	       traverseandaddhelp(path,nlevel+1,ptr.nextptr[nindex],origroot);
            }
	}
        
        if (((ptr!=null) &&((ptr.numchildren < nmaxchild)))&&(!DREM_IO.bendsearch))
        {
	   if (DREM_IO.bdisplaycurrent)
	   {
	      displayTempMap();
	   }
	   
	   if (nlevel < path.length)
	   {
	      //mark to try to split
	      if (BDEBUG)
	      {
                 for (int ni =0; ni < nlevel; ni++)
                 {
                    System.out.print(path[ni]+"\t");
                 }
	      }

              Treenode splittree = splitnode(path,nlevel,origroot);  

	      if (BDEBUG)
	      {
                 System.out.println(path[nlevel]);
	      }
       
	      if (splittree != null)
	      {
                 traverse(splittree,0,false);

                 double dlog;
		 if (BVITERBI)
		 {
		     dlog = trainhmmV(splittree,false);
		 }
		 else
		 {
		     dlog = trainhmm(splittree,false);
		 }   


		 if (!bmodeldiff)
		 {
		    if (BVITERBI)
		    {
                       dlog =testhmmV(splittree);
		    }
		    else
		    {
		       dlog =testhmm(splittree);
		    }
		 } 
                 traverse(splittree,0,false);
                 
		 if (BDEBUG)
		 {
                    System.out.println("*test "+dlog);
		 }

		 if ((dlog>dbestlog)&&(bmodeldiff||(dlog-dprevouterbestlog)>EPSILONDIFF))
                 {
                    bestTree = splittree;
                    dbestlog = dlog;
		    dbesttrainlike = dtrainlike;
		    double dimprove = (dbestlog-dprevouterbestlog)/Math.abs(dbestlog);
                    String szimprove = nf3.format(100*dimprove) + "%";
		    String szimproveDIFF = nf3.format(dbestlog-dprevouterbestlog);

		    if (statusLabel3 != null)
		    {
		       statusLabel3.setText(" Next score: "+nf2.format(dbestlog));
		    }

		    if (statusLabel2 != null)
		    {
		       statusLabel2.setText(" Next score improvement: "+szimproveDIFF+" ("+szimprove+")");
		    }
	         }
              }
	   }
	}
    }

    /////////////////////////////////////////////////////////////////////
    /**
     * Helper function for adding a path in traverseandaddhelp. 
     * Responsible for splitting one path out of a node into two. 
     */
    private Treenode splitnode(int[] path, int ndesiredlevel, Treenode origroot) 
    {
       Treenode treeroot = (Treenode) origroot.clone();
       Treenode ptr = treeroot;

       for(int nindex = 0; nindex < ndesiredlevel; nindex++)
       {
	  //advancing pointer to the node from which a new path should be added
          ptr = ptr.nextptr[path[nindex]];
       }
  
       if (!ptr.bchange)
       {
	  return null;
       }
       else
       {
           //increasing the number of children
           ptr.numchildren++;
	   ptr.binit = false;

           //readjusting the transition probabilities
	   ////////////////////////////////////////      
	   
	   if (BREGDREM)
	   {
              for (int nindex = 0; nindex < ptr.numchildren-1; nindex++)
	      {
	      
                 ptr.ptrans[nindex] = ptr.ptrans[nindex]*(ptr.numchildren-1)/(ptr.numchildren); 
	      }  
	      ptr.ptrans[ptr.numchildren-1] = 1.0/(ptr.numchildren);
	     
              if (BDEBUG)
	      {
	         System.out.println("probs A "+ptr.ptrans[0]+"\t"+ptr.ptrans[1]);
	      }
	   }

	   if (ndesiredlevel < path.length)
	   {
	      path[ndesiredlevel] = ptr.numchildren-1; 
	   }
	   ////////////////////////////////////////////////////
	   //more sophisticated initialization schemes possible here
	   ///////////////////////////////////////  
	   for (int nlevel = ndesiredlevel; nlevel <path.length; nlevel++)
	   {
              ptr.nextptr[ptr.numchildren-1]= new Treenode(ptr);
	      if (ptr.numchildren > 1)
	      {  
		  double dk =0.02;
		  double ddiff = ptr.dmean-ptr.nextptr[ptr.numchildren-2].dmean;
		  
		  if (Math.abs(ddiff) < dk*ptr.dsigma)
		  {
		     if (ptr.nextptr[ptr.numchildren-2].dmean > ptr.dmean)
		     {
                        ptr.nextptr[ptr.numchildren-1].dmean = ptr.dmean -
			    (dk*ptr.dsigma - (ptr.nextptr[ptr.numchildren-2].dmean-ptr.dmean));

			if (BDEBUGMODEL)
			{
			   System.out.println("A: MEAN "+ptr.nextptr[ptr.numchildren-1].dmean+" "+
					   ptr.nextptr[ptr.numchildren-2].dmean+" "+ptr.dsigma);
			}
		     }
		     else
		     {
                        ptr.nextptr[ptr.numchildren-1].dmean = ptr.dmean +
			    (dk*ptr.dsigma - (ptr.dmean-ptr.nextptr[ptr.numchildren-2].dmean));

			if (BDEBUGMODEL)
			{
			   System.out.println("B: MEAN "+ptr.nextptr[ptr.numchildren-1].dmean+" "+
					   ptr.nextptr[ptr.numchildren-2].dmean+" "+ptr.dsigma);
			}
		     }
		  }
		  else
		  {
		      ptr.nextptr[ptr.numchildren-1].dmean = ptr.dmean;

		      if (BDEBUGMODEL)
		      {
			System.out.println("C: MEAN "+ptr.nextptr[ptr.numchildren-1].dmean+" "+
                                 ptr.nextptr[ptr.numchildren-2].dmean+" "+ptr.dsigma);
		      }
		  }
	      }
	      else
	      {
	          ptr.nextptr[ptr.numchildren-1].dmean = ptr.dmean;
	      }
	      
	      ptr.nextptr[ptr.numchildren-1].dsigma = ptr.dsigma;

	      
              ptr = ptr.nextptr[ptr.numchildren-1];
              ptr.numchildren = 1;
	      if (BREGDREM)
	      {
                 ptr.ptrans[0] = 1;
	      }
	   }
	   ptr.numchildren = 0;
       }
       return treeroot;     
    }


    //////////////////////////////////////////////////////////////////////
    /**
     * With its helper function finds the path with the fewest genes assigned 
     * this will become a candidate for deletion
     */
    public MinPathRec traverseanddeleteMinPath(int[] path, int[] bestpath, Treenode ptr) throws Exception
    {
	return traverseanddeletehelpMinPath(path,0,ptr);
    }

    //////////////////////////////////////////////////////////////////////
    /**
     * A record used for storing the path with the fewest genes assigned
     */
    static class MinPathRec
    {
	int nval;
	int nlevel;
	int[] bestpath;

	MinPathRec(int nval, int nlevel, int[] bestpath)
	{
	    this.nval = nval;
	    this.nlevel = nlevel;
	    this.bestpath = bestpath;
	}
    }

    /**
     * Deletes the specificed path from the model starting from ndesiredlevel
     */
   public void deleteMinPath(int[] path, int ndesiredlevel, Treenode root)
    {
	Treenode ptr = root;

        for(int nindex = 0; nindex < ndesiredlevel-1; nindex++)
	{
	   ptr = ptr.nextptr[path[nindex]];
	}
    
        for (int nj = path[ndesiredlevel-1]+1; nj < ptr.numchildren; nj++)   
        {
           ptr.nextptr[nj-1] = ptr.nextptr[nj];
	}

        ptr.numchildren--; 
        ptr.binit = false;
	   
	if (BREGDREM)
	{
           double dsum = 0; 
           for (int nindex = 0; nindex < ptr.numchildren; nindex++)
	   {
	      dsum += ptr.ptrans[nindex]; 
	   }

           for (int nindex = 0; nindex < ptr.numchildren; nindex++)
	   {
	      if (dsum > 0)
	      {
	         ptr.ptrans[nindex]/=dsum; 
	      }
	      else
	      {
	         ptr.ptrans[nindex] = 0;
	      }
	   }
	}	
    } 

    /**
     * Recursively searches for the path with the fewest genes assigned this will become a candidate
     * for deletion
     */
    private MinPathRec traverseanddeletehelpMinPath(int[] path, int nlevel,
                                           Treenode ptr) throws Exception
    {
       int nmin = Integer.MAX_VALUE;
       if (nlevel < path.length)
       {
	  MinPathRec theminMinPathRec=null;
          for (int nindex = 0; nindex < ptr.numchildren; nindex++)
	  {
	     path[nlevel] = nindex;
	     MinPathRec thetempMinPathRec
                   = traverseanddeletehelpMinPath(path,nlevel+1,ptr.nextptr[nindex]);

	     if (thetempMinPathRec.nval < nmin)
	     {
	        nmin = thetempMinPathRec.nval;
	        theminMinPathRec = thetempMinPathRec;
	        theminMinPathRec.bestpath[nlevel] = nindex;
		if (thetempMinPathRec.nval == ptr.numPath)
		{
		    thetempMinPathRec.nlevel = nlevel;
		}
	     }
          }
	  return theminMinPathRec;
       }
       else
       {
	   MinPathRec theMinPathRec = new MinPathRec(ptr.numPath,nlevel,new int[path.length]);
	   return theMinPathRec;
       }
    }

    
    ////////////////////////////////////////////////////////////////////////////
    /**
     * With its helper method traverseanddelayhelp
     * searches for splits to delay one time point
     * Returns true if an eligible split to delay was found
     */
    public boolean traverseanddelay(int[] path, Treenode ptr,int ndesiredlevel, 
                                    Treenode origroot,boolean bresplit) throws Exception
    {
	if (BDEBUG)
	{
	   System.out.println("entering traverse and delay");
	}
	return traverseanddelayhelp(path,0,ndesiredlevel,ptr,origroot,bresplit,0);
    }


    /////////////////////////////////////////////////////////////////////////////
    /**
     * Recursively searches for splits to delay one time point
     */
    private boolean traverseanddelayhelp(int[] path, int nlevel,int ndesiredlevel,
			  Treenode ptr, Treenode origroot,boolean bresplit,int nchild) throws Exception
    {

       if (BDEBUG)
       {
          System.out.println("traverseanddelayhelp "+ndesiredlevel+" "+ndesiredlevel);
       }

       boolean breturnval = false;
       if ((nlevel < path.length-1)&&(nlevel<ndesiredlevel))
       {
          for (int nindex = 0; nindex < ptr.numchildren; nindex++)
	  {
	     if (DREM_IO.bdisplaycurrent)
	     {
	        displayTempMap();
	     }
	     path[nlevel] = nindex;
	     boolean breturnvaltemp;
	     breturnvaltemp = traverseanddelayhelp(path,nlevel+1,ndesiredlevel,
                                 ptr.nextptr[nindex],origroot,bresplit,nindex);
	     breturnval = breturnval || breturnvaltemp;
          }
       }

       //assuming ptr.parent also not null
       if ((ptr !=null)&&(nchild >= 1)&&(nlevel==ndesiredlevel))
       {
          for (int nchildcombine =0; nchildcombine < nchild; nchildcombine++)
	  {
	     if (ptr.numchildren + ptr.parent.nextptr[nchildcombine].numchildren <= nmaxchild)
	     {
	        double dabsmeandiff = Math.abs(ptr.dmean-ptr.parent.nextptr[nchildcombine].dmean);
		NumberFormat nf4 = NumberFormat.getInstance();
		nf4.setMinimumFractionDigits(4);
	        nf4.setMaximumFractionDigits(4);
		if (BDEBUG)
		{
		   System.out.println(nlevel+" "+nf4.format(ptr.dmean)+" "
                                     +nf4.format(ptr.parent.nextptr[nchildcombine].dmean)+" "
				     +nf4.format(dabsmeandiff)+" "+nf4.format(ptr.dsigma)+" "+
                                     nf4.format(ptr.parent.nextptr[nchildcombine].dsigma));
		   System.out.println("-----------");
		}

  	        //mark to try to delete
		if (BDEBUG)
		{
		   System.out.print("dy ");
	           for (int ni =0; ni <nlevel; ni++)
	           {
  	              System.out.print(path[ni]+" ");
		   }
	           System.out.println();
       	           System.out.println("before");
		}

	        traverse(origroot,0, false);
                Treenode delaytree = delaysplit(path,nlevel,origroot,nchildcombine);  

                if (delaytree != null)
	        {
                   double dlog;	      
	           if (BVITERBI)
	           {
                      dlog = trainhmmV(delaytree,true);
		   }
	           else
	           {
		       dlog = trainhmm(delaytree,true);
		   }

		   if (!bmodeldiff)
		   {
		      if (BVITERBI)
		      { 
                         dlog = testhmmV(delaytree);
		      }
		      else
 		      {
                         dlog = testhmm(delaytree);
		      }
		   }

		   if (BDEBUG)
		   {
                      System.out.println("after "+dlog);
		   }
		   traverse(delaytree,0, false);

		   if (BDEBUG)
		   {
                      System.out.println("test "+dlog);
		   }

		   double ddelayimprove = (dlog-dprevouterbestlog)/Math.abs(dlog);

	           if (BDEBUG)
	           {
		      System.out.println("DELAY\t"+dlog+"\t"+dbestlog+"\t"+
                                        ddelayimprove+"\t"+(dlog-dprevouterbestlog)/Math.abs(dlog)+"\t"+DELAYMIN);
		   }

		   if (BDEBUG)
		   {
		      System.out.println("delay = "+ddelayimprove+"\t"+DELAYMIN);
		   }

		   if ((((dlog+DELAYMIN*Math.abs(dlog)-dprevouterbestlog)>=DELAYMINDIFF)
                      &&(dlog>dbestlog)&&!bmodeldiff)||
		       ((bmodeldiff)&&(dlog >= dprevouterbestlog)&&(dlog>dbestlog)))
                   {
                      bestTree = delaytree;
                      dbestlog = dlog;
		      if (BDEBUG)
		      {
		         System.out.println("in delay "+dbestlog);
		      }
			    
		      double dimprove = (dbestlog-dprevouterbestlog)/Math.abs(dbestlog);
                      String szimprove = nf3.format(100*dimprove) + "%";
		      String szimproveDIFF = nf3.format(dbestlog-dprevouterbestlog);
		      if (statusLabel2 != null)
		      {
	                 statusLabel2.setText(" Delay next change: "+szimproveDIFF+" ("+szimprove+")"+
                                       " (Score "+nf2.format(dbestlog)+")");

		      }
			    
	              dbesttrainlike = dtrainlike;
		      breturnval = true;
		   }
		}
	     }
	  }
       }
       return breturnval;
    }

    
    //////////////////////////////////////////////////////////////////////
    /**
     * With its helper function searches for the best path to delete
     * Returns true if an eligible path to delete was found
     */
    public boolean traverseanddelete(int[] path, Treenode ptr, 
				  Treenode origroot,boolean bresplit,
				     double dimprovemin,double dimprovemindiff) throws Exception
    {
	return traverseanddeletehelp(path,0,ptr,origroot,
                                     bresplit,dimprovemin,dimprovemindiff);
    }

    //////////////////////////////////////////////////////////////////////
    /**
     * Helper function that searches for the best path to delete
     */
    private boolean traverseanddeletehelp(int[] path, int nlevel,
	      Treenode ptr, Treenode origroot,boolean bresplit,
	      double dimprovemin,double dimprovemindiff) throws Exception
    {
		
       boolean breturnval = false;
       if (nlevel < path.length)
       {
          for (int nindex = 0; nindex < ptr.numchildren; nindex++)
	  {
	     if (DREM_IO.bdisplaycurrent)
	     {
	        displayTempMap();
	     }
	       
	     path[nlevel] = nindex;
	     boolean breturnvaltemp = 
                         traverseanddeletehelp(path,nlevel+1,ptr.nextptr[nindex],
			    origroot,bresplit,dimprovemin,dimprovemindiff);
	     breturnval = (breturnvaltemp || breturnval);
          }
       }

       if ((ptr !=null)&&(ptr.parent!=null)&&(ptr.parent.numchildren > 1))
       {
          if (BDEBUG)
	  {
	     //mark to try to delete
	     for (int ni =0; ni <nlevel; ni++)
	     {
	        System.out.print(path[ni]+" ");
	     }
	     System.out.println();
	  }

          Treenode deletetree = deletepath(path,nlevel,origroot);  

          if (deletetree != null)
	  {
	     double dlog;

	     if (BVITERBI)
	     {
		 dlog = trainhmmV(deletetree,false);
	     }
	     else
	     {
		 dlog = trainhmm(deletetree,false);
	     } 

	     if (!bmodeldiff)
	     {
	        if (BVITERBI)
	        {
		   dlog = testhmmV(deletetree);
	        }
	        else
	        {
		   dlog =testhmm(deletetree);
	        }
	     }

	     if (BDEBUG)
	     {
                System.out.println("test "+dlog);
	     }

	     double dimprovedelete = (dlog-dprevouterbestlog)/Math.abs(dlog);
	     if (BDEBUG)
	     {
	        System.out.println("del* "+dimprovedelete+"\t"+dimprovemin+"\t"+(dlog-dprevouterbestlog));
		System.out.println("~~"+dlog+"\t"+dbestlog+"\t"+dprevouterbestlog);
	     
	        System.out.println("DELETE\t"+dlog+"\t"+dbestlog+"\t"+dimprovedelete+
                         "\t"+(dlog-dprevouterbestlog)/Math.abs(dlog)+"\t"+dimprovemin);
	     }

	     if ((((dlog+dimprovemin*Math.abs(dlog)-dprevouterbestlog)>=dimprovemindiff)
                      &&(dlog>dbestlog)&&!bmodeldiff)||
		 (bmodeldiff && (dimprovemin>=dprevouterbestlog)&&(dlog>dbestlog)))

             {
                bestTree = deletetree;
                dbestlog = dlog;
		if (BDEBUG)
		{
		   System.out.println("in delete "+dbestlog);
		}

		if (!bresplit)
		{
		   double dimprove = (dbestlog-dprevouterbestlog)/Math.abs(dbestlog);
                   String szimprove = nf3.format(100*dimprove) + "%";
		   String szimproveDIFF = nf3.format((dbestlog-dprevouterbestlog));
		   if (statusLabel3 != null)
		   {
	              statusLabel3.setText(" Next score: "+nf2.format(dbestlog));
		   }

		   if (statusLabel2 != null)
		   {
	              statusLabel2.setText(" Next score improvement: "+szimproveDIFF+" ("+szimprove+")");
		   }
		}
		else
		{
		   double dimprove = (dbestlog-dprevouterbestlog)/Math.abs(dbestlog);
                   String szimprove = nf3.format(100*dimprove) + "%";
		   String szimproveDIFF = nf3.format((dbestlog-dprevouterbestlog));

		   if (statusLabel2 != null)
		   {
	              statusLabel2.setText(" Delete path change : "+szimproveDIFF+" ("+szimprove+")");
		   }
		}
	        dbesttrainlike = dtrainlike;
		breturnval = true;
	     }
          }
       }

       return breturnval;
    }



    ///////////////////////////////////////////////////////////////////////
    /**
     * Prints the most significant TF-association scores for each TF
     */
    private void printMinPvals()
    {
	double[] bestpsplit = new double[tfNames.length];
	double[] bestpfull = new double[tfNames.length];

	int[] bestsplitdepth = new int[tfNames.length];
	int[] bestfulldepth = new int[tfNames.length];

	for (int ni = 0; ni < bestpsplit.length; ni++)
        {
	    bestpsplit[ni] = 1;
	}

	for (int ni = 0; ni < bestpsplit.length; ni++)
        {
	    bestpfull[ni] = 1;
	}

	getMinPvals(treeptr, bestpsplit, bestpfull,bestsplitdepth,bestfulldepth,1);

        try
        {
           PrintWriter pw = new PrintWriter(new FileOutputStream(SCORESDIR+"/"+nrandomseed+".txt"));
	   for (int ni = 0; ni < tfNames.length; ni++)
	   {
	      pw.println(tfNames[ni]+"\t"+bestpfull[ni]+"\t"+bestpsplit[ni]
                         +"\t"+bestfulldepth[ni]+"\t"+bestsplitdepth[ni]);
	   }
	   pw.close();
        }
        catch (IOException ioex)
        {
	   ioex.printStackTrace(System.out);
        }
    }


    /**
     * Helper procedure for getting the most significant TF-association scores for each TF
     */
    private void getMinPvals(Treenode ptr, double[] bestpsplit, double[] bestpfull,
			    int[] bestsplitdepth, int[] bestfulldepth, int ndepth)
    {
	if (ptr.numchildren >=1)
	{
	    for (int nchild = 0; nchild < ptr.numchildren; nchild++)
	    {
	       if (ptr.dpvalEdgeSplit != null)
	       {
	          for (int ni = 0; ni < bestpsplit.length; ni++)
	          {
		     if (ptr.dpvalEdgeSplit[nchild][ni] < bestpsplit[ni])
		     {
		        bestpsplit[ni] = ptr.dpvalEdgeSplit[nchild][ni];
		        bestsplitdepth[ni] = ndepth;
		     }
		  }
	       }

  	       if (ptr.dpvalEdgeFull.length >= 1)
	       {
	          for (int ni = 0; ni < bestpfull.length; ni++)
	          {
		     if (ptr.dpvalEdgeFull[nchild][ni] < bestpfull[ni])
		     {
	  	        bestpfull[ni] = ptr.dpvalEdgeFull[nchild][ni];
		        bestfulldepth[ni] = ndepth;
		     }
		  }
	       }

	       getMinPvals(ptr.nextptr[nchild], bestpsplit, bestpfull,
			bestsplitdepth, bestfulldepth, ndepth+1);
	    }
	}
    }


    //////////////////////////////////////////////////////////////////////
    /**
     * A Treenode corresponds to a state in the model 
     */
    class Treenode
    {
       int ncurrtime;//use to count visited
       int nID;
       int niteration;
       int ninstanceiteration;
       int nrec;
       int ninstancerec;
       int nminparentlevel;
       Treenode minparentptr;
       int timepoint; //IMPORTANT this needs to be read in and saved in the model file as well!!!!

       Treenode[] parentptrA;
       int numdownleaves;  //number of leaves descendants of this node, only relevant if split
       double dens;
       double dEsum; //expected sum of the emissions from this node  
       double dEsumsq; //expected sum of the square of emissions from this node
       double dPsum;
       double dmean;  //emission mean
       double dsigma; //emission std
       double dpredictweight;
       String szgolabel="";
       String szgenesetlabel = "";
       String sztfsetlabel = "";
       int nprime; //non zero recs
       int numchildren; //number of children
       boolean bchange;  //can change state's values
       int ndepth;
       int nparentcolorindex;
       boolean[] bvector;

       DREM_FastLogistic2 tranC;
       double[] recweight;
       double[] dTotalScore;
       double[][] dpvals;
       int[] orderA;
       int[][][] ncountvals;
       int[][][] nothersum;
       double[][] dscoreother;
       double[][] dscore;
       double[][] ddiff;
       TreeSet tsSigTF;
       TreeSet[] tsSigTFEdgeSplit;
       TreeSet[] tsSigTFFull;
       Hashtable[] htScore;
       int[][] ncountTotals;
       double[][] dpvalEdgeSplit;
       double[][] ddiffEdgeSplit;
       double[][] dpvalEdgeFull;
       double[][] ddiffEdgeFull;
       double[][] dexpectEdgeFull;
       double[][] dexpectEdgeSplit;
       double[][] dratioSplit;

       boolean[] bInNode;
       int numPath;
       double[] ptrans;//probability of transitioning 
                       //to each of the next states
       double[] aprobs;  //expected number of transitions 
	                 //given the training sequences
       Treenode[] nextptr;//pointer to each of the next states
       Treenode parent; //pointer back to the parent  

       PText thepredictText;
       PText goText;
       PText genesetText;
       PText tfsetText;
       public String SigRegulators = "";
       //forward and backward variables for current variables
       double df;  //p(x_1,...,x_i,pi_i=k)
       double db; //p(x_(i+1),...,x_L|pi_i=k) 
       boolean binit; 

	/**
	 * Calls inittreenode with a null parent
	 */
       Treenode()
       {
          inittreenode(null);
       }


       Treenode(Treenode parent)
       {
          inittreenode(parent);
       }

	/**
	 * Calls inittreenode with parent
	 */
       void inittreenode(Treenode parent)
       {
	  niteration = 0;
	  ninstanceiteration = 0;
	  nrec = -1;
          dmean = 0;
          dsigma = .5;
          this.parent = parent;   
          dEsum = 0;
          dEsumsq = 0;
	  dPsum =0;
          nprime = 0;
          bchange = true;
	  binit = false;
	  if (parent == null)
	  {
	      ndepth = 0;
	  }
	  else
	  {
              ndepth = parent.ndepth +1;
	  }
          nextptr = new Treenode[nmaxchild];

	 
	  if (BREGDREM)
	  {
             ptrans   = new double[nmaxchild];
             aprobs = new double[nmaxchild];
	  }

          bvector = new boolean[numbits];

	  if (bindingpvalGene != null)
	  {
	      dTotalScore = new double[numbits];
	  }

	  int numPath;

	  for (int nindex = 0; nindex < numbits; nindex++)
	  {
	      bvector[nindex] = false;
	  }

          numchildren = 0; 
          for (int nindex = 0; nindex < nextptr.length; nindex++)
          {
	     nextptr[nindex] = null;
	  }
       } 

	/**
	 * For making copy of nodes
	 */
       public Object clone()
       {
          if (parent == null)
	  {
	     if (BDEBUG)
	     {
	        System.out.println("in clone........");
	     }
	     htBackPts = new Hashtable();
	  }

	  Treenode tnode = new Treenode();
	  tnode.nID = nID;
          tnode.dmean = dmean;
          tnode.dsigma = dsigma;
          
	  tnode.ndepth = ndepth;
          tnode.dEsum = dEsum;
          tnode.dEsumsq = dEsumsq;
	  tnode.dPsum = dPsum;
          tnode.nprime = nprime;
          tnode.numchildren = numchildren;

	  tnode.thepredictText = thepredictText;
          tnode.parent = null;  
	  tnode.bchange = bchange;
          tnode.df =df;  
          tnode.db = db;
	  tnode.binit = binit;
          tnode.nextptr = new Treenode[nmaxchild];

	  if (BREGDREM)
	  {
             tnode.ptrans   = new double[nmaxchild];
             tnode.aprobs = new double[nmaxchild];
	  }
	  else if (tranC != null)
	  {
	     tnode.tranC =  (DREM_FastLogistic2) tranC.clone();  //do we need a clone yes
	  }

	  tnode.recweight = new double[recweight.length];
	   

          for (int nindex = 0; nindex < nextptr.length; nindex++)
          {
	     if (nextptr[nindex] == null)
	     {
	        tnode.nextptr[nindex] = null;
	     }
	     else
	     {
	        BackPtrRec childNodeRec = (BackPtrRec) htBackPts.get(nextptr[nindex]);

		if (childNodeRec != null)
	        {
	           //we've already cloned the child node, just have it link to it
		   tnode.nextptr[nindex] = childNodeRec.childNode;
	           //have the child link back to this node
		   if (BDEBUG)
		   {
		      System.out.println("[["+
                           childNodeRec+" "+childNodeRec.childNode+" "+childNodeRec.childNode.parentptrA);
		   }
		     
                   int nfindparentindex = 0;
		   while (nextptr[nindex].parentptrA[nfindparentindex] != this)
	           {
			 nfindparentindex++;
		   }
		     if (BDEBUG)
		     {
		        System.out.println("nfindparentindex = "+nfindparentindex);
		     }
                     childNodeRec.childNode.parentptrA[nfindparentindex] = tnode;
		}
		 else
		 {
		     //cloning a new node
	            tnode.nextptr[nindex] = (Treenode) nextptr[nindex].clone();
                    tnode.nextptr[nindex].parent = tnode;

		    if (nextptr[nindex].parentptrA != null)
		    {
			tnode.nextptr[nindex].parentptrA = new Treenode[nextptr[nindex].parentptrA.length]; 
		       for (int nparentindex =0; nparentindex < 
                                              nextptr[nindex].parentptrA.length; nparentindex++)
		       {
			  if (nextptr[nindex].parentptrA[nparentindex] == this)
		 	  {
			      if (BDEBUG)
			      {
			         System.out.println("~~``"+tnode.nextptr[nindex].dmean+" "+
                                                 nparentindex);
			      }
 			     tnode.nextptr[nindex].parentptrA[nparentindex] = tnode;
			  }
		       }

		       if (nextptr[nindex].parentptrA.length >= 2)
		       {
		          if (BDEBUG)
			  {
			     System.out.println(dmean+" "+nextptr[nindex].dmean);
			  }
			  htBackPts.put(nextptr[nindex], new BackPtrRec(tnode.nextptr[nindex]));
		       }
		    }
		 }
	      }
	      
	      if (BREGDREM)
	      {
                 tnode.ptrans[nindex] = ptrans[nindex];
	         tnode.aprobs[nindex] =aprobs[nindex];
	      }
	   }

	   tnode.bvector = new boolean[numbits];
	   for (int nindex = 0; nindex < numbits; nindex++)
	   {
	       tnode.bvector[nindex] = bvector[nindex];
	   }

           return tnode;
	}
    }

    /**
     * A record with information about a state a back pointer points to
     */
    static class BackPtrRec
    {
	BackPtrRec(Treenode childNode)
	{
	    this.childNode = childNode;
	}
	Treenode childNode;
    }

    /////////////////////////////////////////////////////////////////////
    /**
     * Returns true iff treeptr or a descendent has two or more parents
     */
    public boolean hasMerge(Treenode treeptr)
    {
	boolean bhasmerge = ((treeptr.parentptrA != null) && (treeptr.parentptrA.length >= 2));
	for (int nchild = 0; (nchild < treeptr.numchildren)&&(!bhasmerge); nchild++)
	{
	    bhasmerge = hasMerge(treeptr.nextptr[nchild]);
	}

	return bhasmerge;
    }

    //////////////////////////////////////////////////////////////////////
    /**
     * Returns a string with the model parameters
     */
    public String saveString(Treenode treecopy)
    {
	StringBuffer szbuf = new StringBuffer("");;

	bhasmerge = hasMerge(treecopy);

	if (bhasmerge)
	{
	    szbuf.append("MERGED TREE\n");
	}

	if (BREGDREM)
	{
           szbuf.append("REGDREM Num. Coefficients\t"+tfNames.length+"\n");
	}
	else
	{
           szbuf.append("Num. Coefficients\t"+tfNames.length+"\n");
	}

	HashMap ptrMap = new HashMap();
	ntotalID = -1;
        szbuf.append(saveStringHelp(treecopy,ptrMap));
	return szbuf.toString();
    }

    /**
     * Helper function for generating a string with model parameters
     * that traverses all the states
     */
    private StringBuffer saveStringHelp(Treenode ptr,HashMap ptrMap)
    {
	StringBuffer szbuf = new StringBuffer();
	if (ptr != null)
	{
	   if (bhasmerge)
	   {
	       Integer obj = (Integer) ptrMap.get(ptr);
	       int nID;
	       if (obj != null)
	       {
		   nID = obj.intValue();
	       }
	       else
	       {
		   ntotalID++;
		   nID = ntotalID;
		   ptrMap.put(ptr,new Integer(nID));
	       }
	       szbuf.append(nID+"\t");
	   }

	   szbuf.append(ptr.dmean+"\t"+ptr.dsigma+"\t"+ptr.numchildren+"\n");
	   if (ptr.numchildren > 1)
	   {
	       if (BREGDREM)
	       {
		   for (int nchild = 0;nchild < ptr.numchildren; nchild++)
		   {
		       szbuf.append(ptr.ptrans[nchild]+"\n");
		   }  
	       }
	       else
	       {
	          szbuf.append(ptr.tranC.saveClassifier(tfNames));
	       }

	   }

           for (int nindex = 0; nindex < ptr.numchildren; nindex++)
	   {
              if (ptr.nextptr[nindex] != null)
	      {
		  szbuf.append(saveStringHelp(ptr.nextptr[nindex],ptrMap));
	      }
	  }
	}

	return szbuf;
    }


    //////////////////////////////////////////////////////////////////////
    /**
     * Record of information about predictions
     */
    static class PredictRec
    {
	double[] mean;
	double[] meansq;
	double[] var;
	double[] entropy;
    }


    /**
     * Used to set probability of each state a gene with a TF-binding signature of binding will be in
     * Also computes a record of other statistics based on these predictions
     */
    public PredictRec predictTime(int[] binding, double dclassprob,DREM_Timeiohmm.Treenode treeptr) throws Exception
    {
	PredictRec thePredictRec = new PredictRec();
	thePredictRec.mean = new double[traindata[0].length];
	thePredictRec.var = new double[traindata[0].length];
	thePredictRec.meansq = new double[traindata[0].length];
	thePredictRec.entropy = new double[traindata[0].length];
	predictTimeHelp(treeptr,binding,dclassprob,0,
                        thePredictRec.mean,thePredictRec.var, 
                        thePredictRec.meansq,thePredictRec.entropy);

	return thePredictRec;

    }


    /**
     * A recursive helper function to predictTime
     */
    private void predictTimeHelp(Treenode node, int[] theInstance, double dweight,
				int nstep,double[] meanpredict, double[] varpredict,
                                double[] meansqpredict,double[] entropypredict)  throws Exception
    {
        if (nstep < meanpredict.length)
	{
	    NumberFormat nf1 = NumberFormat.getInstance(Locale.ENGLISH);

	    if (dweight < 1)
	    {
	       nf1.setMaximumIntegerDigits(0);
	       nf1.setMinimumFractionDigits(2);
	       nf1.setMaximumFractionDigits(2);
	    }
	    else
	    {
	       nf1.setMinimumFractionDigits(1);
	       nf1.setMaximumFractionDigits(1);
	    }
	    node.dpredictweight = dweight;

	    if (node.thepredictText != null)
	    {
	       node.thepredictText.setText(nf1.format(dweight));
	    }

            meanpredict[nstep] += dweight * node.dmean;
	    varpredict[nstep] +=  Math.pow(dweight*node.dsigma, 2);
	    meansqpredict[nstep] += dweight*node.dmean*node.dmean;
	    entropypredict[nstep] -= dweight*Math.log(dweight)/Math.log(2);

	    if (node.binit)
	    {
	       double[] pdist;
 	       if (BREGDREM)
	       {
	          pdist = node.ptrans;
	       }
 	       else
	       {
		  pdist = node.tranC.distributionForInstance(theInstance,-1);
	       }

	       if (BDEBUG)
	       {
	          if (pdist.length==1)
		     System.out.println("warning "+pdist[0]);
	       }

  	       for (int nchild = 0; nchild < node.numchildren; nchild++)
	       {
	          predictTimeHelp(node.nextptr[nchild],theInstance,
				 dweight*pdist[nchild],nstep+1,meanpredict,varpredict,meansqpredict,entropypredict);
	       }
	    }
	    else
	    {
	       predictTimeHelp(node.nextptr[0],  theInstance,dweight,nstep+1,meanpredict,varpredict,
                               meansqpredict,entropypredict);
	    }
	}
    }



    ///////////////////////////////////////////////////////////////////////
    /**
     * Used for debugging to see the contents of the model
     */
    public void traverse(Treenode root, int ndepth, boolean bprintC) 
    {
       if (BDEBUG)
       {
          for (int nindex =0; nindex < ndepth; nindex++)
	  {
	     System.out.print("\t");
	  }
	
          System.out.print(root.numPath+"\t"+root.dmean+"\t"+root.dsigma+"\t"+	       
                           root.numchildren+"\t"+root.binit+"\t"+
			   root.dpredictweight+"\t"+root.ndepth+"\t#"+root.numdownleaves+"\t");

	   if (root.parent != null)
	       System.out.print("p "+root.parent.dmean);

	   if (root.parentptrA != null)
	   {
	       for (int i = 0; i < root.parentptrA.length; i++)
		   System.out.print("\t"+nf2.format(root.parentptrA[i].dmean));
	   }

	   if (root.ptrans != null)
	      System.out.print("\t"+root.ptrans[0]+"\t"+root.ptrans[1]);

  	   for (int nindex =ndepth; nindex < theDataSet.data[0].length-1; nindex++)
	   {
	      System.out.print("\t");
	   }

           if (root.nextptr[0] != null)
	   {
	      System.out.println();

	      if ((bprintC)&&(root.numchildren > 1))
	      {  
	         System.out.println(root.tranC);    
	      }
	   }
  	   else
	   {  
	      System.out.println();
	   }

           for (int nindex = 0; nindex < root.numchildren; nindex++)
	   {
              if (root.nextptr[nindex] != null)
	      {
		traverse(root.nextptr[nindex], ndepth+1, bprintC);
	      }
	   }
	}
    }

    /////////////////////////////////////////////////////////////////////////


    /**
     * Combines the results of the forward and backward algorithm to obtain the probability of
     * each gene going through each state when using viterbi training
     */
    public void instanceAEV(Treenode root,double[] vals,int[] pma, int[] bpvals,int[] bestpath,
                            double dpj,int nrec) throws Exception
    {
       Treenode tempptr = root;

       for (int ndepth = 0; ndepth < bestpath.length; ndepth++)
       {
	  tempptr.dEsum += vals[ndepth]; 
          tempptr.dPsum += 1;
          tempptr.dEsumsq += Math.pow(vals[ndepth],2);
          tempptr.nprime++;

	  if (BREGDREM)
	  {
             tempptr.aprobs[bestpath[ndepth]]++;
	  }

       	  if (tempptr.numchildren >= 1)
	  {
             tempptr.recweight[tempptr.numchildren*nrec+bestpath[ndepth]] = 1;
	  }

	  tempptr = tempptr.nextptr[bestpath[ndepth]];
       }
    }

    ///////////////////////////////////////////////////////////////////////////////////
    /**
     * Initializes all the fields that will be used by instanceAE
     */
    public void initAE(Treenode root)
    {
       if (root != null)
       {
          for (int nchild = 0; nchild < root.numchildren; nchild++)
	  {
	     if (BREGDREM)
	     {
	        root.aprobs[nchild] = 0;
	     }
	     initAE(root.nextptr[nchild]);             
	  }

	  if ((root.recweight==null)|| (root.recweight.length != root.numchildren*traindata.length))
	  {
	      root.recweight = new double[root.numchildren*traindata.length];
      	  }

          root.dEsum = 0;
          root.dEsumsq = 0;
          root.dPsum = 0;
	  root.nprime = 0;
	  root.niteration = 0;
	  root.ninstancerec = 0;
	  root.ninstanceiteration = 0;
	  root.nrec = -1;
       }
    }


    /**
     * Combines the results of the forward and backward algorithm to obtain the probability of
     * each gene going through each state when using baum-welch training
     */
    public void instanceAE(Treenode root,int ndepth,double[] vals,int[] pma, int[] bpvals,
                           double dpj,int nrec) throws Exception
    {
	
	if ((root.ninstancerec != nrec)||(root.ninstanceiteration != nglobaliteration))
	{
	    root.ninstanceiteration = nglobaliteration;
	    root.ninstancerec = nrec;

            if (root.nextptr[0] != null)
	    {
	       for (int nchild = 0; nchild < root.numchildren; nchild++)
               {
                  double dmultval = root.nextptr[nchild].df *
		                  root.nextptr[nchild].db/dpj;

		  //P(A,B)P(C|B)=P(A,B)P(C|A,B)=P(A,B,C)
		    
		  //double df;  //p(x_1,...,x_i,pi_i=k)
		  //double db; //p(x_(i+1),...,x_L|pi_i=k)
		  //p(x_1,...,x_L,pi_i=k)
		  //=p(x_1,...,x_i,pi_i=k)*p(x_(i+1),...,x_L|x_1,...,x_i,pi_i=k)
		  //=p(x_1,...,x_i,pi_i=k)*p(x_(i+1),...,x_L|pi_i=k)
		  //p(x_1,...,x_L) = p(pi_i=k|x_1,...x_L)
                  root.recweight[root.numchildren*nrec+nchild] = dmultval;

		  if (BREGDREM)
		  {
                     root.aprobs[nchild] += dmultval;
		  }

		  instanceAE(root.nextptr[nchild],ndepth+1,vals,pma,bpvals,dpj,nrec);             
	       }
	    }
	   
	    double dweight =root.df*root.db/dpj;
            if ((dweight > 0)&& (pma[ndepth] != 0)&&(!Double.isInfinite(dweight)))
	    {
	       double dtemp = 0;

               root.dEsum += vals[ndepth]*dweight;
	       root.dPsum += dweight;
	       root.dEsumsq +=vals[ndepth]*vals[ndepth]*dweight;
	       root.nprime++;
	    }
	}
    }

    /////////////////////////////////////////////////////////////////////////
    /**
     * Initializes all the fields that will be used by instanceAEV
     */
    public void initAEV(Treenode root)
    {
       if (root != null)
       {
	  if (BREGDREM)
	  {
             for (int nchild = 0; nchild < root.aprobs.length; nchild++)
	     {
	        root.aprobs[nchild] = 0;
	     }
	  }

          for (int nchild = 0; nchild < root.numchildren; nchild++)
	  {
	     if (BREGDREM)
	     {
	        root.aprobs[nchild] = 0;
	     }
	     initAEV(root.nextptr[nchild]);             
	  }


	  if ((root.recweight==null)|| (root.recweight.length != root.numchildren*traindata.length))
	  {
	      root.recweight = new double[root.numchildren*traindata.length];
      	  }
	  else
	  {
	      for (int i=0; i < root.recweight.length; i++)
	      {
		  root.recweight[i] = 0;
	      }
	  }

          root.dEsum = 0;
          root.dEsumsq = 0;
          root.dPsum = 0;
	  root.nprime = 0;
       }
    }

    ////////////////////////////////////////////////////////////////////////
    /**
     * Forces children of a parent to both have the average of their standard
     * deviations
     */
    public void averageChildrenSigmas(Treenode root)
    {
       if (root.numchildren >=2)
       {
          double dsigmasum = 0;
	  double dpsum = 0;
          for (int nchild = 0; nchild< root.numchildren; nchild++)
          {
	     dsigmasum +=  root.nextptr[nchild].dPsum*root.nextptr[nchild].dsigma;
	     dpsum += root.nextptr[nchild].dPsum;
	     if (BDEBUG)
	     {
	        System.out.println("##"+root.nextptr[nchild].dsigma+"\t"+root.nextptr[nchild].dPsum);
	     }
	  }
	  double dsigmaavg = dsigmasum/dpsum;
	  if (BDEBUG)
	  {
             System.out.println("&&&"+dpsum+"\t"+root.dPsum+"\t"+dsigmasum+"\t"+dsigmaavg);
	  }

          for (int nchild = 0; nchild< root.numchildren; nchild++)
          {
	     root.nextptr[nchild].dsigma = dsigmaavg;
	  }
       }

       for (int nchild = 0; nchild< root.numchildren; nchild++)
       {
          averageChildrenSigmas(root.nextptr[nchild]);
       }   
    }

    /////////////////////////////////////////////////////////////////////////

    /**
     * Updates the mean, standard deviation, and classifier parameters
     * based on the current expectation of which genes will go through which paths
     */
    public void updateParams(Treenode root, int nchildnum, double[][] data,int[][] pma, int ndepth) 
                                                                       throws Exception
    {
        if (!root.bchange)
	{
	    //not allowed to change states params
	    //maybe we can get rid of this below
	    //since if there is no change in root can assume all children not changeable
  	   if (root.nextptr[0] != null)
	   {
	      for (int nchild = 0; nchild< root.numchildren; nchild++)
	      {
		  updateParams(root.nextptr[nchild],nchild,data,pma, ndepth+1);
	      }
	   }     
	}
        else
	{

	   double doldmean = root.dmean;

	   if (root.dPsum > 0)
	   {
              root.dmean = root.dEsum/root.dPsum;
	   }
	   else
	   {
	       root.dmean = 0;
	   }	       

	   if (Double.isNaN(root.dmean))
	   {
	       System.out.println("not a valid mean "+root.dEsum+"\t"+root.dPsum+"\t"+doldmean);
	       System.out.println(root.tranC);
	       System.out.println("--------------------");
	       throw new IllegalArgumentException("not a valid mean");
	   }
	   if (root.nprime <= 1)
	   {
	       root.dsigma = Math.max(dminstddev,DEFAULTSIGMA);
	   }
    	   else
	   {
              double dval = (double) root.nprime/(double)(root.nprime - 1)*
		                    (root.dEsumsq/root.dPsum - Math.pow(root.dEsum/root.dPsum,2));
	      if (dval <= 0)
	      {
		 root.dsigma = Math.max(dminstddev,DEFAULTSIGMA);
	      }
              else
	      {
		  //fix here to handle floating point error if standard deviation was too low
		  root.dsigma = Math.max(dminstddev,Math.sqrt(dval));
		  //root.dsigma = Math.sqrt(dval);
	      }
	   }		
	          

  	   if (!(root.dsigma > 0))
	   {
	      System.out.println("## "+root.dsigma+" "+root.nprime+" "+root.dEsumsq +" "+root.dEsum+" "+root.dPsum);
	   }
	
  	   if (root.nextptr[0] != null)
	   {
	      if (root.numchildren > 1)
	      {
	         if (BREGDREM)
		 {
		    root.binit = true;
		 }
		 else
		 {
		    if (root.tranC == null)
		    {
		    	if (!miRNAInteractionDataFile.equals("") && checkStatusmiRNA){
		    		int usedTimepoint = Math.min(root.ndepth+1, numberTimePoints-1);
		    		root.tranC = 
		 			   new DREM_FastLogistic2(theInstancesIndex[root.numchildren-2],
		 					  theInstances[usedTimepoint][root.numchildren-2], theInstancesTFIndex[root.numchildren-2], theInstancesTF[usedTimepoint][root.numchildren-2],
		 		              ylabels[root.numchildren-2],root.recweight,root.numchildren,numbits,regulatorTypes);
		    		
		    	}else{
		    	
 		       root.tranC = 
			   new DREM_FastLogistic2(theInstancesIndex[root.numchildren-2],
                              theInstances[0][root.numchildren-2], theInstancesTFIndex[root.numchildren-2],theInstancesTF[0][root.numchildren-2],
		              ylabels[root.numchildren-2],root.recweight,root.numchildren,numbits,regulatorTypes);
		    	}
 		       root.tranC.setRidge(RIDGE);
		    	
		    }
		    else
		    {
		    	//new version for microRNAs
		    	if (!miRNAInteractionDataFile.equals("") && checkStatusmiRNA){
		    		int usedTimepoint = Math.min(root.ndepth+1, numberTimePoints-1); //because we add the zero timepoint which has only 0s
		    		root.tranC.reinit(theInstancesIndex[root.numchildren-2], theInstances[usedTimepoint][root.numchildren-2],
				            theInstancesTFIndex[root.numchildren-2], theInstancesTF[usedTimepoint][root.numchildren-2],
	                                         ylabels[root.numchildren-2],root.recweight,root.numchildren,regulatorTypes);
		    	}else{
		    		root.tranC.reinit(theInstancesIndex[root.numchildren-2],theInstances[0][root.numchildren-2],
			            theInstancesTFIndex[root.numchildren-2],theInstancesTF[0][root.numchildren-2],
                                         ylabels[root.numchildren-2],root.recweight,root.numchildren,regulatorTypes);
		    	}
		    }
		    /*
		    * before doing this set the param in the classifier that tells which 
		    * next node is the high and which the low node
		    *  
	   	    * CASE -1 0smaller1: ptr.nextptr[0].dmean < ptr.nextptr[1].dmeanchild  -> coeff < 0
	   	    * CASE +1 1smaller0: ptr.nextptr[0].dmean > ptr.nextptr[1].dmeanchild  -> coeff > 0
	   	    * CASE +2 bothUp:  if miRNA downregulated -> coeff [-inf,+inf]
	   	    * CASE -2 bothDown:  if miRNA upregulated -> coeff [-inf,+inf]
		    */
		    /*
 			seems to lead to underfitting because too much influence on the model  
 		    if(root.nextptr[0].dmean > root.dmean &&  root.nextptr[0].dmean > root.dmean){
		    	root.tranC.childExpStatus = 2;
		    }
		    else if(root.nextptr[0].dmean < root.dmean &&  root.nextptr[0].dmean < root.dmean){
		    	root.tranC.childExpStatus = -2;
		    }
		    else
		    */
		    if(root.nextptr[0].dmean > root.nextptr[1].dmean){
		    	root.tranC.childExpStatus = 1;
		    }
		    else{
		    	root.tranC.childExpStatus = -1;
		    }
		    	
		    root.tranC.train();

		    root.binit = true;
		 }
	      }

              double dsum = 0;
	     
	      if (BREGDREM)
	      { 
                 for (int nchild = 0; nchild< root.numchildren; nchild++)
	         {
                    if (root.nextptr[nchild].bchange)
	            {
  	               dsum += root.aprobs[nchild];
		    }
		 }
	      }
	     

  	      for (int nchild = 0; nchild< root.numchildren; nchild++)
	      {
	         if (BREGDREM)
		 {
		    if (dsum >0)
		    {
		       root.ptrans[nchild] = root.aprobs[nchild]/dsum;
		       if (BDEBUG)
		       {
		          System.out.println("probs: "+root.aprobs[nchild]+" "+dsum+" "+root.ptrans[nchild]);
		       }
		    }
		    else
		    {
		       root.ptrans[nchild] = 0;
		    }

		    if (Double.isNaN(root.ptrans[nchild]))
		       System.out.println("%%%%%% "+root.ptrans[nchild]+"\t"+root.aprobs[nchild]+"\t"+dsum);
		 }
      	         updateParams(root.nextptr[nchild],nchild,data,pma,ndepth+1);
	      }
	   }
	}
    }

    //////////////////////////////////////////////////////////////////////////////
    /**
     * Executes the forward algorithm portion of the baum-welch algorithm
     */
    public void forwardalg(double[] vals,int[] pma, int[] theInstanceIndex,
                           int[] theInstance, int ni,double da, Treenode node, 
                           int nrec,Treenode parentptr) throws Exception
    {
	//da is trans prob
	//f_k(i) = P(x_1,...,x_i,pi_i=k)
        //f_0(0) = 1, f_k(0)=0 for k>0

        if (node != null)
	{
	    //sum_m  P(x_1,...,x_(i-1)|pi_(i-1)=m)a_(mk)*prob(vals[ni])
            //but were only assuming there is one path to each state

	    double dens;

	    if (pma[ni] != 0)
	    {
	       double dxmudiff = (vals[ni]-node.dmean);
	       node.dens = Math.exp(-dxmudiff*dxmudiff/(2*node.dsigma*node.dsigma))/(node.dsigma*StatUtil.TWOPISQRT);
	    }
	    else
	    {
		node.dens = 1;
	    }

	    if (node.parentptrA == null)
	    {
	       node.df = node.parent.df*da*node.dens;
	    }
	    else
	    {
	       if ((node.nrec != nrec)||(node.niteration != nglobaliteration))
	       {
	          node.df = parentptr.df*da*node.dens;
	          if (node.niteration != nglobaliteration)
	             node.niteration = nglobaliteration;
	          if (node.nrec != nrec)
	             node.nrec = nrec;
	       }
	       else
	       {
	          node.df += parentptr.df*da*node.dens;
		  node.niteration++;
	       }
	    }


	    double[] ptranlogit;

	    if (BREGDREM)
	    {
		ptranlogit = node.ptrans;
	    }
	    else if ((node.numchildren >1)&&(node.binit))
	    {
		ptranlogit = node.tranC.distributionForInstance(theInstanceIndex,theInstance,nrec);
	    }
	    else
	    {
	       ptranlogit = CONSTANTA[node.numchildren];
	    }

      	    for (int nchild = 0; nchild < node.numchildren; nchild++)
	    {
               try
               {	 
	          forwardalg(vals,pma, theInstanceIndex,theInstance,ni+1,ptranlogit[nchild],
		  node.nextptr[nchild],nrec,node);
	       }
               catch (Exception ex)
               {
                  ex.printStackTrace();
                  System.out.println(ptranlogit.length+" ------abc--"+node.nextptr[0]+"------------- "
                                     +node.nextptr.length+" "+nchild+"\t**"+node.numchildren+"\t"+node.tranC.numclasses
                                     +"\t"+node.binit+"\t"+node.dmean+"\t"+node.dsigma);
		  System.out.println(node.tranC);
	       }
	    }
	}
    }

    /////////////////////////////////////////////////////////////////////////////
    /**
     * Executes the backward portion of the baum-welch algorithm
     */
    public void backalg(double[] vals,int[] pma, int[] theInstanceIndex,
                            int[] theInstance,int ni, Treenode node, int nrec,boolean bforward) throws Exception
    {
	//b_k(i) = P(x_(i+1)...x_L|pi=k)
	//P(x_1,...,x_i,pi_i=k)
        if (node.nextptr[0] == null)
	{
	    node.db = 1;
	}
	else
	{ 
           node.db = 0;
           double[] ptranlogit;

	   if (BREGDREM)
	   {
	       ptranlogit = node.ptrans;
	   }
	   else if ((node.numchildren >1)&&(node.binit))
	   {
	       ptranlogit = node.tranC.distributionForInstance(theInstanceIndex, theInstance,nrec);
	   }
	   else
	   {
	       ptranlogit = CONSTANTA[node.numchildren];
	   }
      
           for (int nchild = 0; nchild < node.numchildren; nchild++)
	   {
	      Treenode nextnode = node.nextptr[nchild];
              backalg(vals, pma, theInstanceIndex,theInstance,ni+1, nextnode,nrec,bforward);

	      double dens;

	      if (bforward)
	      {
		  dens = nextnode.dens;
	      }
	      else if (pma[ni+1] != 0)
	      {
	         double dxmudiff = (vals[ni+1]-nextnode.dmean);
	         dens = Math.exp(-dxmudiff*dxmudiff/(2*nextnode.dsigma*nextnode.dsigma))/
                                                                (nextnode.dsigma*StatUtil.TWOPISQRT);
	      }
	      else
	      {
	         dens = 1;
	      }

	      if (BDEBUG)
	      {
	         if (nchild >= ptranlogit.length)
	         {
		    System.out.println("**********"+nchild+"\t"+ptranlogit.length);
	         }
	      }
	      	  //System.out.println("** nchild " + nchild  + " ptranlogit[nchild] " + ptranlogit[nchild] + " nextnode.db " + nextnode.db + " dens" + dens );
              node.db += ptranlogit[nchild]* nextnode.db *dens;

	      if (node.db < 0)
	      {
		  System.out.println("##"+node.db+"\t"+nextnode.dens);
		  for (int i = 0; i < ptranlogit.length; i++)
		      System.out.print(ptranlogit[i]+"\t");
		  System.out.println();

	      }
  	   }
           
           if (Double.isNaN(node.db))
  	     {	
        	   System.out.println("backward prob is NaN");
        	   System.out.println("##"+node.db+"\t"+node.dens);
        	   for (int nchild = 0; nchild < node.numchildren; nchild++)
        	   {
        	      Treenode nextnode = node.nextptr[nchild];
        	      if(nextnode != null){
        	    	  System.out.println("## "+nchild+"\t"+nextnode.db);
        	    	  
        	      }
        	   }
     		  for (int i = 0; i < ptranlogit.length; i++)
     		      System.out.print(ptranlogit[i]+"\t");
     		  System.out.println();
     		 throw new Exception();
     		  
  	     }
	}
    }

    ////////////////////////////////////////////////////////////////
    /**
     * Clears any prior assignments of genes to paths through the model
     */
    public void clearCounts(Treenode ptr)
    {
	if (ptr != null)
	{
	   ptr.bInNode = new boolean[theDataSet.data.length];
	   ptr.numPath = 0;


	   if (bindingpvalGene != null)
	   {
              ptr.htScore = new Hashtable[numbits];
	      ptr.dTotalScore = new double[numbits];
	   

  	      for (int nbindingindex = 0; nbindingindex < ptr.htScore.length; nbindingindex++)
	      {
	         ptr.htScore[nbindingindex] = new Hashtable();
	      }
	   }

 	   for (int nchild = 0; nchild < ptr.numchildren; nchild++)
	   {
	      clearCounts(ptr.nextptr[nchild]);
	   }
	}
    }

    //////////////////////////////////////////////////////////////////////////////
    /**
     * Determines the most likely path of each gene through the model
     */
    public void viterbi(Treenode treeptr) throws Exception
    {
        int[] bestpath;
	bestpath = new int[theDataSet.data[0].length];
	storedbestpath = new BigInteger[theDataSet.data.length];
	clearCounts(treeptr);
	treeptr.numPath = theDataSet.data.length;
	if (BDEBUG)
	{
	   System.out.print("!!!!!!"+theDataSet.data.length);
	   if (bindingpvalGene !=null)
	       System.out.println(" "+bindingpvalGene.length);
	}

	//initialize new array
	geneViterbiLikelihoods = new double[theDataSet.data.length];
	
        for (int nrow = 0; nrow < theDataSet.data.length; nrow++)
	{
	   if (bindingpvalGene != null)
	   {
		   geneViterbiLikelihoods[nrow] = computevlogit(theDataSet.data[nrow],theDataSet.pmavalues[nrow], bindingpvalGene[nrow],
			      bindingpvalGeneindex[nrow],0,treeptr, bestpath);
	   }
	   else
	   {
		   geneViterbiLikelihoods[nrow] = computevlogit(theDataSet.data[nrow],theDataSet.pmavalues[nrow], null,null,
	    		    0,treeptr, bestpath);
	   }

	   //int nsum = 0;
	   BigInteger nsum = new BigInteger("0");
	   String szsum = "";
	   Treenode tempptr = treeptr;

	   tempptr.bInNode[nrow] = true;

	   for (int nindex =0; nindex < bestpath.length-1; nindex++)
	   {
              tempptr = tempptr.nextptr[bestpath[nindex]];
	      tempptr.bInNode[nrow] = true;
	      tempptr.numPath++;

	      if (bindingpvalGene != null)
	      {
	         int ntfindex = 0;
		 for (int nbit = 0; nbit < numbits; nbit++)
		 {
		    while ((ntfindex < bindingpvalGeneindex[nrow].length)&&
			   (nbit > bindingpvalGeneindex[nrow][ntfindex]))
		    {
		       ntfindex++;
		    }
		   
		    Double objMap;
		    if ((ntfindex < bindingpvalGeneindex[nrow].length)&&
                        (nbit == bindingpvalGeneindex[nrow][ntfindex]))
		    {
		       tempptr.dTotalScore[nbit] += bindingpvalGene[nrow][ntfindex];
		       objMap =new Double(bindingpvalGene[nrow][ntfindex]);
		    }
		    else
		    {
		       objMap = new Double(0.0);
		    }
		
 		    Integer objCount = (Integer) tempptr.htScore[nbit].get(objMap);
		    if (objCount != null)
		    {
		       tempptr.htScore[nbit].put(objMap, new Integer(objCount.intValue()+1));
		    }
		    else
		    {
		       tempptr.htScore[nbit].put(objMap, new Integer(1));
		    }
		 }
	      }
	      //szsum += ""+bestpath[nindex];
	      //nsum += (int) Math.pow(nmaxchild,bestpath.length-nindex-1)*bestpath[nindex];
	      nsum = nsum.add((new BigInteger(""+nmaxchild)).pow(bestpath.length-nindex-1).multiply(new BigInteger(""+bestpath[nindex])));  
	    }
	   storedbestpath[nrow] = nsum;
	}
    }

    //////////////////////////////////////////////////////////////////////////////
    /**
     * Records fpr each split node the regulator to gene interactions and saves them in a file.
     */
    public void outputRegulatorToGeneInteractionsAtSplit(Treenode treeptr,DREMGui Gui,BufferedWriter out,BufferedWriter out2) throws Exception
    {
	
	if (BDEBUG)
	{
	   System.out.print("!!!!!!"+theDataSet.data.length);
	   if (bindingpvalGene !=null)
	       System.out.println(" "+bindingpvalGene.length);
	}
	
	//only write into file if regulator data exists and node has children
	 if (bindingpvalGene != null  && treeptr.numchildren >0) 
	   {
		 
		   //current node a split node?
		   if( treeptr.numchildren <2){
			   if(treeptr.nextptr != null ){
				   return;
			   }
			 //go further down in the tree
			   System.out.println("We are going to the next node no split!");
			 outputRegulatorToGeneInteractionsAtSplit(treeptr.nextptr[0],Gui,out,out2); 
			 return;
		   }
		out.write("Split\t"+numSplit); 
		out.newLine();
		numSplit++;
		int up=0;
		System.out.println("p-value threshold miRNA " +Gui.dkeymiRNApvalue);
		//Gui.dkeyinputpvalue = 0.0000524;
		System.out.println("p-value threshold miRNA " +Gui.dkeyinputpvalue);
		//whats the up node whats the down node
		if (treeptr.nextptr[0].dmean < treeptr.nextptr[1].dmean){
			up =1;
			
		}
		
		for(int direction=0;direction<2;direction++){
				String path="";
				if(up==direction){
					out.write("UP");
					out.newLine();
					path=Integer.toString(numSplit-1) + "-1";
				}else{
					out.write("DOWN");
					out.newLine();
					path=Integer.toString(numSplit-1) + "-0";
				}
				out.flush();
				Treenode childptr = treeptr.nextptr[direction];
				//output nodes on the path
				int all=0;
				for (int slot=0;slot < childptr.bInNode.length;slot++){
					if(childptr.bInNode[slot] == true){
						out2.write(path+"\t"+theDataSet.genenames[slot]);
						out2.newLine();
						all++;
					}
					
				
				}
				
				//out.write(childptr.dmean + " "+childptr.dsigma+"\n");
				Iterator iter = treeptr.tsSigTFEdgeSplit[direction].iterator();
				//NumberFormat nf1 = NumberFormat.getInstance(Locale.ENGLISH);
				//PText theSigText = new PText("");
				String SigText = new String("");
				//used to identify the regulators
				 HashSet htAdded = new HashSet();
				if(treeptr.tsSigTFEdgeSplit[direction] != null){
					System.out.println("size treeptr.tsSigTFEdgeSplit[direction]" + treeptr.tsSigTFEdgeSplit[direction].size());
					//Gui.setSigText(treeptr.tsSigTFEdgeSplit[direction],  theSigText, Gui.nKeyInputType);
					
					
					 StringBuffer szNamesbuf = new StringBuffer();
				       StringBuffer tfNamesBuffer = new StringBuffer();
				       
				      
				    	   Iterator itr = treeptr.tsSigTFEdgeSplit[direction].iterator();
				        
				           

				      	//finding miRNA genes NOTE that the same is done in filtergenesthreshold2change in DataSetCore
				  	    Pattern P = Pattern.compile("MMU-");
				          
				          if (itr.hasNext())
				          {
				             DREM_Timeiohmm.SigTFRecv2 theTFRec =  (DREM_Timeiohmm.SigTFRecv2) itr.next();
				             
				             Matcher m = P.matcher(theTFRec.szname.toUpperCase());
				             
				     		if(m.find() ){
								if ((theTFRec.dpval <= Gui.dkeymiRNApvalue)&&(
										                        (theTFRec.dpercent >= Gui.dsplitpercent)))
										{
										szNamesbuf.append(" "+theTFRec.szname.toUpperCase()+" \n");
										htAdded.add(theTFRec.szname);
										//out.write(theTFRec.szname+" "+theTFRec.dpval+" "+theTFRec.dpercent+"\n");
										}
				     		}else{  //TF version

					             if ((theTFRec.dpval <= Gui.dkeyinputpvalue)&&(
					                                               (theTFRec.dpercent >= Gui.dsplitpercent)))
					             {
					            	 tfNamesBuffer.append(" "+theTFRec.szname.toUpperCase()+" \n");
					            	 //htAdded.add(theTFRec.szname);
					             }
				     		}
				             while (itr.hasNext())
				             {
					        theTFRec =  (DREM_Timeiohmm.SigTFRecv2) itr.next();
					        m = P.matcher(theTFRec.szname.toUpperCase());
				            
				    		if(m.find() ){
					        
				                if ((theTFRec.dpval <= Gui.dkeymiRNApvalue)&&
				                			((theTFRec.dpercent >= Gui.dsplitpercent))&&
				                			(!htAdded.contains(theTFRec.szname.toUpperCase())))
						        {
									    szNamesbuf.append(" "+theTFRec.szname.toUpperCase()+" \n");
									    htAdded.add(theTFRec.szname.toUpperCase());
									    //out.write(theTFRec.szname+" "+theTFRec.dpval+" "+theTFRec.dpercent+"\n");
						        }
				    		}else{ //TF version
				    			  if ((theTFRec.dpval <= Gui.dkeyinputpvalue)&&
				              			((theTFRec.dpercent >= Gui.dsplitpercent))&&
				              			(!htAdded.contains(theTFRec.szname.toUpperCase())))
						        {
									    tfNamesBuffer.append(" "+theTFRec.szname.toUpperCase()+" \n");
									    //htAdded.add(theTFRec.szname.toUpperCase());
						        }
				    		}
				                
				             
				          }
					
				          }
				          SigText = szNamesbuf.toString(); //+ tfNamesBuffer.toString();
					
				}else{
					System.out.println("no entry for treeptr.tsSigTFEdgeSplit[direction]" );
					return;
				}
				
			
				System.out.println(SigText);
				HashSet htAdded2 = new HashSet(); 
				for(int tfIndex=0;tfIndex < numbits;tfIndex++){
					//foreach significant regulator find the set of gene in the up and down node
				
				Pattern p = Pattern.compile(tfNames[tfIndex].toUpperCase());
				htAdded2 = new HashSet(); 
				Matcher m = p.matcher(SigText);
				
		       //if regulator is among significant regulators
				if(m.find() ){
				//if(htAdded.contains(tfNames[tfIndex].toUpperCase())){
						
					
					//System.out.println(tfNames[tfIndex] +" is significant!");
					//String geneNames = tfNames[tfIndex];
					for (int geneIndex = 0; geneIndex < bindingpvalTFindex[tfIndex].length; geneIndex++)
					{
						int elem = bindingpvalTFindex[tfIndex][geneIndex];
						if(childptr.bInNode[elem] == true){
							htAdded2.add(theDataSet.genenames[elem]); 
							//geneNames = geneNames+"\t"+theDataSet.genenames[elem];
						}
					}
					//out.write("new line iwth mirs"+"\n");
					out.write(tfNames[tfIndex]);
					Iterator itSet = htAdded2.iterator();
					while(itSet.hasNext()){
						out.write("\t"+itSet.next().toString());
					}
					//out.write(geneNames);
					out.newLine();
				}	   
			}//tfIndex
	      }//direction
		out.flush();
		
			System.out.println("Following direction " + up);
			outputRegulatorToGeneInteractionsAtSplit(treeptr.nextptr[up],Gui,out,out2);
			System.out.println("Following direction " + (1-up));
			outputRegulatorToGeneInteractionsAtSplit(treeptr.nextptr[1-up],Gui,out,out2);
		
		
	   }//valid node
	 return;
    }
    
    //////////////////////////////////////////////////////////////////////////////////
    /**
     * Computes association scores for the transcription factors overall on paths and
     * on paths out of splits conditional on the set of genes going into the split
     */
    public void computeStats(Treenode treeptr, Treenode rootptr)
    {
       if (treeptr != null)
       {
          treeptr.dscore = new double[numbits][treeptr.numchildren];
       	  treeptr.ddiff = new double[numbits][treeptr.numchildren];
	  treeptr.dpvals = new double[numbits][treeptr.numchildren];

	  treeptr.ncountvals = new int[numbits][treeptr.numchildren][dBindingVals.length];

	  if (treeptr.numchildren >= 3)
	  {
             treeptr.nothersum = new int[numbits][treeptr.numchildren][dBindingVals.length];
	     treeptr.dscoreother = new double[numbits][treeptr.numchildren];
	  }

	  int[][] ncountgrid = new int[2][dBindingVals.length];
	  treeptr.ncountTotals = new int[numbits][dBindingVals.length];

       	  treeptr.tsSigTF = new TreeSet(new SigTFRecv2Compare());
	  for (int ntf = 0; ntf < numbits; ntf++)
	  {
	     double dnumpaths = 0;
	     double dscoretotal = 0;
	     for (int nindex = 0; nindex < treeptr.ncountTotals[ntf].length; nindex++)
	     {
	        treeptr.ncountTotals[ntf][nindex] = 0;
	     }

	     for (int nchild = 0; nchild < treeptr.numchildren; nchild++)
	     {
	        if (treeptr.nextptr[nchild].htScore == null)
		{
		   for (int nvalindex = 0; nvalindex < treeptr.ncountvals[ntf][nchild].length; nvalindex++)
		   {
		      treeptr.ncountvals[ntf][nchild][nvalindex] = 0;
		   }
		}
		else
		{
		   for (int nel = 0; nel < dBindingVals.length; nel++)
		   {
	              Object key = new Double(dBindingVals[nel]);
                      Object objcount = treeptr.nextptr[nchild].htScore[ntf].get(key);
	                      
                      if (objcount != null)
	              {  
		         int ntempval =((Integer) objcount).intValue();
		         treeptr.ncountvals[ntf][nchild][nel] = ntempval;
			 treeptr.ncountTotals[ntf][nel] += ntempval;  
	              }
	              else
	              {
		         treeptr.ncountvals[ntf][nchild][nel] = 0;
		      }
		   }
		}
			   
                treeptr.dscore[ntf][nchild] = 
                               treeptr.nextptr[nchild].dTotalScore[ntf]/treeptr.nextptr[nchild].numPath;
		dnumpaths += treeptr.nextptr[nchild].numPath;
		dscoretotal += treeptr.nextptr[nchild].dTotalScore[ntf];
	     }

	     if (treeptr.numchildren == 2)
	     {
	        treeptr.ddiff[ntf][0] =  treeptr.dscore[ntf][0]- treeptr.dscore[ntf][1];
		treeptr.dpvals[ntf][0] = computepval( treeptr.ncountvals[ntf],  Math.abs(treeptr.ddiff[ntf][0]));
		treeptr.tsSigTF.add(new SigTFRecv2(tfNames[ntf],treeptr.dpvals[ntf][0]));

	     }
	     else  if (treeptr.numchildren >= 3)
	     {
	        for (int nchild = 0; nchild < treeptr.numchildren; nchild++)
		{
	           //divide by 0 need to check about that
	           double ddiff = (dnumpaths-treeptr.nextptr[nchild].numPath);
	       	   double davgother;

		   if (ddiff > 0)
		   {
		      davgother =  (dscoretotal- treeptr.nextptr[nchild].dTotalScore[ntf])/ddiff;
		   }
		   else
		   {
		      davgother = 0;
		   }
		   treeptr.dscoreother[ntf][nchild] = davgother;

		   treeptr.ddiff[ntf][nchild] = treeptr.dscore[ntf][nchild]-davgother;
			    
		   for (int nindex = 0; nindex < treeptr.ncountTotals[ntf].length; nindex++)
		   {
		      ncountgrid[0][nindex] = treeptr.ncountvals[ntf][nchild][nindex];
                      ncountgrid[1][nindex] = treeptr.ncountTotals[ntf][nindex] - ncountgrid[0][nindex];
		      treeptr.nothersum[ntf][nchild][nindex] =  ncountgrid[1][nindex];
		   }
 
		   treeptr.dpvals[ntf][nchild] = computepval(ncountgrid, Math.abs(treeptr.ddiff[ntf][nchild]));
		}

		for (int nchild = 0; nchild < treeptr.numchildren; nchild++)
		{
		   treeptr.tsSigTF.add(
			       new SigTFRecv2(tfNames[ntf],treeptr.dpvals[ntf][treeptr.orderA[nchild]]));						 
		}
	     }
	  }
       
          int numrowstable;
          int nsize = hsUniqueInput.size()-1;

          numrowstable = tfNames.length * nsize;

	  boolean bsplit;
          if (treeptr.numchildren >= 2)
          {
             treeptr.dpvalEdgeSplit= new double[treeptr.numchildren][numrowstable];
             treeptr.ddiffEdgeSplit = new double[treeptr.numchildren][numrowstable];
             treeptr.dexpectEdgeSplit = new double[treeptr.numchildren][numrowstable];
	     treeptr.tsSigTFEdgeSplit = new TreeSet[treeptr.numchildren];
             treeptr.dratioSplit = new double[treeptr.numchildren][numrowstable];

  	     for (int nindex= 0; nindex < treeptr.numchildren; nindex++)
	     {
	        treeptr.tsSigTFEdgeSplit[nindex] = new TreeSet(new SigTFRecv2Compare());
	     }
	     bsplit = true;
	  }
          else
          {
             bsplit = false;
	  }
	
          treeptr.dpvalEdgeFull= new double[treeptr.numchildren][0];
          treeptr.ddiffEdgeFull = new double[treeptr.numchildren][0];
          treeptr.dexpectEdgeFull = new double[treeptr.numchildren][0];
          treeptr.tsSigTFFull = new TreeSet[treeptr.numchildren];
          int nsumpathfull;

          nsumpathfull = rootptr.numPath;
	      
          if ((treeptr.numchildren ==1) && (treeptr != rootptr))
          {
             boolean bfound = false;
	     int nindex = 0;
	     while (!bfound)
	     {
	        if (treeptr.parent.nextptr[nindex] == treeptr)
	        {
	           bfound = true;
		   if (BDEBUG)
		   {
		      System.out.println(treeptr+"\t"+treeptr.parent+
                                          "\t"+treeptr.parentptrA+"\t"+treeptr.parent.dpvalEdgeFull);
		   }
			
                   if (treeptr.parentptrA == null)
		   {
                      treeptr.dpvalEdgeFull[0]= treeptr.parent.dpvalEdgeFull[nindex];
	              treeptr.ddiffEdgeFull[0] =  treeptr.parent.ddiffEdgeFull[nindex];
	              treeptr.dexpectEdgeFull[0] =  treeptr.parent.dexpectEdgeFull[nindex];
                      treeptr.tsSigTFFull[0] = treeptr.parent.tsSigTFFull[nindex];
		   }
		}
	        else
	        {
	           nindex++;
		}
	     }
	  }
          else
          {
             treeptr.dpvalEdgeFull= new double[treeptr.numchildren][numrowstable];
             treeptr.ddiffEdgeFull = new double[treeptr.numchildren][numrowstable];
	     treeptr.dexpectEdgeFull = new double[treeptr.numchildren][numrowstable];
	     for (int nindex= 0; nindex < treeptr.numchildren; nindex++)
	     {
	        treeptr.tsSigTFFull[nindex] = new TreeSet(new SigTFRecv2Compare());
	     }
 	  
             for (int nchild = 0; nchild < treeptr.numchildren; nchild++)
	     {
		 //System.out.println("---------------------------"+treeptr.ndepth);

	        int nrowindex = 0;
                for (int nrow = 0; nrow < tfNames.length; nrow++)
	        {
	           int nsumthispath = 0;
	           int[] dvals = treeptr.ncountvals[nrow][nchild];
		   nsumthispath = treeptr.nextptr[nchild].numPath;

	           for (int nel = 0; nel < dBindingVals.length; nel++)
                   {  
	              if (dBindingVals[nel] != 0)
	              {
                         int nsumfullel = filteredClassifier.nBaseCount[nrow][dBindingVals[nel]+ filteredClassifier.noffset];
       	                 double dexpectfull = (nsumthispath* nsumfullel)/(double) ntotalcombined;
	                 treeptr.dexpectEdgeFull[nchild][nrowindex] =dexpectfull;

  	  	         double ddiffull =  treeptr.ncountvals[nrow][nchild][nel] - dexpectfull;
	                    treeptr.ddiffEdgeFull[nchild][nrowindex] = ddiffull;

	                 treeptr.dpvalEdgeFull[nchild][nrowindex] = 
		              StatUtil.hypergeometrictail(treeptr.ncountvals[nrow][nchild][nel]-1, 
                                        nsumfullel, ntotalcombined-nsumfullel,nsumthispath);
		         //assuming 0 always unique input

		         if (hsUniqueInput.size()==2)
		         {
		            treeptr.tsSigTFFull[nchild].add(new SigTFRecv2(tfNames[nrow],
                                              treeptr.dpvalEdgeFull[nchild][nrowindex]));
		         }
		         else
		         {
		            treeptr.tsSigTFFull[nchild].add(
				      new SigTFRecv2(tfNames[nrow]+" "+(int)dBindingVals[nel],
                                              treeptr.dpvalEdgeFull[nchild][nrowindex]));
			 }

		         if (bsplit)
		         {
	                    int nsumthisel = treeptr.ncountTotals[nrow][nel];

			    int nsumthisparentpath = treeptr.numPath;

		            double dexpect = (nsumthispath* nsumthisel)/(double) nsumthisparentpath;
		            treeptr.dexpectEdgeSplit[nchild][nrowindex] = dexpect;
	                    double ddiff =  treeptr.ncountvals[nrow][nchild][nel] - dexpect;
 	                    treeptr.ddiffEdgeSplit[nchild][nrowindex] = ddiff;
                            treeptr.dpvalEdgeSplit[nchild][nrowindex] = 
	                    StatUtil.hypergeometrictail(treeptr.ncountvals[nrow][nchild][nel]-1, 
                                     nsumthisel, nsumthisparentpath-nsumthisel,nsumthispath);


		       	    treeptr.dratioSplit[nchild][nrowindex] = (double)treeptr.ncountvals[nrow][nchild][nel]/treeptr.ncountTotals[nrow][nel];

			    if (hsUniqueInput.size()==2)
			    {
			    	   int upregulatedChild = 0;
			    	   if(treeptr.nextptr[0].dmean < treeptr.nextptr[1].dmean){
			    		   upregulatedChild = 1;
			    	   }
			    	
			    	String name=tfNames[nrow];
			    	System.out.println("at nrow:"+nrow+" tf:"+tfNames[nrow] + "  regTypes[nrow]:" + regulatorTypes[nrow] + " length traindata:"+ treeptr.tranC.traindataTF[nrow].length );
			    	if(regulatorTypes[nrow]==1 &&treeptr.tranC.traindataTF[nrow].length >0 &&treeptr.tranC.traindataTF[nrow][0] !=0){
			    		if(treeptr.tranC.traindataTF[nrow][0] == -1 && regulatorExpressionIndex.get(name.toUpperCase()) != null && nchild == upregulatedChild){
			    			name="\\/ "+ name;
			    			treeptr.tsSigTFEdgeSplit[nchild].add(
									   new SigTFRecv2(name, treeptr.dpvalEdgeSplit[nchild][nrowindex],
				                                                 treeptr.dratioSplit[nchild][nrowindex]));
			    		}
			    		if(treeptr.tranC.traindataTF[nrow][0] == 1 && regulatorExpressionIndex.get(name.toUpperCase()) != null && nchild != upregulatedChild){
			    			name="/\\ "+ name;
			    			treeptr.tsSigTFEdgeSplit[nchild].add(
									   new SigTFRecv2(name, treeptr.dpvalEdgeSplit[nchild][nrowindex],
				                                                 treeptr.dratioSplit[nchild][nrowindex]));
			    		}
			    		
			    		
			    	}else{
			    		if(regulatorTypes[nrow]==0){
			    			treeptr.tsSigTFEdgeSplit[nchild].add(
									   new SigTFRecv2(name, treeptr.dpvalEdgeSplit[nchild][nrowindex],
				                                                 treeptr.dratioSplit[nchild][nrowindex]));
			    		}
			    	}
			       
			    }
			    else
			    {
			    	
			       treeptr.tsSigTFEdgeSplit[nchild].add(
					   new SigTFRecv2(tfNames[nrow]+" "+(int)dBindingVals[nel],
							  treeptr.dpvalEdgeSplit[nchild][nrowindex],
							  treeptr.dratioSplit[nchild][nrowindex]));
			    }
			 }
	                 nrowindex++;
		      }
		   }
		}
	     }
	  }



          for (int nchild = 0; nchild < treeptr.numchildren; nchild++)
          {
             computeStats(treeptr.nextptr[nchild],rootptr);
	  }
       }
    }

    /////////////////////////////////////////////////////////////////////////////////
    /**
     * Record used in the ranking of transcription factors
     */
    static class SigTFRecv2 
    {
	String szname;
	double dpval;
	double dpercent;

	SigTFRecv2(String szname, double dpval,double dpercent)
	{
	    this.szname = szname;
	    this.dpval = dpval;
	    this.dpercent = dpercent;
	}

	SigTFRecv2(String szname, double dpval)
	{
	    this.szname = szname;
	    this.dpval = dpval;
	    this.dpercent = -1;
	}
    }

    /**
     * Compares TFs first based on the value first lower dpval, then great dpercent, then name
     */
    static class SigTFRecv2Compare implements Comparator 
    {
        public int compare(Object c1, Object c2)
	{
	    SigTFRecv2 cr1 = (SigTFRecv2) c1;
	    SigTFRecv2 cr2 = (SigTFRecv2) c2;

	    if (cr1.dpval < cr2.dpval)
		return -1;
	    else if (cr1.dpval > cr2.dpval)
		return 1;
	    else if (cr1.dpercent > cr2.dpercent)
		return -1;
	    else if (cr1.dpercent < cr2.dpercent)
		return 1;
	    else
		return cr1.szname.compareTo(cr2.szname);

	}
    }

    /////////////////////////////////////////////////////////////////////////////////////////
    /**
     * Computes the fraction of combinations for vals that could lead to a greater difference
     * than ddiff
     */
    public double computepval(int[][] vals, double diff)
    {
	double dcol0 = 0;
	double dcol1 = 0;

	int[] rowSum = new int[vals[0].length];
	double dtimes = 0;
	int nsum0 = 0;
	int nsum1 = 0;

	for (int nindex = 0; nindex < vals[0].length; nindex++)
	{
	    nsum0 += vals[0][nindex];
	    nsum1 += vals[1][nindex];
	    rowSum[nindex] = vals[0][nindex] + vals[1][nindex];
	}

	double dpvalsum = 0;
	int[] ncol0 = new int[vals[0].length];

        if (ncol0.length == 2)
	{
	   for (ncol0[0] = 0; ncol0[0] <= Math.min(rowSum[0],nsum0);  ncol0[0]++)
 	   {
	      double dinnersum = 0;
	      ncol0[1] = nsum0-ncol0[0];

	      if (ncol0[1] <= rowSum[1])
	      {
 	        double dweightsum0 = 0;
	        double dweightsum1 = 0;
	        for (int i = 0; i < ncol0.length; i++)
	        {
	           dweightsum0 += dBindingVals[i]*ncol0[i]; 
	           dweightsum1 += dBindingVals[i]*(rowSum[i]-ncol0[i]); 
	        }
	        double dcurrdiff = Math.abs(dweightsum0/nsum0-dweightsum1/nsum1);
	        if (dcurrdiff >= diff)
	        {
	            dtimes++;
		    dinnersum++;
	        }
	     }
	     dpvalsum += StatUtil.hypergeometric(ncol0[0], nsum0, nsum1, rowSum[0])* dinnersum;
	   }
	}
	else if (ncol0.length==3)
	{
	   for (ncol0[0] = 0; ncol0[0] <= Math.min(rowSum[0],nsum0);  ncol0[0]++)
 	   {
	      double dinnersum = 0;
	      int nremainder0 =  nsum0-ncol0[0];
	      int nremainder1 = nsum1 - (rowSum[0]- ncol0[0]);
	      for (ncol0[1] = 0; ncol0[1] <= Math.min(rowSum[1],nremainder0); ncol0[1]++)
	      {
	         ncol0[2] = nsum0;
		 for (int i = 0; i < ncol0.length - 1; i++)
		 {
		    ncol0[2] -= ncol0[i];
		 }
		 if (ncol0[2] <= rowSum[2])
		 {
 		    double dweightsum0 = 0;
		    double dweightsum1 = 0;
		    for (int i = 0; i < ncol0.length; i++)
		    {
		       dweightsum0 += dBindingVals[i]*ncol0[i]; 
		       dweightsum1 += dBindingVals[i]*(rowSum[i]-ncol0[i]); 
		    }
		    double dcurrdiff = Math.abs(dweightsum0/nsum0-dweightsum1/nsum1);
		    if (dcurrdiff >= diff)
		    {
	               dtimes++;
		       dinnersum += StatUtil.hypergeometric(ncol0[1], nremainder0, nremainder1,rowSum[1]);
		    }
		 }
	     }
	     dpvalsum += StatUtil.hypergeometric(ncol0[0], nsum0, nsum1, rowSum[0])* dinnersum;
	   }
	}
	else if (ncol0.length == 1)
	{
	    return 1;
	}
        else
	{
	    throw new IllegalArgumentException("can only handle two or three unique inputs");
	}

	return dpvalsum;
    }

    /////////////////////////////////////////////////////////////////////////

    /**
     * Recursively determines the best path through the model and its likelihood
     */
    public double computevlogit(double[] vals,int[] pma,
                                int[] theInstance,int[] theInstanceIndex, 
                                int ndepth,Treenode node,int[] bestpath) throws Exception
    {

        double dmax = Double.NEGATIVE_INFINITY;
        int bestchild = 0;
        double dlogout = 0;
	double dval = 0;
        
        if (node.dsigma > 0)
        {
	   if (pma[ndepth] != 0)
	   {

	       if (ndepth == 0)
	       {
		   dlogout = 0;
	       }
	       else
	       {
                  dlogout = Math.log(StatUtil.normaldensity(vals[ndepth], node.dmean, node.dsigma));
	       }
	   }
	   else
	   {
	       dlogout = 0;
	   }
	}
           
        if (node.numchildren == 0)
	{
           return dlogout;
	}

        int[] currbestpath = new int[bestpath.length];

        // log (a) + c(log(b_1) + log(b_2) + ... + log(b_n))
        //= log(a*(b_1*b_2*...*b_n)^c) 

	double [] ptranlogit;

	if (BREGDREM)
	{
	   ptranlogit = node.ptrans;
	}
	else if ((node.numchildren >1)&&(node.binit))
	{
	   ptranlogit = node.tranC.distributionForInstance(theInstanceIndex,theInstance,-1);
	}
	else
	{
	   ptranlogit = CONSTANTA[node.numchildren];
	}

        for (int nchild = 0; nchild < node.numchildren; nchild++)
	{
            dval = dlogout;
            if (node.nextptr[nchild] != null)
	    {
                double dvi = computevlogit(vals,pma,theInstance,theInstanceIndex,
                                           ndepth+1,node.nextptr[nchild],bestpath);
		if (ptranlogit[nchild]==0)
		{
		   dval += Math.log(MINPROB);
		}
		else
		{
		   dval += Math.log(ptranlogit[nchild])+dvi;
		}
	    }

	    if (dval > dmax)
	    {
		dmax = dval;
                bestchild = nchild;
                for (int nindex = 0; nindex <bestpath.length; nindex++)
		{
		    currbestpath[nindex] = bestpath[nindex];
		}
	    }
	}
               
        for (int nindex = 0; nindex <bestpath.length; nindex++)
	{
	   bestpath[nindex] = currbestpath[nindex];
	}
        bestpath[ndepth] = bestchild;

        return dmax;
    }

    //////////////////////////////////////////////////////////////////////////
    /**
     * Evaluates the likelihood of the viterbi assignments of the holdoutdata 
     * under the current settings of the model parameters
     */
    public double testhmmVHoldOut(Treenode treehmm) throws Exception
    {
       double dlike = 0;
       int[] bestpath = new int[traindata[0].length];
       for (int nrow = 0; nrow <holdoutdata.length; nrow++)
       {
	   int[] theInstance = holdoutpval[nrow];
	   int[] theInstanceindex = holdoutpvalIndex[nrow];

           double dbest = computevlogit(holdoutdata[nrow],holdoutpma[nrow],theInstance,
                                         theInstanceindex, 0,treehmm, bestpath);
	   {
	       dlike += dbest;
	   }
       }
       return dlike;
    }

    //////////////////////////////////////////////////////////////////////////
    /**
     * Evaluates the likelihood of the viterbi assignments of the testdata 
     * under the current settings of the model parameters
     */
    public double testhmmV(Treenode treehmm) throws Exception
    {
       double dlike = 0;
       int[] bestpath = new int[traindata[0].length];
       for (int nrow = 0; nrow <testdata.length; nrow++)
       {

	   int[] theInstance = testpval[nrow];
	   int[] theInstanceIndex = testpvalIndex[nrow];
           double dbest = computevlogit(testdata[nrow],testpma[nrow],theInstance,
                                                   theInstanceIndex, 0,treehmm, bestpath);
	   dlike += dbest;
       }
       return dlike;
    }


    //////////////////////////////////////////////////////////////////////////
    /**
     * Evaluates the likelihood of the holdoutdata under the current settings of the
     * model parameters
     */
    public double testhmmHoldOut(Treenode treehmm) throws Exception
    {
       double dlike = 0;
       for (int nrow = 0; nrow <holdoutdata.length; nrow++)
       {
	   backalg(holdoutdata[nrow],holdoutpma[nrow],holdoutpvalIndex[nrow],
		   holdoutpval[nrow], 0, treehmm,nrow,false);
	   if (treehmm.db <= 0)
	   {
	       dlike += Math.log(MINPROB);
	       System.out.println("B warning row "+nrow+" is "+treehmm.db);
	   }
	   else
	   {
              dlike += Math.log(treehmm.db);
	   }
       }
       return dlike;
    }

    //////////////////////////////////////////////////////////////////////////
    /**
     * Evaluates the likelihood of the testdata under the current settings of the
     * model parameters
     */
    public double testhmm(Treenode treehmm) throws Exception
    {
       double dlike = 0;
       for (int nrow = 0; nrow <testdata.length; nrow++)
       {
	   backalg(testdata[nrow],testpma[nrow],testpvalIndex[nrow],
		   testpval[nrow],0, treehmm,nrow,false);

	   if (treehmm.db <= 0)
	   {
	       dlike += Math.log(MINPROB);
	   }
	   else
	   {
              dlike += Math.log(treehmm.db);
	   }
       }

       return dlike;
    }


    /**
     * Returns the number of nodes in the tree pointed by root for which its
     * ncurrtime field does not equal the ncurrtime parameter
     */
    public int countNodes(Treenode root, int ncurrtime)
    {

	if (root == null)
	{
	    return 0;
	}
	else 
	{
	    int nsum;
	    if (root.ncurrtime != ncurrtime)
	    {
		root.ncurrtime = ncurrtime;
		nsum = 1;
	    }
	    else
	    {
	        nsum = 0;
	    }

	    for (int nchild = 0; nchild < root.numchildren; nchild++)
	    {
		nsum += countNodes(root.nextptr[nchild],ncurrtime);
	    }

	    return nsum;
	}
    }


    //////////////////////////////////////////////////////////////////////////
    /**
     * Implements a viterbi training method for the parameters with the
     * current model structure
     */
    public double trainhmmV(Treenode treehmm, boolean bpruneexempt) throws Exception
    {

       double dlike=0;
       double doldlike;

       //first time through we will need to initialize the hmm without the classifiers
       //then we will need to train the classifiers

       initAEV(treehmm);
       int[] bestpath = new int[traindata[0].length];

       double[] ptranlogit;

       for (int nrow = 0; nrow <traindata.length; nrow++)
       {
	  int[] theInstance = trainpval[nrow];
	  int[] theInstanceIndex = trainpvalIndex[nrow];
  
	  if (BREGDREM)
	  {
	      ptranlogit = treehmm.ptrans;
	  }
          else if ((treehmm.numchildren >1)&&(treehmm.binit))
          {
              ptranlogit = treehmm.tranC.distributionForInstance(theInstanceIndex,theInstance,-1);
          }
          else
          {
              ptranlogit = CONSTANTA[treehmm.numchildren];
          }

          double dbest = computevlogit(traindata[nrow],trainpma[nrow],theInstance,
                                       theInstanceIndex, 0,treehmm, bestpath);

          instanceAEV(treehmm,traindata[nrow],trainpma[nrow],trainpval[nrow],
			  bestpath,Math.exp(dbest),nrow);

          dlike += dbest;
	  
       }
       updateParams(treehmm,0,traindata,trainpma,0);

       if (BEQUALSTD)
       {
          averageChildrenSigmas(treehmm);
       }
       
       int ncount = 0;
                
       //very first time going to assign labels 
       double dpredictitr;

       do
       {
          //train while there is still a big enough improvement
          doldlike = dlike;
          initAEV(treehmm);
          dlike = 0;

          for (int nrow = 0; nrow <traindata.length; nrow++)
          {
	     int[] theInstance = trainpval[nrow];
	     int[] theInstanceIndex = trainpvalIndex[nrow];

	     if (BREGDREM)
	     {
		 ptranlogit = treehmm.ptrans;
	     }
             else if ((treehmm.numchildren >1)&&(treehmm.binit))
             {
		 ptranlogit = treehmm.tranC.distributionForInstance(theInstanceIndex,theInstance,nrow);
             }
             else
             {
                ptranlogit = CONSTANTA[treehmm.numchildren];
             }

             double dbest = computevlogit(traindata[nrow],trainpma[nrow],theInstance,
                                          theInstanceIndex, 0,treehmm, bestpath);


             instanceAEV(treehmm,traindata[nrow],trainpma[nrow],trainpval[nrow],
                             bestpath,Math.exp(dbest),nrow);

             dlike += dbest;

	     if (Double.isNaN(dlike))
	     {
	        traverse(treehmm,0,true);

	        System.out.println(nrow+"\t");
	        for (int na = 0; na < trainpval[nrow].length; na++)
	        {
	           System.out.print(trainpval[nrow][na]+"\t");
	        }
	        System.out.println();
	        if (!BREGDREM)
	        {
	           for (int na = 0; na < treehmm.tranC.dcoeff.length; na++)
		   {
		      System.out.print(treehmm.tranC.dcoeff[na]+"\t");
		   }
		}
	        System.out.println();
	        System.out.println("treehmm.db = "+treehmm.db);
	        throw new Exception();
	     }
	  }

          updateParams(treehmm,0,traindata,trainpma,0);
          if (BEQUALSTD)
	  {
	     averageChildrenSigmas(treehmm);
	  }

	  ncount++;
	  dpredictitr= (dbesttrainlike-dlike)/(dlike-doldlike);
       } 
       while (((dlike-doldlike)/Math.abs(dlike) > BEPSILON)
             &&((bpruneexempt)||(dpredictitr<MAXFUTUREITR)));

       
       if (BDEBUG)
       {
          System.out.println("Likelihood: "+dlike);
       }

       dtrainlike = dlike;   
 
       return (dlike);
    }

    //////////////////////////////////////////////////////////////////////////
    /**
     * Implements a baum-welch method for training the parameters with the
     * current model structure
     */
    public double trainhmm(Treenode treehmm, boolean bpruneexempt) throws Exception
    {

       double dlike=0;
       double doldlike;


       //first time through we will need to initialize the hmm without the classifiers
       //then we will need to train the classifiers

       initAE(treehmm);
       nglobaliteration = 1;
       dlike = 0;
       double[] ptranlogit;

       traverse(treehmm,0,false);
       for (int nrow = 0; nrow <traindata.length; nrow++)
       {
          treehmm.df = 1;  

	  int[] theInstance = trainpval[nrow];
	  int[] theInstanceIndex = trainpvalIndex[nrow];
  
	  if (BREGDREM)
	  {
	      ptranlogit = treehmm.ptrans;
	  }
          else if ((treehmm.numchildren >1)&&(treehmm.binit))
          {
              ptranlogit = treehmm.tranC.distributionForInstance(theInstanceIndex,theInstance,-1);
          }
          else
          {
              ptranlogit = CONSTANTA[treehmm.numchildren];
          }
	  
          for (int nchild =0;  nchild < treehmm.numchildren; nchild++)
	  {
	      forwardalg(traindata[nrow],trainpma[nrow],theInstanceIndex,theInstance,
			 1,ptranlogit[nchild],treehmm.nextptr[nchild],nrow,treehmm);
	  }    
          backalg(traindata[nrow],trainpma[nrow],theInstanceIndex,theInstance, 0, treehmm,nrow,true);
          double dpj =  treehmm.db;
	  if (dpj == 0) 
	  {
	      dlike += Math.log(MINPROB);
	  }
	  else
	  {
	      instanceAE(treehmm,0,traindata[nrow],trainpma[nrow],
                                    trainpval[nrow],dpj,nrow);

              dlike += Math.log(treehmm.db);
	  }
       }

       traverse(treehmm,0,false);
       updateParams(treehmm,0,traindata,trainpma,0);

       traverse(treehmm,0,false);
       if (BEQUALSTD)
       {
          averageChildrenSigmas(treehmm);
       }
       
       int ncount = 0;
                
       //very first time going to assign labels 
       double dpredictitr;

       do
       {
          nglobaliteration++;
	  if (BDEBUG)
	  {
	     System.out.println("Global iteration is now "+nglobaliteration);
	  }

          //train while there is still a big enough improvement
          doldlike = dlike;
          initAE(treehmm);
          dlike = 0;

          for (int nrow = 0; nrow <traindata.length; nrow++)
          {
	     int[] theInstance = trainpval[nrow];
	     int[] theInstanceIndex = trainpvalIndex[nrow];

	     if (BREGDREM)
	     {
		 ptranlogit = treehmm.ptrans;
	     }
             else if ((treehmm.numchildren >1)&&(treehmm.binit))
             {
		 ptranlogit = treehmm.tranC.distributionForInstance(theInstanceIndex,theInstance,nrow);
             }
             else
             {
                ptranlogit = CONSTANTA[treehmm.numchildren];
             }

             treehmm.df = 1;  
             for (int nchild =0;  nchild < treehmm.numchildren; nchild++)
             {
        	 forwardalg(traindata[nrow],trainpma[nrow],theInstanceIndex,theInstance,
			    1,ptranlogit[nchild],treehmm.nextptr[nchild],nrow,treehmm);
             }
  	    
             backalg(traindata[nrow],trainpma[nrow],theInstanceIndex,theInstance, 0, 
		     treehmm,nrow,true);

             double dpj =  treehmm.db;

	     if (dpj == 0) 
	     {
	        dlike += Math.log(MINPROB);
	     }
	     else
	     {
	        instanceAE(treehmm,0,traindata[nrow],trainpma[nrow], trainpval[nrow],dpj,nrow);
                dlike += Math.log(treehmm.db);
	     }
 
	     if (Double.isNaN(dlike))
	     {
	
		 traverse(treehmm,0,true);

		 System.out.println(nrow+"\t");
		 for (int na = 0; na < trainpval[nrow].length; na++)
		 {
		     System.out.print(trainpval[nrow][na]+"\t");
		 }
		 System.out.println();
		 if(BREGDREM){
			 System.out.println("BREGDREM is wahr");
		 }else{
			 System.out.println("BREGDREM is not wahr");
		 }
		 
		 if(!BREGDREM)
		 {
				int count = 0;
		    for (int na = 0; na < ptranlogit.length; na++)
		    {
		    	
		        System.out.print(ptranlogit[na]+"\t");
		        if(count > 10){
		    		count=0;
		    		System.out.println();
		    	}else{
		    		count++;
		    	}
		    }
		    System.out.println();
		    for (int na = 0; na < treehmm.recweight.length; na++)
		    {
		        //System.out.print(treehmm.recweight[na]+"\t");
		        if(count > 10){
		    		count=0;
		    		//System.out.println();
		    	}else{
		    		count++;
		    	}
		    }
		 }
		 System.out.println();
		 System.out.println("treehmm.db = "+treehmm.db + " treehmm.df = "+treehmm.df);
		// System.out.println("traindata length = "+treehmm.db + "treehmm.df = "+treehmm.df "treehmm.dpj = "+treehmm.db);
		 throw new Exception();
	     }
          } 

	  traverse(treehmm,0,false);
          updateParams(treehmm,0,traindata,trainpma,0);
          if (BEQUALSTD)
	  {
	     averageChildrenSigmas(treehmm);
	  }

	  traverse(treehmm,0,false); 
	  ncount++;
	  dpredictitr= (dbesttrainlike-dlike)/(dlike-doldlike);
	  if (BDEBUGMODEL)
	  {
             System.out.println(ncount +" - Train hmm Likelihood: "+dlike+
                             " best "+dbesttrainlike+" "+"oldlike"+doldlike+" "+dpredictitr);
	  }
       } 
       while (((dlike-doldlike)/Math.abs(dlike) > BEPSILON)
             &&((bpruneexempt)||(dpredictitr<MAXFUTUREITR)));
	     
       if (BDEBUG)
       {
          System.out.println("Likelihood: "+dlike);
       }

       dtrainlike = dlike;   


       nglobaltime++;
       int nparams =countNodes(treehmm,nglobaltime);
       dgloballike = dlike;

       if (BDEBUG)
       {
          System.out.print(dlike+"\t"+nparams);
       }
       dlike -= nodepenalty*nparams;

       if (BDEBUG)
       {
          System.out.println("\t"+dlike);
       }

       return (dlike);
    }
    
    //new miRNA functions
/////////////////////////////////////////// 
    /**
     * Responsible for loading the miRNA-gene interaction input data from the file into the variable fields
     *   static String miRNAInteractionDataFile = "";
    static String miRNAExpressionDataFile = "";
    static boolean checkStatusTF;     //should TF expression be scaled?
    static boolean checkStatusmiRNA;  //should miRNA be used as a regulator
    //values filled by the constructor
    String[] miRNANames;
    int[] dmiRNABindingVals;
    HashMap htmiRNABinding;
    HashSet hsmiRNAUniqueInput;
     
    public void readmiRNAGeneData(String szbinding) throws IOException
    {
       htmiRNABinding = new HashMap();
       hsmiRNAUniqueInput = new HashSet();
       BufferedReader br = null;

       try
       {
          br = new BufferedReader(new InputStreamReader(
                             new GZIPInputStream(new FileInputStream(szbinding))));
       }
       catch (IOException ex)
       {
          br = new BufferedReader(new FileReader(szbinding));
       }

       String szLine = br.readLine();
       StringTokenizer st = new StringTokenizer(szLine,"\t");
       String szh1="";

       if (szLine == null)
       {
          throw new IllegalArgumentException("Empty miRNA-gene interaction input file found!");
       }
       else if (szLine.startsWith("\t"))
       {
          numbits = st.countTokens();
       }
       else
       {
          numbits = st.countTokens()-1;
	  szh1 = st.nextToken();
       }

System.out.println("number of columns : " + numbits);
       miRNANames = new String[numbits];

       for (int ntfindex = 0; ntfindex < numbits; ntfindex++)
       {
    	   miRNANames[ntfindex] = st.nextToken();
       }


       boolean bthreecol = (((numbits ==2))&&(szh1.equalsIgnoreCase("miRNA"))
	                    &&(miRNANames[0].equalsIgnoreCase("GENE")));

       if (bthreecol)
       {
    	   System.out.println("parse in three column format");
	   parseThreeColFormat(br);
       }
       else
       {
	   parseGridFormat(br);
       }



       hsmiRNAUniqueInput.add(new Integer(0));
       if (bfilterbinding)
       {
          //filter those genes without binding data
	  int nbinding = 0;  //count of the number of genes with binding info

          //first determining how many genes we have binding data for
	  Object[] hitA  = new Object[theDataSet.data.length];
	  for (int nrow = 0; nrow < theDataSet.data.length; nrow++)
	  {
	     Object obj = getBindingObject(theDataSet.genenames[nrow],theDataSet.probenames[nrow]); 

  	     if (obj != null)
	     {
	        hitA[nrow] = obj;
	        nbinding++;
	     }
	     else
	     {
	        hitA[nrow] = null;
	     }
	  }
              
	  if (BDEBUG)
	  {
             System.out.println("nbinding = "+nbinding);
          }

          bindingpvalGene= new int[nbinding][];
          bindingpvalGeneindex = new int[nbinding][];

	  int nbindingindex = 0;
	  boolean[] bbindingdata = new boolean[theDataSet.data.length];
	  //stores whether or not should keep gene

          //going through all data values storing into 
          //bindingpval binding values
          //flagging for filtering those records without binding
          for (int nrow = 0; nrow < theDataSet.data.length; nrow++)
          {
	     if (hitA[nrow] != null)
	     {
	        BindingGeneRec theBindingGeneRec = (BindingGeneRec) hitA[nrow]; 

	        bindingpvalGene[nbindingindex] = theBindingGeneRec.bindingpvalGene;
	        bindingpvalGeneindex[nbindingindex] = theBindingGeneRec.bindingpvalGeneindex; 
	        for (int nindex =0; nindex < theBindingGeneRec.bindingpvalGene.length; nindex++)
	        {
	           hsmiRNAUniqueInput.add(new Integer(theBindingGeneRec.bindingpvalGene[nindex]));
	        }
	        nbindingindex++;
                bbindingdata[nrow] = true;
	     }
	     else
	     {
	        bbindingdata[nrow] = false;
	     }
	  }
	  //this line below was causing a bug previously
          //theDataSet = (DREM_DataSet) theDataSet.filtergenesgeneral(bbindingdata, nbinding, true);
	  theDataSet = new DREM_DataSet(theDataSet.filtergenesgeneral(bbindingdata, nbinding, true),theDataSet.tga);
	}
	else
	{
	   //not filtering genes with missing p-values instead setting to 0
	   //transfering binding p-values in a hashmap to an array
	   //0 values if do not have a p-value for that gene
	   //bindingpval = new double[theDataSet.data.length][numbits];
	   bindingpvalGene = new int[theDataSet.data.length][];//[numbits];
	   bindingpvalGeneindex = new int[theDataSet.data.length][];

	   for (int nrow = 0; nrow < theDataSet.data.length; nrow++)
	   {
	     Object obj = getBindingObject(theDataSet.genenames[nrow], theDataSet.probenames[nrow]);

  	     if (obj != null)
	     {
		BindingGeneRec theBindingGeneRec = (BindingGeneRec) obj;
	        bindingpvalGene[nrow] = theBindingGeneRec.bindingpvalGene;
	        bindingpvalGeneindex[nrow] = theBindingGeneRec.bindingpvalGeneindex; 
	        for (int nindex =0; nindex < theBindingGeneRec.bindingpvalGene.length; nindex++)
	        {
	           hsmiRNAUniqueInput.add(new Integer(theBindingGeneRec.bindingpvalGene[nindex]));
	        }
	     }
	     else
	     {
		 bindingpvalGene[nrow] = new int[0];
		 bindingpvalGeneindex[nrow] = new int[0];
	     }
          }
       }
	  
       System.out.println("Number of selected genes is "+bindingpvalGene.length); 
       bindingpvalTFindex = new int[numbits][];
       bindingpvalTF = new int[numbits][];
       makeTFindex(bindingpvalGene, bindingpvalGeneindex, bindingpvalTF, bindingpvalTFindex);
       hsmiRNAUniqueInput.add(new Integer(0));
       Iterator itrKeys = hsmiRNAUniqueInput.iterator();
       int nel = 0;

       dmiRNABindingVals = new int[hsmiRNAUniqueInput.size()];
       while (itrKeys.hasNext())
       {
          Integer key = (Integer) itrKeys.next();
	  dmiRNABindingVals[nel] = key.intValue();
	  nel++;
       }
       Arrays.sort(dmiRNABindingVals);
    }

*/

    
    
    
    
}