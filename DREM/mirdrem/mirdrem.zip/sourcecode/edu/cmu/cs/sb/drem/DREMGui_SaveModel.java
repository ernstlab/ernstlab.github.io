package edu.cmu.cs.sb.drem;

import edu.cmu.cs.sb.core.*;
import edu.umd.cs.piccolo.nodes.PPath;
import javax.swing.*;
import javax.swing.event.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.text.NumberFormat;
import java.io.*;
import javax.imageio.*;
import java.awt.image.*;
import edu.umd.cs.piccolo.nodes.PImage;

/**
 * Class to encapsulate window used to specify a file to save a DREM model
 */ 
public class DREMGui_SaveModel extends JPanel
{

    final static Color bgColor = Color.white;
    final static Color fgColor = Color.black;
    final DREM_Timeiohmm theTimeiohmm;
    final DREM_Timeiohmm.Treenode treecopy;

    /**
     * Class constructor
     */
    public DREMGui_SaveModel(final DREM_Timeiohmm theTimeiohmm,final DREM_Timeiohmm.Treenode treecopy,
                             final JFrame theFrame,final DREMGui theDREMGui)
    {
	this.theTimeiohmm = theTimeiohmm;
	this.treecopy = treecopy;

        setLayout(new BoxLayout(this, BoxLayout.PAGE_AXIS));
        setForeground(fgColor);
	final JFileChooser theChooser = new JFileChooser();
	add(theChooser);
	theChooser.setDialogType(JFileChooser.SAVE_DIALOG);
        theChooser.addActionListener(new ActionListener() 
        {
             public void actionPerformed(ActionEvent e) 
             {
                // set label's icon to the current image
                String state = (String)e.getActionCommand();

  	        if (state.equals(JFileChooser.CANCEL_SELECTION))
	        {
	           theFrame.setVisible(false);
	           theFrame.dispose();
	        }
                else if (state.equals(JFileChooser.APPROVE_SELECTION))
	        {
                   File f = theChooser.getSelectedFile();

                   try
                   {
		       PrintWriter pw = new PrintWriter(new FileOutputStream(f));
		       pw.print(theTimeiohmm.saveString(treecopy));
		       pw.println("COLORS");
		       pw.print(theDREMGui.saveColors());
		       pw.close();
                   }
	           catch (final IOException fex)
                   {
                      javax.swing.SwingUtilities.invokeLater(new Runnable() 
                      {
                         public void run() 
                         {
                            JOptionPane.showMessageDialog(null, fex.getMessage(), 
                                "Exception thrown", JOptionPane.ERROR_MESSAGE);
	                 }
	              });
                      fex.printStackTrace(System.out);
                   }
		   theDREMGui.bsavedchange = true;
	           theFrame.setVisible(false);
	           theFrame.dispose();
	        }
             }
         });			      
    }
}